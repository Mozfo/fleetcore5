--
-- PostgreSQL database dump
--

\restrict vWvUyac9BWqJJViPhRrdQSvjA01yypE9jYTPOy7ajNGWfUmx1TxmN7i5ATggUQ1

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: shadow; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA shadow;


ALTER SCHEMA shadow OWNER TO postgres;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA extensions;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: audit_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.audit_category AS ENUM (
    'security',
    'financial',
    'compliance',
    'operational'
);


ALTER TYPE public.audit_category OWNER TO postgres;

--
-- Name: audit_severity; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.audit_severity AS ENUM (
    'info',
    'warning',
    'error',
    'critical'
);


ALTER TYPE public.audit_severity OWNER TO postgres;

--
-- Name: lifecycle_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.lifecycle_status AS ENUM (
    'active',
    'inactive',
    'deprecated'
);


ALTER TYPE public.lifecycle_status OWNER TO postgres;

--
-- Name: performed_by_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.performed_by_type AS ENUM (
    'system',
    'employee',
    'api'
);


ALTER TYPE public.performed_by_type OWNER TO postgres;

--
-- Name: tenant_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tenant_status AS ENUM (
    'trialing',
    'active',
    'suspended',
    'past_due',
    'cancelled'
);


ALTER TYPE public.tenant_status OWNER TO postgres;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: rid_driver_language_add(uuid, uuid, character, text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.rid_driver_language_add(p_tenant_id uuid, p_driver_id uuid, p_language_code character, p_proficiency text, p_created_by uuid) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  v_language_id uuid;
BEGIN
  -- Set tenant context
  PERFORM set_config('app.current_tenant_id', p_tenant_id::text, true);

  -- Insert language
  INSERT INTO public.rid_driver_languages (
    tenant_id,
    driver_id,
    language_code,
    proficiency,
    created_by,
    updated_by
  ) VALUES (
    p_tenant_id,
    p_driver_id,
    p_language_code,
    p_proficiency,
    p_created_by,
    p_created_by
  )
  RETURNING id INTO v_language_id;

  RETURN v_language_id;
END;
$$;


ALTER FUNCTION public.rid_driver_language_add(p_tenant_id uuid, p_driver_id uuid, p_language_code character, p_proficiency text, p_created_by uuid) OWNER TO postgres;

--
-- Name: rid_driver_profile_get(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.rid_driver_profile_get(p_driver_id uuid, p_tenant_id uuid) RETURNS TABLE(driver_id uuid, tenant_id uuid, first_name text, last_name text, email text, phone text, date_of_birth date, gender text, nationality character, hire_date date, employment_status text, driver_status text, cooperation_type text, emergency_contact_name text, emergency_contact_phone text, languages text[], languages_detail json)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  -- Set tenant context
  PERFORM set_config('app.current_tenant_id', p_tenant_id::text, true);

  -- Return driver profile
  RETURN QUERY
  SELECT
    v.driver_id,
    v.tenant_id,
    v.first_name,
    v.last_name,
    v.email,
    v.phone,
    v.date_of_birth,
    v.gender,
    v.nationality,
    v.hire_date,
    v.employment_status,
    v.driver_status,
    v.cooperation_type,
    v.emergency_contact_name,
    v.emergency_contact_phone,
    v.languages,
    v.languages_detail
  FROM public.v_driver_profile v
  WHERE v.driver_id = p_driver_id
    AND v.tenant_id = p_tenant_id;
END;
$$;


ALTER FUNCTION public.rid_driver_profile_get(p_driver_id uuid, p_tenant_id uuid) OWNER TO postgres;

--
-- Name: set_tenant(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_tenant(p_tenant_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  PERFORM set_config('app.current_tenant_id', p_tenant_id::text, false);
END;
$$;


ALTER FUNCTION public.set_tenant(p_tenant_id uuid) OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO postgres;

--
-- Name: sync_driver_status_from_employment(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sync_driver_status_from_employment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Terminated employment → terminated driver_status
  IF NEW.employment_status = 'terminated' THEN
    NEW.driver_status := 'terminated';

  -- Suspended employment → suspended driver_status (unless already terminated)
  ELSIF NEW.employment_status = 'suspended' AND NEW.driver_status <> 'terminated' THEN
    NEW.driver_status := 'suspended';

  -- On leave → inactive driver_status (ALWAYS blocks trips)
  ELSIF NEW.employment_status = 'on_leave' THEN
    NEW.driver_status := 'inactive';

  -- Active employment → active driver_status (unless manually set otherwise)
  ELSIF NEW.employment_status = 'active'
    AND NEW.driver_status IN ('inactive', 'suspended') THEN
    NEW.driver_status := 'active';
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION public.sync_driver_status_from_employment() OWNER TO postgres;

--
-- Name: trigger_set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trigger_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_set_updated_at() OWNER TO postgres;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


ALTER FUNCTION storage.add_prefixes(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: delete_leaf_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_rows_deleted integer;
BEGIN
    LOOP
        WITH candidates AS (
            SELECT DISTINCT
                t.bucket_id,
                unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        ),
        uniq AS (
             SELECT
                 bucket_id,
                 name,
                 storage.get_level(name) AS level
             FROM candidates
             WHERE name <> ''
             GROUP BY bucket_id, name
        ),
        leaf AS (
             SELECT
                 p.bucket_id,
                 p.name,
                 p.level
             FROM storage.prefixes AS p
                  JOIN uniq AS u
                       ON u.bucket_id = p.bucket_id
                           AND u.name = p.name
                           AND u.level = p.level
             WHERE NOT EXISTS (
                 SELECT 1
                 FROM storage.objects AS o
                 WHERE o.bucket_id = p.bucket_id
                   AND o.level = p.level + 1
                   AND o.name COLLATE "C" LIKE p.name || '/%'
             )
             AND NOT EXISTS (
                 SELECT 1
                 FROM storage.prefixes AS c
                 WHERE c.bucket_id = p.bucket_id
                   AND c.level = p.level + 1
                   AND c.name COLLATE "C" LIKE p.name || '/%'
             )
        )
        DELETE
        FROM storage.prefixes AS p
            USING leaf AS l
        WHERE p.bucket_id = l.bucket_id
          AND p.name = l.name
          AND p.level = l.level;

        GET DIAGNOSTICS v_rows_deleted = ROW_COUNT;
        EXIT WHEN v_rows_deleted = 0;
    END LOOP;
END;
$$;


ALTER FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) OWNER TO supabase_storage_admin;

--
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION storage.delete_prefix(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION storage.delete_prefix_hierarchy_trigger() OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


ALTER FUNCTION storage.get_level(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


ALTER FUNCTION storage.get_prefix(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


ALTER FUNCTION storage.get_prefixes(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- Name: lock_top_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket text;
    v_top text;
BEGIN
    FOR v_bucket, v_top IN
        SELECT DISTINCT t.bucket_id,
            split_part(t.name, '/', 1) AS top
        FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        WHERE t.name <> ''
        ORDER BY 1, 2
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_bucket || '/' || v_top, 0));
        END LOOP;
END;
$$;


ALTER FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) OWNER TO supabase_storage_admin;

--
-- Name: objects_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_delete_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_insert_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    -- NEW - OLD (destinations to create prefixes for)
    v_add_bucket_ids text[];
    v_add_names      text[];

    -- OLD - NEW (sources to prune)
    v_src_bucket_ids text[];
    v_src_names      text[];
BEGIN
    IF TG_OP <> 'UPDATE' THEN
        RETURN NULL;
    END IF;

    -- 1) Compute NEW−OLD (added paths) and OLD−NEW (moved-away paths)
    WITH added AS (
        SELECT n.bucket_id, n.name
        FROM new_rows n
        WHERE n.name <> '' AND position('/' in n.name) > 0
        EXCEPT
        SELECT o.bucket_id, o.name FROM old_rows o WHERE o.name <> ''
    ),
    moved AS (
         SELECT o.bucket_id, o.name
         FROM old_rows o
         WHERE o.name <> ''
         EXCEPT
         SELECT n.bucket_id, n.name FROM new_rows n WHERE n.name <> ''
    )
    SELECT
        -- arrays for ADDED (dest) in stable order
        COALESCE( (SELECT array_agg(a.bucket_id ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        COALESCE( (SELECT array_agg(a.name      ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        -- arrays for MOVED (src) in stable order
        COALESCE( (SELECT array_agg(m.bucket_id ORDER BY m.bucket_id, m.name) FROM moved m), '{}' ),
        COALESCE( (SELECT array_agg(m.name      ORDER BY m.bucket_id, m.name) FROM moved m), '{}' )
    INTO v_add_bucket_ids, v_add_names, v_src_bucket_ids, v_src_names;

    -- Nothing to do?
    IF (array_length(v_add_bucket_ids, 1) IS NULL) AND (array_length(v_src_bucket_ids, 1) IS NULL) THEN
        RETURN NULL;
    END IF;

    -- 2) Take per-(bucket, top) locks: ALL prefixes in consistent global order to prevent deadlocks
    DECLARE
        v_all_bucket_ids text[];
        v_all_names text[];
    BEGIN
        -- Combine source and destination arrays for consistent lock ordering
        v_all_bucket_ids := COALESCE(v_src_bucket_ids, '{}') || COALESCE(v_add_bucket_ids, '{}');
        v_all_names := COALESCE(v_src_names, '{}') || COALESCE(v_add_names, '{}');

        -- Single lock call ensures consistent global ordering across all transactions
        IF array_length(v_all_bucket_ids, 1) IS NOT NULL THEN
            PERFORM storage.lock_top_prefixes(v_all_bucket_ids, v_all_names);
        END IF;
    END;

    -- 3) Create destination prefixes (NEW−OLD) BEFORE pruning sources
    IF array_length(v_add_bucket_ids, 1) IS NOT NULL THEN
        WITH candidates AS (
            SELECT DISTINCT t.bucket_id, unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(v_add_bucket_ids, v_add_names) AS t(bucket_id, name)
            WHERE name <> ''
        )
        INSERT INTO storage.prefixes (bucket_id, name)
        SELECT c.bucket_id, c.name
        FROM candidates c
        ON CONFLICT DO NOTHING;
    END IF;

    -- 4) Prune source prefixes bottom-up for OLD−NEW
    IF array_length(v_src_bucket_ids, 1) IS NOT NULL THEN
        -- re-entrancy guard so DELETE on prefixes won't recurse
        IF current_setting('storage.gc.prefixes', true) <> '1' THEN
            PERFORM set_config('storage.gc.prefixes', '1', true);
        END IF;

        PERFORM storage.delete_leaf_prefixes(v_src_bucket_ids, v_src_names);
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_update_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_level_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_level_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Set the new level
        NEW."level" := "storage"."get_level"(NEW."name");
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_level_trigger() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: prefixes_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.prefixes_delete_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.prefixes_insert_trigger() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    sort_col text;
    sort_ord text;
    cursor_op text;
    cursor_expr text;
    sort_expr text;
BEGIN
    -- Validate sort_order
    sort_ord := lower(sort_order);
    IF sort_ord NOT IN ('asc', 'desc') THEN
        sort_ord := 'asc';
    END IF;

    -- Determine cursor comparison operator
    IF sort_ord = 'asc' THEN
        cursor_op := '>';
    ELSE
        cursor_op := '<';
    END IF;
    
    sort_col := lower(sort_column);
    -- Validate sort column  
    IF sort_col IN ('updated_at', 'created_at') THEN
        cursor_expr := format(
            '($5 = '''' OR ROW(date_trunc(''milliseconds'', %I), name COLLATE "C") %s ROW(COALESCE(NULLIF($6, '''')::timestamptz, ''epoch''::timestamptz), $5))',
            sort_col, cursor_op
        );
        sort_expr := format(
            'COALESCE(date_trunc(''milliseconds'', %I), ''epoch''::timestamptz) %s, name COLLATE "C" %s',
            sort_col, sort_ord, sort_ord
        );
    ELSE
        cursor_expr := format('($5 = '''' OR name COLLATE "C" %s $5)', cursor_op);
        sort_expr := format('name COLLATE "C" %s', sort_ord);
    END IF;

    RETURN QUERY EXECUTE format(
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    NULL::uuid AS id,
                    updated_at,
                    created_at,
                    NULL::timestamptz AS last_accessed_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
            UNION ALL
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    id,
                    updated_at,
                    created_at,
                    last_accessed_at,
                    metadata
                FROM storage.objects
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
        ) obj
        ORDER BY %s
        LIMIT $3
        $sql$,
        cursor_expr,    -- prefixes WHERE
        sort_expr,      -- prefixes ORDER BY
        cursor_expr,    -- objects WHERE
        sort_expr,      -- objects ORDER BY
        sort_expr       -- final ORDER BY
    )
    USING prefix, bucket_name, limits, levels, start_after, sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: adm_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_audit_logs (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    member_id uuid,
    entity character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    changes jsonb,
    ip_address character varying(45),
    user_agent text,
    "timestamp" timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.adm_audit_logs OWNER TO postgres;

--
-- Name: adm_member_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_member_roles (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    member_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.adm_member_roles OWNER TO postgres;

--
-- Name: adm_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_members (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    email extensions.citext NOT NULL,
    clerk_user_id character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(50),
    role character varying(50) DEFAULT 'member'::character varying NOT NULL,
    last_login_at timestamp(6) with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.adm_members OWNER TO postgres;

--
-- Name: adm_provider_employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_provider_employees (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    clerk_user_id character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    department character varying(50),
    title character varying(50),
    permissions jsonb,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.adm_provider_employees OWNER TO postgres;

--
-- Name: adm_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_roles (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.adm_roles OWNER TO postgres;

--
-- Name: adm_tenant_lifecycle_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_tenant_lifecycle_events (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    performed_by uuid,
    effective_date date,
    description text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT adm_tenant_lifecycle_events_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['created'::character varying, 'plan_changed'::character varying, 'suspended'::character varying, 'reactivated'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.adm_tenant_lifecycle_events OWNER TO postgres;

--
-- Name: adm_tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adm_tenants (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    country_code character varying(2) NOT NULL,
    clerk_organization_id text,
    vat_rate numeric(5,2),
    default_currency character(3) DEFAULT 'EUR'::character varying NOT NULL,
    timezone text DEFAULT 'Europe/Paris'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(6) with time zone,
    subdomain character varying(100)
);


ALTER TABLE public.adm_tenants OWNER TO postgres;

--
-- Name: bil_billing_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bil_billing_plans (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    plan_name text NOT NULL,
    description text,
    monthly_fee numeric(14,2) DEFAULT 0 NOT NULL,
    annual_fee numeric(14,2) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT bil_billing_plans_annual_fee_check CHECK ((annual_fee >= (0)::numeric)),
    CONSTRAINT bil_billing_plans_monthly_fee_check CHECK ((monthly_fee >= (0)::numeric)),
    CONSTRAINT bil_billing_plans_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text])))
);


ALTER TABLE public.bil_billing_plans OWNER TO postgres;

--
-- Name: bil_payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bil_payment_methods (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    payment_type text NOT NULL,
    provider_token text NOT NULL,
    expires_at date,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT bil_payment_methods_payment_type_check CHECK ((payment_type = ANY (ARRAY['card'::text, 'bank'::text, 'paypal'::text]))),
    CONSTRAINT bil_payment_methods_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'expired'::text])))
);


ALTER TABLE public.bil_payment_methods OWNER TO postgres;

--
-- Name: bil_tenant_invoice_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bil_tenant_invoice_lines (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    amount numeric(18,2) DEFAULT 0 NOT NULL,
    quantity numeric(10,2) DEFAULT 1 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT bil_tenant_invoice_lines_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT bil_tenant_invoice_lines_quantity_check CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.bil_tenant_invoice_lines OWNER TO postgres;

--
-- Name: bil_tenant_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bil_tenant_invoices (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    invoice_number text NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    total_amount numeric(18,2) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT bil_tenant_invoices_due_date_check CHECK ((due_date >= invoice_date)),
    CONSTRAINT bil_tenant_invoices_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'sent'::text, 'paid'::text, 'overdue'::text]))),
    CONSTRAINT bil_tenant_invoices_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


ALTER TABLE public.bil_tenant_invoices OWNER TO postgres;

--
-- Name: bil_tenant_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bil_tenant_subscriptions (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    subscription_start date NOT NULL,
    subscription_end date,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT bil_tenant_subscriptions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'cancelled'::text]))),
    CONSTRAINT bil_tenant_subscriptions_subscription_end_check CHECK (((subscription_end IS NULL) OR (subscription_end >= subscription_start)))
);


ALTER TABLE public.bil_tenant_subscriptions OWNER TO postgres;

--
-- Name: bil_tenant_usage_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bil_tenant_usage_metrics (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    metric_name character varying(50) NOT NULL,
    metric_value numeric(18,2) DEFAULT 0 NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT bil_tenant_usage_metrics_metric_value_check CHECK ((metric_value >= (0)::numeric)),
    CONSTRAINT bil_tenant_usage_metrics_period_end_check CHECK ((period_end >= period_start))
);


ALTER TABLE public.bil_tenant_usage_metrics OWNER TO postgres;

--
-- Name: crm_contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crm_contracts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    lead_id uuid NOT NULL,
    contract_reference text NOT NULL,
    contract_date date NOT NULL,
    effective_date date NOT NULL,
    expiry_date date,
    total_value numeric(18,2) NOT NULL,
    currency character varying(3) NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    opportunity_id uuid,
    CONSTRAINT crm_contracts_date_check CHECK ((effective_date >= contract_date)),
    CONSTRAINT crm_contracts_effective_date_check CHECK ((effective_date >= contract_date)),
    CONSTRAINT crm_contracts_expiry_check CHECK (((expiry_date IS NULL) OR (expiry_date >= effective_date))),
    CONSTRAINT crm_contracts_expiry_date_check CHECK (((expiry_date IS NULL) OR (expiry_date >= effective_date))),
    CONSTRAINT crm_contracts_status_check CHECK ((status = ANY (ARRAY['active'::text, 'expired'::text, 'terminated'::text]))),
    CONSTRAINT crm_contracts_total_value_check CHECK ((total_value >= (0)::numeric))
);


ALTER TABLE public.crm_contracts OWNER TO postgres;

--
-- Name: crm_leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crm_leads (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text,
    demo_company_name text,
    source text,
    status text DEFAULT 'new'::text NOT NULL,
    message text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    country_code character varying(2),
    fleet_size character varying(50),
    current_software character varying(255),
    assigned_to uuid,
    qualification_score integer,
    qualification_notes text,
    qualified_date timestamp with time zone,
    converted_date timestamp with time zone,
    utm_source character varying(255),
    utm_medium character varying(255),
    utm_campaign character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT crm_leads_source_check CHECK (((source IS NULL) OR (source = ANY (ARRAY['web'::text, 'referral'::text, 'event'::text])))),
    CONSTRAINT crm_leads_status_check CHECK ((status = ANY (ARRAY['new'::text, 'qualified'::text, 'converted'::text, 'lost'::text])))
);


ALTER TABLE public.crm_leads OWNER TO postgres;

--
-- Name: crm_opportunities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crm_opportunities (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    lead_id uuid NOT NULL,
    stage text DEFAULT 'prospect'::text NOT NULL,
    expected_value numeric(18,2),
    close_date date,
    assigned_to uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    probability integer,
    CONSTRAINT crm_opportunities_expected_value_check CHECK (((expected_value IS NULL) OR (expected_value >= (0)::numeric))),
    CONSTRAINT crm_opportunities_opportunity_stage_check CHECK ((stage = ANY (ARRAY['prospect'::text, 'proposal'::text, 'negotiation'::text, 'closed'::text])))
);


ALTER TABLE public.crm_opportunities OWNER TO postgres;

--
-- Name: dir_car_makes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dir_car_makes (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    name text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.dir_car_makes OWNER TO postgres;

--
-- Name: dir_car_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dir_car_models (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    make_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    vehicle_class_id uuid
);


ALTER TABLE public.dir_car_models OWNER TO postgres;

--
-- Name: dir_country_regulations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dir_country_regulations (
    country_code character(2) NOT NULL,
    vehicle_max_age integer,
    min_vehicle_class text,
    min_fare_per_trip numeric(10,2),
    min_fare_per_km numeric(10,2),
    min_fare_per_hour numeric(10,2),
    vat_rate numeric(5,2),
    currency character(3) NOT NULL,
    timezone text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    requires_vtc_card boolean DEFAULT false NOT NULL
);


ALTER TABLE public.dir_country_regulations OWNER TO postgres;

--
-- Name: dir_platforms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dir_platforms (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    api_config jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.dir_platforms OWNER TO postgres;

--
-- Name: dir_vehicle_classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dir_vehicle_classes (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    country_code character(2) NOT NULL,
    name text NOT NULL,
    description text,
    max_age integer,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.dir_vehicle_classes OWNER TO postgres;

--
-- Name: doc_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doc_documents (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    document_type text NOT NULL,
    file_url text NOT NULL,
    issue_date date,
    expiry_date date,
    verified boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT doc_documents_document_type_check CHECK ((document_type = ANY (ARRAY['registration'::text, 'insurance'::text, 'visa'::text, 'residence_visa'::text, 'emirates_id'::text, 'platform_approval'::text, 'other'::text]))),
    CONSTRAINT doc_documents_entity_type_check CHECK ((entity_type = ANY (ARRAY['flt_vehicle'::text, 'rid_driver'::text, 'adm_member'::text, 'contract'::text])))
);


ALTER TABLE public.doc_documents OWNER TO postgres;

--
-- Name: fin_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_accounts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    account_name text NOT NULL,
    account_type text NOT NULL,
    currency character varying(3) NOT NULL,
    balance numeric(18,2) DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT fin_accounts_account_type_check CHECK ((account_type = ANY (ARRAY['bank'::text, 'cash'::text, 'digital'::text]))),
    CONSTRAINT fin_accounts_balance_check CHECK ((balance >= (0)::numeric))
);


ALTER TABLE public.fin_accounts OWNER TO postgres;

--
-- Name: fin_driver_payment_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_driver_payment_batches (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    batch_reference text NOT NULL,
    payment_date date NOT NULL,
    total_amount numeric(18,2) NOT NULL,
    currency character varying(3) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT fin_driver_payment_batches_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT fin_driver_payment_batches_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


ALTER TABLE public.fin_driver_payment_batches OWNER TO postgres;

--
-- Name: fin_driver_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_driver_payments (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    payment_batch_id uuid NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying(3) NOT NULL,
    payment_date date NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT fin_driver_payments_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT fin_driver_payments_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


ALTER TABLE public.fin_driver_payments OWNER TO postgres;

--
-- Name: fin_toll_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_toll_transactions (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    toll_gate text NOT NULL,
    toll_date date NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency character varying(3) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT fin_toll_transactions_amount_check CHECK ((amount >= (0)::numeric))
);


ALTER TABLE public.fin_toll_transactions OWNER TO postgres;

--
-- Name: fin_traffic_fines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_traffic_fines (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    fine_reference text NOT NULL,
    fine_date date NOT NULL,
    fine_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency character varying(3) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT fin_traffic_fines_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT fin_traffic_fines_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'paid'::text, 'disputed'::text, 'cancelled'::text])))
);


ALTER TABLE public.fin_traffic_fines OWNER TO postgres;

--
-- Name: fin_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fin_transactions (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    account_id uuid NOT NULL,
    transaction_type text NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying(3) NOT NULL,
    reference text NOT NULL,
    description text,
    transaction_date timestamp with time zone NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT fin_transactions_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT fin_transactions_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'completed'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT fin_transactions_transaction_type_check CHECK ((transaction_type = ANY (ARRAY['credit'::text, 'debit'::text])))
);


ALTER TABLE public.fin_transactions OWNER TO postgres;

--
-- Name: flt_vehicle_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flt_vehicle_assignments (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date,
    assignment_type character varying(50) DEFAULT 'permanent'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.flt_vehicle_assignments OWNER TO postgres;

--
-- Name: flt_vehicle_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flt_vehicle_events (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    event_type text NOT NULL,
    event_date timestamp(6) with time zone NOT NULL,
    severity text,
    downtime_hours integer,
    cost_amount numeric(10,2),
    currency character(3) DEFAULT 'EUR'::bpchar NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    notes text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT flt_vehicle_events_event_type_check CHECK ((event_type = ANY (ARRAY['acquisition'::text, 'disposal'::text, 'maintenance'::text, 'accident'::text, 'handover'::text, 'inspection'::text, 'insurance'::text]))),
    CONSTRAINT flt_vehicle_events_severity_check CHECK (((severity IS NULL) OR (severity = ANY (ARRAY['minor'::text, 'moderate'::text, 'severe'::text, 'total_loss'::text]))))
);


ALTER TABLE public.flt_vehicle_events OWNER TO postgres;

--
-- Name: flt_vehicle_expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flt_vehicle_expenses (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    ride_id uuid,
    expense_date date NOT NULL,
    expense_category text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character(3) DEFAULT 'EUR'::bpchar NOT NULL,
    payment_method text,
    receipt_url text,
    odometer_reading integer,
    quantity numeric(10,2),
    unit_price numeric(10,2),
    location text,
    vendor text,
    description text,
    reimbursed boolean DEFAULT false NOT NULL,
    reimbursed_at timestamp(6) with time zone,
    reimbursed_in_batch_id uuid,
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT flt_vehicle_expenses_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT flt_vehicle_expenses_expense_category_check CHECK ((expense_category = ANY (ARRAY['fuel'::text, 'toll'::text, 'parking'::text, 'wash'::text, 'repair'::text, 'fine'::text, 'other'::text]))),
    CONSTRAINT flt_vehicle_expenses_payment_method_check CHECK (((payment_method IS NULL) OR (payment_method = ANY (ARRAY['cash'::text, 'card'::text, 'fuel_card'::text, 'toll_card'::text, 'company_account'::text]))))
);


ALTER TABLE public.flt_vehicle_expenses OWNER TO postgres;

--
-- Name: flt_vehicle_insurances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flt_vehicle_insurances (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    provider_name text NOT NULL,
    policy_number text NOT NULL,
    policy_type text NOT NULL,
    coverage_amount numeric(12,2),
    currency character(3) DEFAULT 'EUR'::bpchar NOT NULL,
    deductible_amount numeric(10,2),
    premium_amount numeric(10,2) NOT NULL,
    premium_frequency text DEFAULT 'annual'::character varying NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    auto_renew boolean DEFAULT false NOT NULL,
    contact_name text,
    contact_phone text,
    contact_email text,
    document_url text,
    claim_count integer DEFAULT 0 NOT NULL,
    last_claim_date date,
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT flt_vehicle_insurances_claim_count_check CHECK ((claim_count >= 0)),
    CONSTRAINT flt_vehicle_insurances_dates_check CHECK ((end_date > start_date)),
    CONSTRAINT flt_vehicle_insurances_policy_type_check CHECK ((policy_type = ANY (ARRAY['comprehensive'::text, 'third_party'::text, 'collision'::text, 'other'::text]))),
    CONSTRAINT flt_vehicle_insurances_premium_amount_check CHECK ((premium_amount > (0)::numeric)),
    CONSTRAINT flt_vehicle_insurances_premium_frequency_check CHECK ((premium_frequency = ANY (ARRAY['annual'::text, 'semi_annual'::text, 'quarterly'::text, 'monthly'::text])))
);


ALTER TABLE public.flt_vehicle_insurances OWNER TO postgres;

--
-- Name: flt_vehicle_maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flt_vehicle_maintenance (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    maintenance_type text NOT NULL,
    scheduled_date date NOT NULL,
    completed_date date,
    odometer_reading integer,
    next_service_km integer,
    next_service_date date,
    provider_name text,
    provider_contact text,
    cost_amount numeric(10,2),
    currency character(3) DEFAULT 'EUR'::bpchar NOT NULL,
    invoice_reference text,
    parts_replaced text,
    notes text,
    status text DEFAULT 'scheduled'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    CONSTRAINT flt_vehicle_maintenance_dates_check CHECK (((completed_date IS NULL) OR (completed_date >= scheduled_date))),
    CONSTRAINT flt_vehicle_maintenance_maintenance_type_check CHECK ((maintenance_type = ANY (ARRAY['oil_change'::text, 'service'::text, 'inspection'::text, 'tire_rotation'::text, 'brake_service'::text, 'repair'::text, 'other'::text]))),
    CONSTRAINT flt_vehicle_maintenance_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'in_progress'::text, 'completed'::text, 'cancelled'::text])))
);


ALTER TABLE public.flt_vehicle_maintenance OWNER TO postgres;

--
-- Name: flt_vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flt_vehicles (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    make_id uuid NOT NULL,
    model_id uuid NOT NULL,
    license_plate text NOT NULL,
    vin text,
    year integer NOT NULL,
    color text,
    seats integer DEFAULT 4 NOT NULL,
    vehicle_class text,
    fuel_type text,
    transmission text,
    registration_date date,
    insurance_number text,
    insurance_expiry date,
    last_inspection date,
    next_inspection date,
    odometer integer,
    ownership_type text DEFAULT 'owned'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.flt_vehicles OWNER TO postgres;

--
-- Name: rev_driver_revenues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rev_driver_revenues (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_revenue numeric(18,2) DEFAULT 0 NOT NULL,
    commission_amount numeric(18,2) DEFAULT 0 NOT NULL,
    net_revenue numeric(18,2) DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rev_driver_revenues_commission_amount_check CHECK ((commission_amount >= (0)::numeric)),
    CONSTRAINT rev_driver_revenues_net_revenue_check CHECK ((net_revenue >= (0)::numeric)),
    CONSTRAINT rev_driver_revenues_period_check CHECK ((period_end >= period_start)),
    CONSTRAINT rev_driver_revenues_total_revenue_check CHECK ((total_revenue >= (0)::numeric))
);


ALTER TABLE public.rev_driver_revenues OWNER TO postgres;

--
-- Name: rev_reconciliations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rev_reconciliations (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    import_id uuid NOT NULL,
    reconciliation_date date NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rev_reconciliations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


ALTER TABLE public.rev_reconciliations OWNER TO postgres;

--
-- Name: rev_revenue_imports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rev_revenue_imports (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    import_reference text NOT NULL,
    import_date date NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    total_revenue numeric(18,2) DEFAULT 0 NOT NULL,
    currency character varying(3) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rev_revenue_imports_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT rev_revenue_imports_total_revenue_check CHECK ((total_revenue >= (0)::numeric))
);


ALTER TABLE public.rev_revenue_imports OWNER TO postgres;

--
-- Name: rid_driver_blacklists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_blacklists (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    reason text NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rid_driver_blacklists_date_check CHECK (((end_date IS NULL) OR (end_date >= start_date))),
    CONSTRAINT rid_driver_blacklists_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text])))
);


ALTER TABLE public.rid_driver_blacklists OWNER TO postgres;

--
-- Name: rid_driver_cooperation_terms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_cooperation_terms (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    terms_version text NOT NULL,
    accepted_at timestamp with time zone,
    effective_date date,
    expiry_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rid_driver_cooperation_terms_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'expired'::text, 'terminated'::text])))
);


ALTER TABLE public.rid_driver_cooperation_terms OWNER TO postgres;

--
-- Name: rid_driver_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_documents (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    document_id uuid NOT NULL,
    document_type text NOT NULL,
    expiry_date date,
    verified boolean DEFAULT false NOT NULL,
    verified_by uuid,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.rid_driver_documents OWNER TO postgres;

--
-- Name: rid_driver_languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_languages (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    language_code character(2) NOT NULL,
    proficiency text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rid_driver_languages_language_code_check CHECK ((language_code ~ '^[A-Za-z]{2}$'::text)),
    CONSTRAINT rid_driver_languages_proficiency_check CHECK ((proficiency = ANY (ARRAY['basic'::text, 'conversational'::text, 'fluent'::text, 'native'::text])))
);


ALTER TABLE public.rid_driver_languages OWNER TO postgres;

--
-- Name: rid_driver_performances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_performances (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    trips_completed integer DEFAULT 0 NOT NULL,
    trips_cancelled integer DEFAULT 0 NOT NULL,
    on_time_rate numeric(5,2),
    avg_rating numeric(3,2),
    incidents_count integer DEFAULT 0 NOT NULL,
    earnings_total numeric(12,2) DEFAULT 0 NOT NULL,
    hours_online numeric(7,2),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rid_driver_performances_avg_rating_check CHECK (((avg_rating >= (0)::numeric) AND (avg_rating <= (5)::numeric))),
    CONSTRAINT rid_driver_performances_earnings_total_check CHECK ((earnings_total >= (0)::numeric)),
    CONSTRAINT rid_driver_performances_hours_online_check CHECK ((hours_online >= (0)::numeric)),
    CONSTRAINT rid_driver_performances_incidents_count_check CHECK ((incidents_count >= 0)),
    CONSTRAINT rid_driver_performances_on_time_rate_check CHECK (((on_time_rate >= (0)::numeric) AND (on_time_rate <= (100)::numeric))),
    CONSTRAINT rid_driver_performances_period_check CHECK ((period_end >= period_start)),
    CONSTRAINT rid_driver_performances_trips_cancelled_check CHECK ((trips_cancelled >= 0)),
    CONSTRAINT rid_driver_performances_trips_completed_check CHECK ((trips_completed >= 0))
);


ALTER TABLE public.rid_driver_performances OWNER TO postgres;

--
-- Name: rid_driver_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_requests (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    request_type text NOT NULL,
    request_date date NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    resolution_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rid_driver_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'cancelled'::text])))
);


ALTER TABLE public.rid_driver_requests OWNER TO postgres;

--
-- Name: rid_driver_training; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_driver_training (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    training_name text NOT NULL,
    provider text,
    status text DEFAULT 'planned'::text NOT NULL,
    assigned_at timestamp with time zone,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    score numeric(5,2),
    certificate_url text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT rid_driver_training_score_check CHECK (((score >= (0)::numeric) AND (score <= (100)::numeric))),
    CONSTRAINT rid_driver_training_status_check CHECK ((status = ANY (ARRAY['planned'::text, 'in_progress'::text, 'completed'::text, 'expired'::text, 'cancelled'::text])))
);


ALTER TABLE public.rid_driver_training OWNER TO postgres;

--
-- Name: rid_drivers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rid_drivers (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    license_number text NOT NULL,
    license_issue_date date,
    license_expiry_date date,
    professional_card_no text,
    professional_expiry date,
    driver_status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(6) with time zone,
    rating numeric,
    notes text,
    date_of_birth date,
    gender text,
    nationality character(2),
    hire_date date,
    employment_status text DEFAULT 'active'::text NOT NULL,
    cooperation_type text,
    emergency_contact_name text,
    emergency_contact_phone text,
    CONSTRAINT rid_drivers_cooperation_type_check CHECK (((cooperation_type IS NULL) OR (cooperation_type = ANY (ARRAY['employee'::text, 'contractor'::text, 'owner_operator'::text, 'partner_driver'::text])))),
    CONSTRAINT rid_drivers_dob_check CHECK (((date_of_birth IS NULL) OR (date_of_birth <= CURRENT_DATE))),
    CONSTRAINT rid_drivers_driver_status_check CHECK (((driver_status)::text = ANY (ARRAY['active'::text, 'inactive'::text, 'suspended'::text, 'terminated'::text]))),
    CONSTRAINT rid_drivers_employment_status_check CHECK ((employment_status = ANY (ARRAY['active'::text, 'on_leave'::text, 'suspended'::text, 'terminated'::text]))),
    CONSTRAINT rid_drivers_gender_check CHECK (((gender IS NULL) OR (gender = ANY (ARRAY['male'::text, 'female'::text, 'unspecified'::text])))),
    CONSTRAINT rid_drivers_nationality_check CHECK (((nationality IS NULL) OR (nationality ~ '^[A-Za-z]{2}$'::text)))
);


ALTER TABLE public.rid_drivers OWNER TO postgres;

--
-- Name: sch_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sch_goals (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    goal_type text NOT NULL,
    target_value numeric NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    assigned_to uuid NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT sch_goals_period_check CHECK ((period_end >= period_start)),
    CONSTRAINT sch_goals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'in_progress'::text, 'completed'::text, 'cancelled'::text, 'expired'::text])))
);


ALTER TABLE public.sch_goals OWNER TO postgres;

--
-- Name: sch_maintenance_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sch_maintenance_schedules (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    vehicle_id uuid NOT NULL,
    scheduled_date date NOT NULL,
    maintenance_type text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT sch_maintenance_schedules_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'completed'::text, 'cancelled'::text])))
);


ALTER TABLE public.sch_maintenance_schedules OWNER TO postgres;

--
-- Name: sch_shifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sch_shifts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT sch_shifts_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'completed'::text, 'cancelled'::text]))),
    CONSTRAINT sch_shifts_time_check CHECK ((end_time >= start_time))
);


ALTER TABLE public.sch_shifts OWNER TO postgres;

--
-- Name: sch_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sch_tasks (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    task_type text NOT NULL,
    description text NOT NULL,
    target_id uuid NOT NULL,
    due_at timestamp with time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT sch_tasks_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'in_progress'::text, 'completed'::text, 'cancelled'::text, 'overdue'::text])))
);


ALTER TABLE public.sch_tasks OWNER TO postgres;

--
-- Name: sup_customer_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sup_customer_feedback (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    submitted_by uuid NOT NULL,
    submitter_type character varying(50) NOT NULL,
    feedback_text text NOT NULL,
    rating integer NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_by uuid,
    deleted_at timestamp with time zone,
    CONSTRAINT sup_customer_feedback_rating_check CHECK (((rating >= 1) AND (rating <= 5))),
    CONSTRAINT sup_customer_feedback_submitter_type_check CHECK (((submitter_type)::text = ANY ((ARRAY['driver'::character varying, 'client'::character varying, 'member'::character varying, 'guest'::character varying])::text[])))
);


ALTER TABLE public.sup_customer_feedback OWNER TO postgres;

--
-- Name: TABLE sup_customer_feedback; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.sup_customer_feedback IS 'Customer feedback and satisfaction ratings';


--
-- Name: COLUMN sup_customer_feedback.submitted_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sup_customer_feedback.submitted_by IS 'Polymorphic reference to feedback submitter';


--
-- Name: COLUMN sup_customer_feedback.rating; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.sup_customer_feedback.rating IS 'Satisfaction rating from 1 (worst) to 5 (best)';


--
-- Name: sup_ticket_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sup_ticket_messages (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    message_body text NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.sup_ticket_messages OWNER TO postgres;

--
-- Name: sup_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sup_tickets (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    raised_by uuid NOT NULL,
    subject text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    assigned_to uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT sup_tickets_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text]))),
    CONSTRAINT sup_tickets_status_check CHECK ((status = ANY (ARRAY['open'::text, 'pending'::text, 'resolved'::text, 'closed'::text])))
);


ALTER TABLE public.sup_tickets OWNER TO postgres;

--
-- Name: trp_client_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trp_client_invoices (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    invoice_number text NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    total_amount numeric(14,2) NOT NULL,
    currency character varying(3) NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT trp_client_invoices_due_date_check CHECK ((due_date >= invoice_date)),
    CONSTRAINT trp_client_invoices_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'sent'::text, 'paid'::text, 'cancelled'::text, 'overdue'::text]))),
    CONSTRAINT trp_client_invoices_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


ALTER TABLE public.trp_client_invoices OWNER TO postgres;

--
-- Name: trp_platform_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trp_platform_accounts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    platform_id uuid NOT NULL,
    account_identifier text NOT NULL,
    api_key text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text
);


ALTER TABLE public.trp_platform_accounts OWNER TO postgres;

--
-- Name: trp_settlements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trp_settlements (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    trip_id uuid NOT NULL,
    settlement_reference text NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency character varying(3) NOT NULL,
    platform_commission numeric(14,2) NOT NULL,
    net_amount numeric(14,2) NOT NULL,
    settlement_date date NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    deletion_reason text,
    CONSTRAINT trp_settlements_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT trp_settlements_net_amount_check CHECK ((net_amount >= (0)::numeric)),
    CONSTRAINT trp_settlements_platform_commission_check CHECK ((platform_commission >= (0)::numeric)),
    CONSTRAINT trp_settlements_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'settled'::text, 'cancelled'::text])))
);


ALTER TABLE public.trp_settlements OWNER TO postgres;

--
-- Name: trp_trips; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trp_trips (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    driver_id uuid NOT NULL,
    vehicle_id uuid,
    platform_id uuid,
    pickup_latitude numeric(10,8),
    pickup_longitude numeric(11,8),
    start_time timestamp(6) with time zone,
    dropoff_latitude numeric(10,8),
    dropoff_longitude numeric(11,8),
    end_time timestamp(6) with time zone,
    distance_km numeric(10,2),
    duration_minutes numeric,
    payment_method character varying(50),
    platform_commission numeric(10,2),
    net_earnings numeric(10,2),
    status character varying(50) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(6) with time zone,
    client_id uuid,
    trip_date date,
    fare_base numeric,
    fare_distance numeric,
    fare_time numeric,
    surge_multiplier numeric,
    tip_amount numeric,
    CONSTRAINT trp_trips_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'card'::character varying, 'wallet'::character varying, 'invoice'::character varying])::text[]))),
    CONSTRAINT trp_trips_status_check CHECK (((status)::text = ANY ((ARRAY['completed'::character varying, 'cancelled'::character varying, 'rejected'::character varying, 'no_show'::character varying])::text[])))
);


ALTER TABLE public.trp_trips OWNER TO postgres;

--
-- Name: v_driver_profile; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_driver_profile AS
 SELECT d.id AS driver_id,
    d.tenant_id,
    d.first_name,
    d.last_name,
    d.email,
    d.phone,
    d.date_of_birth,
    d.gender,
    d.nationality,
    d.hire_date,
    d.employment_status,
    d.driver_status,
    d.cooperation_type,
    d.emergency_contact_name,
    d.emergency_contact_phone,
    d.license_number,
    d.license_issue_date,
    d.license_expiry_date,
    d.professional_card_no,
    d.professional_expiry,
    d.rating,
    d.created_at,
    d.updated_at,
    array_remove(array_agg(DISTINCT l.language_code) FILTER (WHERE (l.deleted_at IS NULL)), NULL::bpchar) AS languages,
    json_agg(json_build_object('code', l.language_code, 'proficiency', l.proficiency)) FILTER (WHERE (l.deleted_at IS NULL)) AS languages_detail
   FROM (public.rid_drivers d
     LEFT JOIN public.rid_driver_languages l ON (((l.driver_id = d.id) AND (l.tenant_id = d.tenant_id) AND (l.deleted_at IS NULL))))
  WHERE (d.deleted_at IS NULL)
  GROUP BY d.id, d.tenant_id, d.first_name, d.last_name, d.email, d.phone, d.date_of_birth, d.gender, d.nationality, d.hire_date, d.employment_status, d.driver_status, d.cooperation_type, d.emergency_contact_name, d.emergency_contact_phone, d.license_number, d.license_issue_date, d.license_expiry_date, d.professional_card_no, d.professional_expiry, d.rating, d.created_at, d.updated_at;


ALTER VIEW public.v_driver_profile OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE storage.prefixes OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
2b0b597a-b008-49b9-aff7-e42482653580		2025-11-02 21:14:56.402791+00	20251103011555_init	\N	\N	2025-11-02 21:14:56.402791+00	1
78c7372e-a31c-46eb-ad30-4d1099b10199	47df7b28bc293f7c7654333cdee5e84d4e57a54f08ab6dfba9707a0c9188db76	\N	20251103012521_add_adm_v2	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251103012521_add_adm_v2\n\nDatabase error code: 2BP01\n\nDatabase error:\nERROR: cannot drop index adm_tenants_clerk_org_unique because constraint adm_tenants_clerk_org_unique on table adm_tenants requires it\nHINT: You can drop constraint adm_tenants_clerk_org_unique on table adm_tenants instead.\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E2BP01), message: "cannot drop index adm_tenants_clerk_org_unique because constraint adm_tenants_clerk_org_unique on table adm_tenants requires it", detail: None, hint: Some("You can drop constraint adm_tenants_clerk_org_unique on table adm_tenants instead."), position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("dependency.c"), line: Some(787), routine: Some("findDependentObjects") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20251103012521_add_adm_v2"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20251103012521_add_adm_v2"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:236	2025-11-02 22:25:17.321521+00	2025-11-02 21:25:52.67258+00	0
70ad9a19-09de-4d5c-84ea-d30c84d2ea96	47df7b28bc293f7c7654333cdee5e84d4e57a54f08ab6dfba9707a0c9188db76	2025-11-02 22:25:17.561486+00	20251103012521_add_adm_v2		\N	2025-11-02 22:25:17.561486+00	0
\.


--
-- Data for Name: adm_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_audit_logs (id, tenant_id, member_id, entity, entity_id, action, changes, ip_address, user_agent, "timestamp") FROM stdin;
19d81b74-71c6-4e39-93c0-a01e79e1eb5d	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:05:27.799+00
d851e87a-04c9-43de-b8ff-cef8bff40073	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:05:28.396+00
ac4ac900-3360-4e6f-8b6c-c9d8facabc24	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:05:28.965+00
e13ca516-b771-4247-a9fa-eea9af3cff77	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:05:29.594+00
546ce91f-6f14-4b59-8b14-cb71c91d4c3a	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:27:36.699+00
51a8ce09-e316-4cfd-b7f8-821a9077c4ea	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:27:37.311+00
9dfa93e3-8f33-4cfb-bd3f-a042d9be62da	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:27:37.918+00
3caccda1-58dd-47ef-81ec-25965384243b	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:27:38.626+00
2d67bd22-ad6f-417a-a6d2-a5e3922a1074	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:40:18.091+00
24642064-3e88-4252-b203-e67b790850b7	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:40:18.379+00
85943b2c-3485-49b9-94a0-a14608c1dbfc	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:40:18.518+00
8a83b04f-7b78-4d16-8bab-c069a4d72711	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:40:18.657+00
bff4baf7-29bc-4cf3-894d-f9154d8886d7	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:48:26.356+00
4b5115b4-4efd-42ee-b01c-ba0dc0ff69df	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:48:26.685+00
86847c82-8039-4e65-aa2b-7426f776f486	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:48:26.832+00
eed5ba45-52fc-4381-8608-6597cafbb633	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:48:26.972+00
55f3e41e-cf59-4b7e-81ee-5091e512298e	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:52:01.844+00
2724eb31-ad95-41dd-94be-84ce616ca1cf	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:52:02.143+00
8beea298-81e4-4c6c-99d9-4d9e9048e1cd	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:52:02.285+00
39993147-6ed7-4e08-82a5-c6c6a7c63b81	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:52:02.417+00
25332063-8463-4018-8aa0-69a406bae437	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:56:14.635+00
23880997-cdfe-468e-9bf4-394d90d737f8	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:56:14.919+00
d80f56d9-b598-4482-bf5d-ebad5d8e8df7	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:56:15.059+00
e7faee76-dd3b-436a-bdbe-1458d2e0ae39	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:56:15.201+00
880997e8-4a5d-44e2-9b59-c4220a93d54d	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:57:09.872+00
d48f59b3-c8be-47c1-8135-18a6027a4d74	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:57:10.177+00
38ff8a58-f5d9-44e6-b2a0-c51ea78540e0	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:57:10.325+00
afe2fc7a-29f8-48fe-bb10-8f7d91329baa	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:57:10.47+00
5597bb14-de2d-4dbe-80a3-63e7ad634f8b	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	vehicle	00000000-0000-0000-0000-000000000001	create	{"_audit_metadata": {"test": "step1a2", "source": "manual_test", "version": "1.0"}, "_audit_snapshot": {"year": 2023, "model": "Toyota Corolla", "plate": "ABC123"}}	\N	\N	2025-10-14 12:57:55.087+00
952097e4-0e67-4308-8960-fa1b9a2acd3c	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	driver	00000000-0000-0000-0000-000000000002	update	{"name": {"new": "Jane Doe", "old": "John Doe"}, "email": {"new": "jane@example.com", "old": "john@example.com"}, "status": {"new": "inactive", "old": "active"}, "_audit_reason": "User profile update requested by admin"}	\N	\N	2025-10-14 12:57:55.367+00
b5580c86-b55a-48f9-92c5-202dee9828fd	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	document	00000000-0000-0000-0000-000000000003	delete	{"_audit_reason": "GDPR deletion request - user requested account removal"}	\N	\N	2025-10-14 12:57:55.514+00
df441537-1599-4718-a60b-215544018c16	550e8400-e29b-41d4-a716-446655440001	660e8400-e29b-41d4-a716-446655440001	organization	550e8400-e29b-41d4-a716-446655440001	create	{"_audit_clerk_id": "user_2testClerkId123xyz", "_audit_metadata": {"source": "clerk_webhook", "event_type": "organization.created", "webhook_id": "wh_123abc"}}	192.168.1.100	ClerkWebhook/1.0	2025-10-14 12:57:55.66+00
98050742-35c7-4b4b-9777-d3eb1f5cf09c	550e8400-e29b-41d4-a716-446655440001	\N	system_parameter	32348671-038b-4a6a-91de-7cd48bb259b5	validation_failed	{"_audit_metadata": {"allowed_fields": ["id", "email"], "attempted_field": "test"}}	\N	\N	2025-10-14 17:50:08.29437+00
87160f62-2663-4b14-8811-d06f8fd36132	550e8400-e29b-41d4-a716-446655440001	\N	system_parameter	00000000-0000-0000-0000-000000000000	validation_failed	{"_audit_metadata": {"allowed_fields": ["id", "email", "created_at"], "attempted_field": "password", "validation_type": "sortby_whitelist"}}	\N	\N	2025-10-14 17:50:30.628+00
2d85a1cf-6d2d-4fa9-b014-d8a71e5ef866	550e8400-e29b-41d4-a716-446655440001	\N	system_parameter	00000000-0000-0000-0000-000000000000	validation_failed	{"_audit_metadata": {"allowed_fields": ["id", "email", "created_at"], "attempted_field": "deleted_at", "validation_type": "sortby_whitelist"}}	\N	\N	2025-10-14 17:50:30.628+00
b85cc056-85f1-4d8a-8392-2f229edb3dd1	550e8400-e29b-41d4-a716-446655440001	\N	system_parameter	00000000-0000-0000-0000-000000000000	validation_failed	{"_audit_metadata": {"allowed_fields": ["id", "tenant_id", "first_name", "last_name", "email", "driver_status", "employment_status", "rating", "hire_date", "created_at", "updated_at"], "attempted_field": "deleted_at", "validation_type": "sortby_whitelist"}}	\N	\N	2025-10-14 19:01:25.199+00
b2cd5f0c-702a-4e5b-b432-d2ba56a2ea24	550e8400-e29b-41d4-a716-446655440001	\N	system_parameter	00000000-0000-0000-0000-000000000000	validation_failed	{"_audit_metadata": {"allowed_fields": ["id", "tenant_id", "first_name", "last_name", "email", "driver_status", "employment_status", "rating", "hire_date", "created_at", "updated_at"], "attempted_field": "license_number", "validation_type": "sortby_whitelist"}}	\N	\N	2025-10-14 19:01:26.604+00
c2faf060-6248-4a19-b8a4-553fb2cb9915	00000000-0000-0000-0000-000000000000	\N	system_parameter	00000000-0000-0000-0000-000000000000	ip_blocked	{"_audit_metadata": {"test": true}}	203.0.113.99	\N	2025-10-14 19:32:14.132+00
df0bc809-eee5-4570-9cb0-91b5cc3be477	00000000-0000-0000-0000-000000000000	\N	system_parameter	00000000-0000-0000-0000-000000000000	ip_blocked	{"_audit_metadata": {"blocked_ip": "::1", "whitelist_size": 0, "attempted_route": "/adm"}}	::1	curl/8.7.1	2025-10-14 20:57:41.275+00
9ab15fca-2102-4e4a-8f5c-c8fb4da9018a	00000000-0000-0000-0000-000000000000	\N	system_parameter	00000000-0000-0000-0000-000000000000	ip_blocked	{"_audit_metadata": {"test_case": "security_valid_token", "blocked_route": "/adm"}}	203.0.113.99	Mozilla/5.0 Test Agent	2025-10-14 21:18:30.372+00
b09e1927-b6e5-4fd6-9ac8-68ab86a01718	00000000-0000-0000-0000-000000000000	\N	system_parameter	00000000-0000-0000-0000-000000000000	ip_blocked	{"_audit_metadata": {"blocked_ip": "198.51.100.42", "whitelist_size": 0, "attempted_route": "/adm"}}	198.51.100.42	curl/8.7.1	2025-10-14 21:19:50.142+00
\.


--
-- Data for Name: adm_member_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_member_roles (id, tenant_id, member_id, role_id, assigned_at, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: adm_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_members (id, tenant_id, email, clerk_user_id, first_name, last_name, phone, role, last_login_at, metadata, status, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
660e8400-e29b-41d4-a716-446655440001	550e8400-e29b-41d4-a716-446655440001	admin@dubaifleet.ae	user_clerk_dubai_admin_placeholder	Ahmed	Al Maktoum	\N	admin	\N	{"department": "operations"}	active	2025-10-09 19:11:07.995+00	\N	2025-10-09 19:11:07.995+00	\N	\N	\N	\N
660e8400-e29b-41d4-a716-446655440002	550e8400-e29b-41d4-a716-446655440002	admin@parisvtc.fr	user_clerk_paris_admin_placeholder	Marie	Dubois	\N	admin	\N	{"department": "operations"}	active	2025-10-09 19:11:09.679+00	\N	2025-10-09 19:11:09.679+00	\N	\N	\N	\N
0b8152a1-a88a-45b9-8a8a-9479cdc851c4	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760766200454@example.com	user_34E65ZZ7iVsp6DsEHecUSJAhty1	\N	\N	\N	member	\N	{}	active	2025-10-18 05:43:24.873+00	\N	2025-10-18 05:43:24.873+00	\N	\N	\N	\N
192e5b3e-6d95-4250-a968-ea813845a617	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760766222829@example.com	user_34E68LFz0JSafgpFUthljecnFVM	\N	\N	\N	member	\N	{}	active	2025-10-18 05:43:44.885+00	\N	2025-10-18 05:43:44.885+00	\N	\N	\N	\N
e340877e-6e86-490f-813b-2864d92009d3	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760766249680@example.com	user_34E6Bkq1gQk2WekhEEjlt153UJL	\N	\N	\N	member	\N	{}	active	2025-10-18 05:44:11.61+00	\N	2025-10-18 05:44:11.61+00	\N	\N	\N	\N
a359d9f5-b904-4c5d-b705-9cb724a1bb71	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760766685544@example.com	user_34E74bIt5zbZHTORrQIBd3SVIG5	\N	\N	\N	member	\N	{}	active	2025-10-18 05:51:29.387+00	\N	2025-10-18 05:51:29.387+00	\N	\N	\N	\N
ac6bc4bc-c8e5-4467-88f1-2f5ec0b4b721	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760766852262@example.com	user_34E7PNJJF9OUQcZudyFojpahcOk	\N	\N	\N	member	\N	{}	active	2025-10-18 05:54:14.47+00	\N	2025-10-18 05:54:14.47+00	\N	\N	\N	\N
71b13168-413e-416f-8598-6ec43eed452f	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760766990877@example.com	user_34E7gttp60XEid7lvlC0627quIM	\N	\N	\N	member	\N	{}	active	2025-10-18 05:56:33.414+00	\N	2025-10-18 05:56:33.414+00	\N	\N	\N	\N
c1131b36-5a05-423a-a68f-c2b2f39a096b	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760767000459@example.com	user_34E7i0UQJ89w9VUg2Hs4rt1NPSx	\N	\N	\N	member	\N	{}	active	2025-10-18 05:56:42.247+00	\N	2025-10-18 05:56:42.247+00	\N	\N	\N	\N
87af528d-c638-4fd6-a12c-95d151c8fb2e	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760767075687@example.com	user_34E7rXuHuj6cV7SkzYyFerjwhzz	\N	\N	\N	member	\N	{}	active	2025-10-18 05:57:57.961+00	\N	2025-10-18 05:57:57.961+00	\N	\N	\N	\N
1709c731-1423-4c2b-bc22-bc2b646dea4a	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760767101286@example.com	user_34E7uhQQUB5z5c45L5OAXSSxkLe	\N	\N	\N	member	\N	{}	active	2025-10-18 05:58:23.148+00	\N	2025-10-18 05:58:23.148+00	\N	\N	\N	\N
25abe71c-72a4-44a5-8d85-584354e68c8a	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760768351138@example.com	user_34EARkLFntsKj5TxzdcRX3XeIm4	\N	\N	\N	member	\N	{}	active	2025-10-18 06:19:16.215+00	\N	2025-10-18 06:19:16.215+00	\N	\N	\N	\N
1bc77ded-83c8-4895-9926-0993ca3d88b3	8047c1d2-59e0-465b-990f-5e444de4a45d	test-fleetcore-1760768673367@example.com	user_34EB6LaUl4F1g3ldbku4aYwAWDU	\N	\N	\N	member	\N	{}	active	2025-10-18 06:24:36.403+00	\N	2025-10-18 06:24:36.403+00	\N	\N	\N	\N
7eb670e8-a5ee-4c91-9e47-44f9abfa3970	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760780219097@example.com	user_34EYVD3NxUHuAw2BeU01tzSmHYi	\N	\N	\N	member	\N	{}	active	2025-10-18 09:37:02.142+00	\N	2025-10-18 09:37:02.142+00	\N	\N	\N	\N
f96c7a26-02db-480d-a658-eab7f4d1eafd	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760780639159@example.com	user_34EZM0SUvcZDnYbulNxfIc1oQo8	\N	\N	\N	member	\N	{}	active	2025-10-18 09:44:02.194+00	\N	2025-10-18 09:44:02.194+00	\N	\N	\N	\N
6e265d9c-d01e-4174-8511-c69f8adf235e	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760780984091@example.com	user_34Ea3KFHapio0KjQa2WJnr2aMUg	\N	\N	\N	member	\N	{}	active	2025-10-18 09:49:47.087+00	\N	2025-10-18 09:49:47.087+00	\N	\N	\N	\N
7b0c3a3f-62e5-4f77-a965-0de26654cdd8	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760782330809@example.com	user_34EcmaHRgt1YXejL1Zk7Xu9WPHD	\N	\N	\N	member	\N	{}	active	2025-10-18 10:12:13.786+00	\N	2025-10-18 10:12:13.786+00	\N	\N	\N	\N
751b59fd-cd1d-4499-bfcd-568b887ce0e3	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760782632805@example.com	user_34EdOcrtV9J8du0lHUmFS3hWcm0	\N	\N	\N	member	\N	{}	active	2025-10-18 10:17:22.351+00	\N	2025-10-18 10:17:22.351+00	\N	\N	\N	\N
982ad331-8972-452d-b88e-af6742a78ba4	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-1760787919948@example.com	user_34Eo71NynQjKwcnKfSeDKmQGi8G	\N	\N	\N	member	\N	{}	active	2025-10-18 11:45:31.763+00	\N	2025-10-18 11:45:31.763+00	\N	\N	\N	\N
40942e2a-7006-4ddc-a8a3-3d738832ae5e	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760796548318@example.com	user_34F5bHpyxMvOAOfvT239dkCaTI3	\N	\N	\N	member	\N	{}	active	2025-10-18 14:09:18.268+00	\N	2025-10-18 14:09:18.268+00	\N	\N	\N	\N
b79f53a3-8ab5-47dd-bd45-c17220a587dd	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760797142762@example.com	user_34F6o4gVWBncc5OYuq4qgCmiWh5	\N	\N	\N	member	\N	{}	active	2025-10-18 14:19:12.558+00	\N	2025-10-18 14:19:12.558+00	\N	\N	\N	\N
fbe6f93a-e960-4676-be4a-9e8a8f4483d2	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760800628548@example.com	user_34FDrwHQgLEcHSPMxXIN2vFTMtv	\N	\N	\N	member	\N	{}	active	2025-10-18 15:17:18.407+00	\N	2025-10-18 15:17:18.407+00	\N	\N	\N	\N
ad9498ee-d350-476a-9cb6-f2d21a78a7ab	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760801507534@example.com	user_34FFeSiFHwzBtYCnHpkxNUWJ2pv	\N	\N	\N	member	\N	{}	active	2025-10-18 15:31:57.353+00	\N	2025-10-18 15:31:57.353+00	\N	\N	\N	\N
259fb500-02c1-467b-a235-6f4bc49c568a	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760802001186@example.com	user_34FGeSWcmNcwmttSUtDaCUsWjw1	\N	\N	\N	member	\N	{}	active	2025-10-18 15:45:34.402+00	\N	2025-10-18 15:45:34.402+00	\N	\N	\N	\N
b7abaf9f-db60-439d-a0d8-ae3498113702	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-1760804065956@example.com	user_34FKq6vRypWkFXvFQgiNGE9ZdfC	\N	\N	\N	member	\N	{}	active	2025-10-18 16:18:41.679+00	\N	2025-10-18 16:18:41.679+00	\N	\N	\N	\N
e29294f8-0582-41c0-862d-c694335fed32	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-1760805340291@example.com	user_34FNQCg55B0JO06GaXDfvABm192	\N	\N	\N	member	\N	{}	active	2025-10-18 16:40:00.259+00	\N	2025-10-18 16:40:00.259+00	\N	\N	\N	\N
8d5aa738-f703-48a3-bca3-6ad77b3e6123	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760806065515@example.com	user_34FOtA1UDd9ZvEOsz7Iz2kuCNhT	\N	\N	\N	member	\N	{}	active	2025-10-18 16:52:16.964+00	\N	2025-10-18 16:52:16.964+00	\N	\N	\N	\N
88cf5575-7b30-441a-af08-44151b7de559	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-1760807217571@example.com	user_34FRE4C9WbyCUaUf8MGrCjiEe7N	\N	\N	\N	member	\N	{}	active	2025-10-18 17:11:21.988+00	\N	2025-10-18 17:11:21.988+00	\N	\N	\N	\N
2ed09332-5945-44b5-b304-d7fcd21e5917	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1760808762192@example.com	user_34FUM9xv5ccviyYtLgPXCMYl4fo	\N	\N	\N	member	\N	{}	active	2025-10-18 17:32:45.095+00	\N	2025-10-18 17:32:45.095+00	\N	\N	\N	\N
f0d8f09f-04a2-4518-938f-e45b7bedcdcd	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test-fleetcore-ci-1761230603518@example.com	user_34THNlESkwVGWlUGzcDGTRTyz8K	\N	\N	\N	member	\N	{}	active	2025-10-23 14:48:00.758+00	\N	2025-10-23 14:48:00.758+00	\N	\N	\N	\N
\.


--
-- Data for Name: adm_provider_employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_provider_employees (id, clerk_user_id, name, email, department, title, permissions, status, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: adm_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_roles (id, tenant_id, name, description, permissions, status, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason, slug) FROM stdin;
aef858a5-b42a-437b-aefa-d8e6f01d71f5	bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	test_admin_role	\N	{"admin": true, "manage_drivers": true, "manage_vehicles": true, "manage_directory": true}	active	2025-10-18 10:17:16.302+00	\N	2025-11-02 21:44:21.326275+00	\N	\N	\N	\N	test-admin-role
\.


--
-- Data for Name: adm_tenant_lifecycle_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_tenant_lifecycle_events (id, tenant_id, event_type, performed_by, effective_date, description, created_at) FROM stdin;
\.


--
-- Data for Name: adm_tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adm_tenants (id, name, country_code, clerk_organization_id, vat_rate, default_currency, timezone, created_at, updated_at, deleted_at, subdomain) FROM stdin;
550e8400-e29b-41d4-a716-446655440001	Dubai Fleet Operations	AE	\N	5.00	AED	Asia/Dubai	2025-10-09 19:11:05.769+00	2025-10-09 19:11:05.769+00	\N	\N
550e8400-e29b-41d4-a716-446655440002	Paris VTC Services	FR	\N	20.00	EUR	Europe/Paris	2025-10-09 19:11:06.881+00	2025-10-09 19:11:06.881+00	\N	\N
00000000-0000-0000-0000-000000000000	System	AE	\N	\N	AED	Asia/Dubai	2025-10-14 19:31:36.639681+00	2025-10-14 19:31:36.639681+00	\N	\N
0475027d-2b3a-473e-9fba-021de48aece4	test orga	AE	org_33l3WwjKdZkqm7m68ObW1r8UmIA	\N	EUR	Europe/Paris	2025-10-15 21:00:09.096+00	2025-10-15 21:00:09.096+00	\N	\N
275e0aeb-02b0-4112-991d-84cdeecc71af	dede	AE	org_33kyj4J0iNzutzfLD7tXWZqdlYJ	\N	EUR	Europe/Paris	2025-10-15 21:03:25.406+00	2025-10-15 21:03:25.406+00	\N	\N
8047c1d2-59e0-465b-990f-5e444de4a45d	FleetCore Test Organization	AE	org_34E5E4g3eTrXLmK9NAsMd4X44zW	\N	EUR	Europe/Paris	2025-10-18 05:36:19.7+00	2025-10-18 05:36:19.7+00	\N	\N
bcdac6e3-07bd-4ab3-8d4f-2b8a8314f357	18 OCT 25 test organisation	AE	org_34EedMG4d1Fz3zsFrP6rzJPnrSE	\N	EUR	Europe/Paris	2025-10-18 10:27:26.575+00	2025-10-18 10:27:26.575+00	\N	\N
bfea0f9d-2ae3-42cc-8506-7ce1ed4c67bb	FleetCore Test Organization CI	AE	org_34EXxYF5pWSgjfzuoGlmcHA11aa	\N	EUR	Europe/Paris	2025-10-18 09:32:34.695+00	2025-10-18 15:24:34.067892+00	\N	\N
\.


--
-- Data for Name: bil_billing_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bil_billing_plans (id, plan_name, description, monthly_fee, annual_fee, currency, features, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: bil_payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bil_payment_methods (id, tenant_id, payment_type, provider_token, expires_at, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: bil_tenant_invoice_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bil_tenant_invoice_lines (id, invoice_id, description, amount, quantity, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: bil_tenant_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bil_tenant_invoices (id, tenant_id, invoice_number, invoice_date, due_date, total_amount, currency, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: bil_tenant_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bil_tenant_subscriptions (id, tenant_id, plan_id, subscription_start, subscription_end, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: bil_tenant_usage_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bil_tenant_usage_metrics (id, tenant_id, metric_name, metric_value, period_start, period_end, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: crm_contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crm_contracts (id, lead_id, contract_reference, contract_date, effective_date, expiry_date, total_value, currency, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason, opportunity_id) FROM stdin;
\.


--
-- Data for Name: crm_leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crm_leads (id, full_name, email, phone, demo_company_name, source, status, message, created_at, updated_at, country_code, fleet_size, current_software, assigned_to, qualification_score, qualification_notes, qualified_date, converted_date, utm_source, utm_medium, utm_campaign, metadata, created_by, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
770e8400-e29b-41d4-a716-446655440001	Hassan Abdullah	hassan.abdullah@emiratesfleet.ae	+971501234567	Emirates Fleet Services	\N	new	Interested in fleet management solution for our Dubai operations	2025-10-09 19:45:32.83+00	2025-10-09 19:45:32.83+00	AE	20-50	Excel	\N	\N	\N	\N	\N	website	organic	\N	{"industry": "transportation", "employees": 150}	\N	\N	\N	\N	\N
770e8400-e29b-41d4-a716-446655440002	Jean-Pierre Martin	jp.martin@francevtc.fr	+33612345678	France VTC Premium	\N	qualified	Looking for VTC management platform with driver payroll	2025-10-09 19:46:20.258+00	2025-10-09 19:46:20.258+00	FR	10-20	Custom Solution	\N	75	Strong interest, budget confirmed, decision maker	\N	\N	google	cpc	vtc-france-2025	{"industry": "vtc", "employees": 50}	\N	\N	\N	\N	\N
770e8400-e29b-41d4-a716-446655440003	Fatima Al-Rashid	fatima@abudhabirides.ae	+971509876543	Abu Dhabi Luxury Rides	\N	qualified	Enterprise fleet solution needed for 80 vehicles	2025-10-09 19:46:21.361+00	2025-10-09 19:46:21.361+00	AE	50-100	Outdated System	\N	90	Ready to sign, enterprise deal, needs multi-tenant support	2025-10-05 00:00:00+00	\N	referral	partner	\N	{"urgency": "high", "industry": "luxury-transport", "employees": 200}	\N	\N	\N	\N	\N
\.


--
-- Data for Name: crm_opportunities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crm_opportunities (id, lead_id, stage, expected_value, close_date, assigned_to, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason, probability) FROM stdin;
\.


--
-- Data for Name: dir_car_makes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dir_car_makes (id, tenant_id, name, created_at, updated_at) FROM stdin;
550e8400-e29b-41d4-a716-446655440010	275e0aeb-02b0-4112-991d-84cdeecc71af	Toyota	2025-10-15 20:38:25.746499+00	2025-10-15 21:15:56.005004+00
49274318-c4bf-4df1-abfe-7eef2ff102f7	\N	Tesla_Test_1760802005315	2025-10-18 15:40:07.814+00	2025-10-18 15:40:07.814+00
05ede3c8-54f4-43a9-9e82-d662104598c6	\N	Tesla_Test_1760804079048	2025-10-18 16:14:41.405+00	2025-10-18 16:14:41.405+00
1a9a926a-8e6f-4485-a7fc-0ba00c2528ca	\N	Tesla_Test_1760804239376	2025-10-18 16:17:21.746+00	2025-10-18 16:17:21.746+00
fd0acf0e-f49b-44fd-b5f3-a2bb46504e63	\N	Tesla_Test_1760805352994	2025-10-18 16:35:55.454+00	2025-10-18 16:35:55.454+00
8c626d15-1303-4350-b729-f7f4ce766df1	\N	Tesla_Test_1760805760964	2025-10-18 16:42:43.346+00	2025-10-18 16:42:43.346+00
619c5cbc-6526-4312-a333-0059ab826803	\N	Tesla_Test_1760806027665	2025-10-18 16:47:10.069+00	2025-10-18 16:47:10.069+00
a0a45eec-24e9-4498-840c-85785833059a	\N	Tesla_Test_1760806071043	2025-10-18 16:47:53.433+00	2025-10-18 16:47:53.433+00
e843dd1e-0575-45c2-b599-a3d7e88e002e	\N	Tesla_Test_1760807228825	2025-10-18 17:07:10.961+00	2025-10-18 17:07:10.961+00
283f1ced-1af9-4011-83eb-eb8fb31165f6	\N	Tesla_Test_1760807404769	2025-10-18 17:10:06.852+00	2025-10-18 17:10:06.852+00
c5af190d-3c9b-40f7-8b6a-777f2ace40f1	\N	Tesla_Test_1760807740751	2025-10-18 17:15:44.976+00	2025-10-18 17:15:44.976+00
5058cf58-0af0-4c99-9df6-50a8f500aa74	\N	Tesla_Test_1760809109544	2025-10-18 17:38:32.586+00	2025-10-18 17:38:32.586+00
75368d52-cef3-4dd0-9495-cba1f3737391	\N	Tesla_Test_1760809682094	2025-10-18 17:48:05.364+00	2025-10-18 17:48:05.364+00
9166e90a-90bc-4cef-bbd7-5ded4c675b56	\N	Tesla_Test_1760809941835	2025-10-18 17:52:24.565+00	2025-10-18 17:52:24.565+00
131c48e9-5aac-4385-bd8d-59a072d6be65	\N	Tesla_Test_1761301547747	2025-10-24 10:25:50.689+00	2025-10-24 10:25:50.689+00
e5540370-cca7-4bba-8055-81e62af3bc2d	\N	Tesla_Test_1761305656906	2025-10-24 11:34:18.616+00	2025-10-24 11:34:18.616+00
\.


--
-- Data for Name: dir_car_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dir_car_models (id, tenant_id, make_id, name, created_at, updated_at, vehicle_class_id) FROM stdin;
550e8400-e29b-41d4-a716-446655440011	275e0aeb-02b0-4112-991d-84cdeecc71af	550e8400-e29b-41d4-a716-446655440010	Corolla	2025-10-15 20:38:38.181401+00	2025-10-15 21:15:56.136104+00	\N
\.


--
-- Data for Name: dir_country_regulations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dir_country_regulations (country_code, vehicle_max_age, min_vehicle_class, min_fare_per_trip, min_fare_per_km, min_fare_per_hour, vat_rate, currency, timezone, created_at, updated_at, requires_vtc_card) FROM stdin;
\.


--
-- Data for Name: dir_platforms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dir_platforms (id, name, api_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dir_vehicle_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dir_vehicle_classes (id, country_code, name, description, max_age, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: doc_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doc_documents (id, tenant_id, entity_type, entity_id, document_type, file_url, issue_date, expiry_date, verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fin_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_accounts (id, tenant_id, account_name, account_type, currency, balance, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: fin_driver_payment_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_driver_payment_batches (id, tenant_id, batch_reference, payment_date, total_amount, currency, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: fin_driver_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_driver_payments (id, tenant_id, driver_id, payment_batch_id, amount, currency, payment_date, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: fin_toll_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_toll_transactions (id, tenant_id, driver_id, vehicle_id, toll_gate, toll_date, amount, currency, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: fin_traffic_fines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_traffic_fines (id, tenant_id, driver_id, vehicle_id, fine_reference, fine_date, fine_type, amount, currency, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: fin_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fin_transactions (id, tenant_id, account_id, transaction_type, amount, currency, reference, description, transaction_date, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: flt_vehicle_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flt_vehicle_assignments (id, tenant_id, driver_id, vehicle_id, start_date, end_date, assignment_type, metadata, status, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: flt_vehicle_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flt_vehicle_events (id, tenant_id, vehicle_id, event_type, event_date, severity, downtime_hours, cost_amount, currency, details, notes, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: flt_vehicle_expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flt_vehicle_expenses (id, tenant_id, vehicle_id, driver_id, ride_id, expense_date, expense_category, amount, currency, payment_method, receipt_url, odometer_reading, quantity, unit_price, location, vendor, description, reimbursed, reimbursed_at, reimbursed_in_batch_id, notes, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: flt_vehicle_insurances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flt_vehicle_insurances (id, tenant_id, vehicle_id, provider_name, policy_number, policy_type, coverage_amount, currency, deductible_amount, premium_amount, premium_frequency, start_date, end_date, is_active, auto_renew, contact_name, contact_phone, contact_email, document_url, claim_count, last_claim_date, notes, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: flt_vehicle_maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flt_vehicle_maintenance (id, tenant_id, vehicle_id, maintenance_type, scheduled_date, completed_date, odometer_reading, next_service_km, next_service_date, provider_name, provider_contact, cost_amount, currency, invoice_reference, parts_replaced, notes, status, metadata, created_at, created_by, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: flt_vehicles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flt_vehicles (id, tenant_id, make_id, model_id, license_plate, vin, year, color, seats, vehicle_class, fuel_type, transmission, registration_date, insurance_number, insurance_expiry, last_inspection, next_inspection, odometer, ownership_type, metadata, status, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
550e8400-e29b-41d4-a716-446655440003	275e0aeb-02b0-4112-991d-84cdeecc71af	550e8400-e29b-41d4-a716-446655440010	550e8400-e29b-41d4-a716-446655440011	AB-123-CD	\N	2020	\N	4	\N	\N	\N	\N	\N	\N	\N	\N	\N	owned	{}	pending	2025-10-15 20:38:59.071286+00	\N	2025-10-15 21:15:55.856437+00	\N	\N	\N	\N
\.


--
-- Data for Name: rev_driver_revenues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rev_driver_revenues (id, tenant_id, driver_id, period_start, period_end, total_revenue, commission_amount, net_revenue, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rev_reconciliations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rev_reconciliations (id, tenant_id, import_id, reconciliation_date, status, notes, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rev_revenue_imports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rev_revenue_imports (id, tenant_id, import_reference, import_date, status, total_revenue, currency, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_blacklists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_blacklists (id, tenant_id, driver_id, reason, start_date, end_date, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_cooperation_terms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_cooperation_terms (id, tenant_id, driver_id, terms_version, accepted_at, effective_date, expiry_date, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_documents (id, tenant_id, driver_id, document_id, document_type, expiry_date, verified, verified_by, verified_at, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_languages (id, tenant_id, driver_id, language_code, proficiency, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_performances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_performances (id, tenant_id, driver_id, period_start, period_end, trips_completed, trips_cancelled, on_time_rate, avg_rating, incidents_count, earnings_total, hours_online, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_requests (id, tenant_id, driver_id, request_type, request_date, details, status, resolution_notes, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_driver_training; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_driver_training (id, tenant_id, driver_id, training_name, provider, status, assigned_at, due_at, completed_at, score, certificate_url, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: rid_drivers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rid_drivers (id, tenant_id, first_name, last_name, email, phone, license_number, license_issue_date, license_expiry_date, professional_card_no, professional_expiry, driver_status, created_at, updated_at, deleted_at, rating, notes, date_of_birth, gender, nationality, hire_date, employment_status, cooperation_type, emergency_contact_name, emergency_contact_phone) FROM stdin;
550e8400-e29b-41d4-a716-446655440002	275e0aeb-02b0-4112-991d-84cdeecc71af	Test	Driver	test@test.com	+33612345678	TEST123	\N	\N	\N	\N	active	2025-10-15 20:38:47.909382+00	2025-10-15 20:38:47.909382+00	\N	\N	\N	\N	\N	\N	\N	active	\N	\N	\N
\.


--
-- Data for Name: sch_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sch_goals (id, tenant_id, goal_type, target_value, period_start, period_end, assigned_to, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: sch_maintenance_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sch_maintenance_schedules (id, tenant_id, vehicle_id, scheduled_date, maintenance_type, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: sch_shifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sch_shifts (id, tenant_id, driver_id, start_time, end_time, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: sch_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sch_tasks (id, tenant_id, task_type, description, target_id, due_at, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: sup_customer_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sup_customer_feedback (id, tenant_id, submitted_by, submitter_type, feedback_text, rating, metadata, created_by, created_at, updated_by, updated_at, deleted_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: sup_ticket_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sup_ticket_messages (id, ticket_id, sender_id, message_body, sent_at, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: sup_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sup_tickets (id, tenant_id, raised_by, subject, description, status, priority, assigned_to, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: trp_client_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trp_client_invoices (id, tenant_id, client_id, invoice_number, invoice_date, due_date, total_amount, currency, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: trp_platform_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trp_platform_accounts (id, tenant_id, platform_id, account_identifier, api_key, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: trp_settlements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trp_settlements (id, tenant_id, trip_id, settlement_reference, amount, currency, platform_commission, net_amount, settlement_date, status, metadata, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, deletion_reason) FROM stdin;
\.


--
-- Data for Name: trp_trips; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trp_trips (id, tenant_id, driver_id, vehicle_id, platform_id, pickup_latitude, pickup_longitude, start_time, dropoff_latitude, dropoff_longitude, end_time, distance_km, duration_minutes, payment_method, platform_commission, net_earnings, status, created_at, updated_at, deleted_at, client_id, trip_date, fare_base, fare_distance, fare_time, surge_multiplier, tip_amount) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-10-07 06:12:41
20211116045059	2025-10-07 06:12:43
20211116050929	2025-10-07 06:12:45
20211116051442	2025-10-07 06:12:46
20211116212300	2025-10-07 06:12:48
20211116213355	2025-10-07 06:12:50
20211116213934	2025-10-07 06:12:51
20211116214523	2025-10-07 06:12:53
20211122062447	2025-10-07 06:12:55
20211124070109	2025-10-07 06:12:56
20211202204204	2025-10-07 06:12:58
20211202204605	2025-10-07 06:12:59
20211210212804	2025-10-07 06:13:04
20211228014915	2025-10-07 06:13:06
20220107221237	2025-10-07 06:13:07
20220228202821	2025-10-07 06:13:09
20220312004840	2025-10-07 06:13:11
20220603231003	2025-10-07 06:13:13
20220603232444	2025-10-07 06:13:15
20220615214548	2025-10-07 06:13:16
20220712093339	2025-10-07 06:13:18
20220908172859	2025-10-07 06:13:19
20220916233421	2025-10-07 06:13:21
20230119133233	2025-10-07 06:13:23
20230128025114	2025-10-07 06:13:25
20230128025212	2025-10-07 06:13:26
20230227211149	2025-10-07 06:13:28
20230228184745	2025-10-07 06:13:29
20230308225145	2025-10-07 06:13:31
20230328144023	2025-10-07 06:13:32
20231018144023	2025-10-07 06:13:34
20231204144023	2025-10-07 06:13:37
20231204144024	2025-10-07 06:13:38
20231204144025	2025-10-07 06:13:40
20240108234812	2025-10-07 06:13:41
20240109165339	2025-10-07 06:13:43
20240227174441	2025-10-07 06:13:46
20240311171622	2025-10-07 06:13:48
20240321100241	2025-10-07 06:13:51
20240401105812	2025-10-07 06:13:56
20240418121054	2025-10-07 06:13:58
20240523004032	2025-10-07 06:14:03
20240618124746	2025-10-07 06:14:05
20240801235015	2025-10-07 06:14:06
20240805133720	2025-10-07 06:14:08
20240827160934	2025-10-07 06:14:09
20240919163303	2025-10-07 06:14:12
20240919163305	2025-10-07 06:14:13
20241019105805	2025-10-07 06:14:15
20241030150047	2025-10-07 06:14:21
20241108114728	2025-10-07 06:14:23
20241121104152	2025-10-07 06:14:24
20241130184212	2025-10-07 06:14:26
20241220035512	2025-10-07 06:14:28
20241220123912	2025-10-07 06:14:29
20241224161212	2025-10-07 06:14:31
20250107150512	2025-10-07 06:14:32
20250110162412	2025-10-07 06:14:34
20250123174212	2025-10-07 06:14:35
20250128220012	2025-10-07 06:14:37
20250506224012	2025-10-07 06:14:38
20250523164012	2025-10-07 06:14:40
20250714121412	2025-10-07 06:14:41
20250905041441	2025-10-07 06:14:43
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-10-07 06:12:36.953803
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-10-07 06:12:36.963098
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-10-07 06:12:36.965163
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-10-07 06:12:37.001368
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-10-07 06:12:37.047292
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-10-07 06:12:37.050015
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-10-07 06:12:37.053693
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-10-07 06:12:37.057436
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-10-07 06:12:37.060731
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-10-07 06:12:37.06338
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-10-07 06:12:37.068109
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-10-07 06:12:37.072524
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-10-07 06:12:37.078528
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-10-07 06:12:37.081355
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-10-07 06:12:37.083951
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-10-07 06:12:37.108583
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-10-07 06:12:37.111961
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-10-07 06:12:37.114427
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-10-07 06:12:37.118743
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-10-07 06:12:37.123248
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-10-07 06:12:37.125751
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-10-07 06:12:37.131126
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-10-07 06:12:37.146451
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-10-07 06:12:37.15462
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-10-07 06:12:37.157387
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-10-07 06:12:37.160068
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-10-07 06:12:37.162842
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-10-07 06:12:37.176571
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-10-07 06:12:37.640204
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-10-07 06:12:37.645435
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-10-07 06:12:37.649751
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-10-07 06:12:37.656515
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-10-07 06:12:37.663335
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-10-07 06:12:37.669912
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-10-07 06:12:37.671403
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-10-07 06:12:37.675885
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-10-07 06:12:37.678556
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-10-07 06:12:37.684436
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-10-07 06:12:37.687489
39	add-search-v2-sort-support	39cf7d1e6bf515f4b02e41237aba845a7b492853	2025-10-07 06:12:37.696597
40	fix-prefix-race-conditions-optimized	fd02297e1c67df25a9fc110bf8c8a9af7fb06d1f	2025-10-07 06:12:37.699396
41	add-object-level-update-trigger	44c22478bf01744b2129efc480cd2edc9a7d60e9	2025-10-07 06:12:37.70474
42	rollback-prefix-triggers	f2ab4f526ab7f979541082992593938c05ee4b47	2025-10-07 06:12:37.708642
43	fix-object-level	ab837ad8f1c7d00cc0b7310e989a23388ff29fc6	2025-10-07 06:12:37.712724
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: adm_audit_logs adm_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_audit_logs
    ADD CONSTRAINT adm_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: adm_member_roles adm_member_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_pkey PRIMARY KEY (id);


--
-- Name: adm_members adm_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_members
    ADD CONSTRAINT adm_members_pkey PRIMARY KEY (id);


--
-- Name: adm_provider_employees adm_provider_employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_provider_employees
    ADD CONSTRAINT adm_provider_employees_pkey PRIMARY KEY (id);


--
-- Name: adm_roles adm_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_roles
    ADD CONSTRAINT adm_roles_pkey PRIMARY KEY (id);


--
-- Name: adm_roles adm_roles_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_roles
    ADD CONSTRAINT adm_roles_slug_key UNIQUE (slug);


--
-- Name: adm_tenant_lifecycle_events adm_tenant_lifecycle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_tenant_lifecycle_events
    ADD CONSTRAINT adm_tenant_lifecycle_events_pkey PRIMARY KEY (id);


--
-- Name: adm_tenants adm_tenants_clerk_org_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_tenants
    ADD CONSTRAINT adm_tenants_clerk_org_unique UNIQUE (clerk_organization_id);


--
-- Name: adm_tenants adm_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_tenants
    ADD CONSTRAINT adm_tenants_pkey PRIMARY KEY (id);


--
-- Name: adm_tenants adm_tenants_subdomain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_tenants
    ADD CONSTRAINT adm_tenants_subdomain_key UNIQUE (subdomain);


--
-- Name: bil_billing_plans bil_billing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_billing_plans
    ADD CONSTRAINT bil_billing_plans_pkey PRIMARY KEY (id);


--
-- Name: bil_payment_methods bil_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_payment_methods
    ADD CONSTRAINT bil_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: bil_tenant_invoice_lines bil_tenant_invoice_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoice_lines
    ADD CONSTRAINT bil_tenant_invoice_lines_pkey PRIMARY KEY (id);


--
-- Name: bil_tenant_invoices bil_tenant_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoices
    ADD CONSTRAINT bil_tenant_invoices_pkey PRIMARY KEY (id);


--
-- Name: bil_tenant_subscriptions bil_tenant_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_subscriptions
    ADD CONSTRAINT bil_tenant_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: bil_tenant_usage_metrics bil_tenant_usage_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_usage_metrics
    ADD CONSTRAINT bil_tenant_usage_metrics_pkey PRIMARY KEY (id);


--
-- Name: crm_contracts crm_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_contracts
    ADD CONSTRAINT crm_contracts_pkey PRIMARY KEY (id);


--
-- Name: crm_leads crm_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_pkey PRIMARY KEY (id);


--
-- Name: crm_opportunities crm_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_pkey PRIMARY KEY (id);


--
-- Name: dir_car_makes dir_car_makes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_car_makes
    ADD CONSTRAINT dir_car_makes_pkey PRIMARY KEY (id);


--
-- Name: dir_car_models dir_car_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_car_models
    ADD CONSTRAINT dir_car_models_pkey PRIMARY KEY (id);


--
-- Name: dir_country_regulations dir_country_regulations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_country_regulations
    ADD CONSTRAINT dir_country_regulations_pkey PRIMARY KEY (country_code);


--
-- Name: dir_platforms dir_platforms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_platforms
    ADD CONSTRAINT dir_platforms_pkey PRIMARY KEY (id);


--
-- Name: dir_vehicle_classes dir_vehicle_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_vehicle_classes
    ADD CONSTRAINT dir_vehicle_classes_pkey PRIMARY KEY (id);


--
-- Name: doc_documents doc_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doc_documents
    ADD CONSTRAINT doc_documents_pkey PRIMARY KEY (id);


--
-- Name: fin_accounts fin_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_pkey PRIMARY KEY (id);


--
-- Name: fin_driver_payment_batches fin_driver_payment_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payment_batches
    ADD CONSTRAINT fin_driver_payment_batches_pkey PRIMARY KEY (id);


--
-- Name: fin_driver_payments fin_driver_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_pkey PRIMARY KEY (id);


--
-- Name: fin_toll_transactions fin_toll_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_pkey PRIMARY KEY (id);


--
-- Name: fin_traffic_fines fin_traffic_fines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_pkey PRIMARY KEY (id);


--
-- Name: fin_transactions fin_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_pkey PRIMARY KEY (id);


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_pkey PRIMARY KEY (id);


--
-- Name: flt_vehicle_events flt_vehicle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_events
    ADD CONSTRAINT flt_vehicle_events_pkey PRIMARY KEY (id);


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_pkey PRIMARY KEY (id);


--
-- Name: flt_vehicle_insurances flt_vehicle_insurances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_insurances
    ADD CONSTRAINT flt_vehicle_insurances_pkey PRIMARY KEY (id);


--
-- Name: flt_vehicle_maintenance flt_vehicle_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_maintenance
    ADD CONSTRAINT flt_vehicle_maintenance_pkey PRIMARY KEY (id);


--
-- Name: flt_vehicles flt_vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_pkey PRIMARY KEY (id);


--
-- Name: rev_driver_revenues rev_driver_revenues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_driver_revenues
    ADD CONSTRAINT rev_driver_revenues_pkey PRIMARY KEY (id);


--
-- Name: rev_reconciliations rev_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_reconciliations
    ADD CONSTRAINT rev_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: rev_revenue_imports rev_revenue_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_revenue_imports
    ADD CONSTRAINT rev_revenue_imports_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_blacklists rid_driver_blacklists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_blacklists
    ADD CONSTRAINT rid_driver_blacklists_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_cooperation_terms rid_driver_cooperation_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_cooperation_terms
    ADD CONSTRAINT rid_driver_cooperation_terms_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_documents rid_driver_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_languages rid_driver_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_languages
    ADD CONSTRAINT rid_driver_languages_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_performances rid_driver_performances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_performances
    ADD CONSTRAINT rid_driver_performances_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_requests rid_driver_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_requests
    ADD CONSTRAINT rid_driver_requests_pkey PRIMARY KEY (id);


--
-- Name: rid_driver_training rid_driver_training_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_training
    ADD CONSTRAINT rid_driver_training_pkey PRIMARY KEY (id);


--
-- Name: rid_drivers rid_drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_drivers
    ADD CONSTRAINT rid_drivers_pkey PRIMARY KEY (id);


--
-- Name: sch_goals sch_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_goals
    ADD CONSTRAINT sch_goals_pkey PRIMARY KEY (id);


--
-- Name: sch_maintenance_schedules sch_maintenance_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_maintenance_schedules
    ADD CONSTRAINT sch_maintenance_schedules_pkey PRIMARY KEY (id);


--
-- Name: sch_shifts sch_shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_shifts
    ADD CONSTRAINT sch_shifts_pkey PRIMARY KEY (id);


--
-- Name: sch_tasks sch_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_tasks
    ADD CONSTRAINT sch_tasks_pkey PRIMARY KEY (id);


--
-- Name: sup_customer_feedback sup_customer_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_customer_feedback
    ADD CONSTRAINT sup_customer_feedback_pkey PRIMARY KEY (id);


--
-- Name: sup_ticket_messages sup_ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_ticket_messages
    ADD CONSTRAINT sup_ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: sup_tickets sup_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_tickets
    ADD CONSTRAINT sup_tickets_pkey PRIMARY KEY (id);


--
-- Name: trp_client_invoices trp_client_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_client_invoices
    ADD CONSTRAINT trp_client_invoices_pkey PRIMARY KEY (id);


--
-- Name: trp_platform_accounts trp_platform_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_platform_accounts
    ADD CONSTRAINT trp_platform_accounts_pkey PRIMARY KEY (id);


--
-- Name: trp_settlements trp_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_settlements
    ADD CONSTRAINT trp_settlements_pkey PRIMARY KEY (id);


--
-- Name: trp_trips trp_trips_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_trips
    ADD CONSTRAINT trp_trips_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: adm_audit_logs_changes_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_audit_logs_changes_gin ON public.adm_audit_logs USING gin (changes);


--
-- Name: adm_audit_logs_changes_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_audit_logs_changes_idx ON public.adm_audit_logs USING gin (changes);


--
-- Name: adm_audit_logs_tenant_entity_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_audit_logs_tenant_entity_entity_id_idx ON public.adm_audit_logs USING btree (tenant_id, entity, entity_id);


--
-- Name: adm_audit_logs_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_audit_logs_tenant_id_idx ON public.adm_audit_logs USING btree (tenant_id);


--
-- Name: adm_audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_audit_logs_timestamp_idx ON public.adm_audit_logs USING btree ("timestamp" DESC);


--
-- Name: adm_member_roles_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_member_roles_created_by_idx ON public.adm_member_roles USING btree (created_by);


--
-- Name: adm_member_roles_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_member_roles_deleted_at_idx ON public.adm_member_roles USING btree (deleted_at);


--
-- Name: adm_member_roles_member_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_member_roles_member_id_idx ON public.adm_member_roles USING btree (member_id);


--
-- Name: adm_member_roles_role_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_member_roles_role_id_idx ON public.adm_member_roles USING btree (role_id);


--
-- Name: adm_member_roles_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_member_roles_tenant_id_idx ON public.adm_member_roles USING btree (tenant_id);


--
-- Name: adm_member_roles_tenant_id_member_id_role_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX adm_member_roles_tenant_id_member_id_role_id_key ON public.adm_member_roles USING btree (tenant_id, member_id, role_id) WHERE (deleted_at IS NULL);


--
-- Name: adm_member_roles_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_member_roles_updated_by_idx ON public.adm_member_roles USING btree (updated_by);


--
-- Name: adm_members_clerk_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_clerk_user_id_idx ON public.adm_members USING btree (clerk_user_id);


--
-- Name: adm_members_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_created_by_idx ON public.adm_members USING btree (created_by);


--
-- Name: adm_members_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_deleted_at_idx ON public.adm_members USING btree (deleted_at);


--
-- Name: adm_members_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_email_idx ON public.adm_members USING btree (email);


--
-- Name: adm_members_last_login_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_last_login_at_idx ON public.adm_members USING btree (last_login_at);


--
-- Name: adm_members_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_metadata_gin ON public.adm_members USING gin (metadata);


--
-- Name: adm_members_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_metadata_idx ON public.adm_members USING gin (metadata);


--
-- Name: adm_members_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_status_active_idx ON public.adm_members USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: adm_members_tenant_clerk_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX adm_members_tenant_clerk_uq ON public.adm_members USING btree (tenant_id, clerk_user_id) WHERE (deleted_at IS NULL);


--
-- Name: adm_members_tenant_email_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX adm_members_tenant_email_uq ON public.adm_members USING btree (tenant_id, email) WHERE (deleted_at IS NULL);


--
-- Name: adm_members_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_tenant_id_idx ON public.adm_members USING btree (tenant_id);


--
-- Name: adm_members_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_members_updated_by_idx ON public.adm_members USING btree (updated_by);


--
-- Name: adm_provider_employees_clerk_user_id_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX adm_provider_employees_clerk_user_id_uq ON public.adm_provider_employees USING btree (clerk_user_id) WHERE (deleted_at IS NULL);


--
-- Name: adm_provider_employees_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_provider_employees_created_by_idx ON public.adm_provider_employees USING btree (created_by);


--
-- Name: adm_provider_employees_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_provider_employees_deleted_at_idx ON public.adm_provider_employees USING btree (deleted_at);


--
-- Name: adm_provider_employees_email_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX adm_provider_employees_email_uq ON public.adm_provider_employees USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: adm_provider_employees_permissions_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_provider_employees_permissions_gin ON public.adm_provider_employees USING gin (permissions);


--
-- Name: adm_provider_employees_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_provider_employees_status_active_idx ON public.adm_provider_employees USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: adm_provider_employees_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_provider_employees_updated_by_idx ON public.adm_provider_employees USING btree (updated_by);


--
-- Name: adm_roles_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_roles_created_by_idx ON public.adm_roles USING btree (created_by);


--
-- Name: adm_roles_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_roles_deleted_at_idx ON public.adm_roles USING btree (deleted_at);


--
-- Name: adm_roles_permissions_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_roles_permissions_gin ON public.adm_roles USING gin (permissions);


--
-- Name: adm_roles_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_roles_status_active_idx ON public.adm_roles USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: adm_roles_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_roles_tenant_id_idx ON public.adm_roles USING btree (tenant_id);


--
-- Name: adm_roles_tenant_name_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX adm_roles_tenant_name_uq ON public.adm_roles USING btree (tenant_id, name) WHERE (deleted_at IS NULL);


--
-- Name: adm_roles_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_roles_updated_by_idx ON public.adm_roles USING btree (updated_by);


--
-- Name: adm_tenant_lifecycle_events_effective_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenant_lifecycle_events_effective_date_idx ON public.adm_tenant_lifecycle_events USING btree (effective_date DESC);


--
-- Name: adm_tenant_lifecycle_events_event_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenant_lifecycle_events_event_type_idx ON public.adm_tenant_lifecycle_events USING btree (event_type);


--
-- Name: adm_tenant_lifecycle_events_tenant_event_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenant_lifecycle_events_tenant_event_idx ON public.adm_tenant_lifecycle_events USING btree (tenant_id, event_type);


--
-- Name: adm_tenant_lifecycle_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenant_lifecycle_events_tenant_id_idx ON public.adm_tenant_lifecycle_events USING btree (tenant_id);


--
-- Name: adm_tenants_clerk_organization_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenants_clerk_organization_id_idx ON public.adm_tenants USING btree (clerk_organization_id);


--
-- Name: adm_tenants_country_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenants_country_code_idx ON public.adm_tenants USING btree (country_code);


--
-- Name: adm_tenants_default_currency_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenants_default_currency_idx ON public.adm_tenants USING btree (default_currency);


--
-- Name: adm_tenants_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX adm_tenants_deleted_at_idx ON public.adm_tenants USING btree (deleted_at);


--
-- Name: bil_billing_plans_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_billing_plans_created_by_idx ON public.bil_billing_plans USING btree (created_by);


--
-- Name: bil_billing_plans_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_billing_plans_deleted_at_idx ON public.bil_billing_plans USING btree (deleted_at);


--
-- Name: bil_billing_plans_features_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_billing_plans_features_idx ON public.bil_billing_plans USING gin (features);


--
-- Name: bil_billing_plans_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_billing_plans_metadata_idx ON public.bil_billing_plans USING gin (metadata);


--
-- Name: bil_billing_plans_plan_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bil_billing_plans_plan_name_key ON public.bil_billing_plans USING btree (plan_name) WHERE (deleted_at IS NULL);


--
-- Name: bil_billing_plans_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_billing_plans_status_idx ON public.bil_billing_plans USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: bil_billing_plans_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_billing_plans_updated_by_idx ON public.bil_billing_plans USING btree (updated_by);


--
-- Name: bil_payment_methods_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_created_by_idx ON public.bil_payment_methods USING btree (created_by);


--
-- Name: bil_payment_methods_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_deleted_at_idx ON public.bil_payment_methods USING btree (deleted_at);


--
-- Name: bil_payment_methods_expires_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_expires_at_idx ON public.bil_payment_methods USING btree (expires_at);


--
-- Name: bil_payment_methods_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_metadata_idx ON public.bil_payment_methods USING gin (metadata);


--
-- Name: bil_payment_methods_payment_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_payment_type_idx ON public.bil_payment_methods USING btree (payment_type);


--
-- Name: bil_payment_methods_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_status_active_idx ON public.bil_payment_methods USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: bil_payment_methods_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_tenant_id_idx ON public.bil_payment_methods USING btree (tenant_id);


--
-- Name: bil_payment_methods_tenant_id_payment_type_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bil_payment_methods_tenant_id_payment_type_unique ON public.bil_payment_methods USING btree (tenant_id, payment_type) WHERE (deleted_at IS NULL);


--
-- Name: bil_payment_methods_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_payment_methods_updated_by_idx ON public.bil_payment_methods USING btree (updated_by);


--
-- Name: bil_tenant_invoice_lines_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoice_lines_created_by_idx ON public.bil_tenant_invoice_lines USING btree (created_by);


--
-- Name: bil_tenant_invoice_lines_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoice_lines_deleted_at_idx ON public.bil_tenant_invoice_lines USING btree (deleted_at);


--
-- Name: bil_tenant_invoice_lines_description_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoice_lines_description_idx ON public.bil_tenant_invoice_lines USING btree (description);


--
-- Name: bil_tenant_invoice_lines_invoice_id_description_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bil_tenant_invoice_lines_invoice_id_description_unique ON public.bil_tenant_invoice_lines USING btree (invoice_id, description) WHERE (deleted_at IS NULL);


--
-- Name: bil_tenant_invoice_lines_invoice_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoice_lines_invoice_id_idx ON public.bil_tenant_invoice_lines USING btree (invoice_id);


--
-- Name: bil_tenant_invoice_lines_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoice_lines_metadata_idx ON public.bil_tenant_invoice_lines USING gin (metadata);


--
-- Name: bil_tenant_invoice_lines_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoice_lines_updated_by_idx ON public.bil_tenant_invoice_lines USING btree (updated_by);


--
-- Name: bil_tenant_invoices_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_created_by_idx ON public.bil_tenant_invoices USING btree (created_by);


--
-- Name: bil_tenant_invoices_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_deleted_at_idx ON public.bil_tenant_invoices USING btree (deleted_at);


--
-- Name: bil_tenant_invoices_due_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_due_date_idx ON public.bil_tenant_invoices USING btree (due_date);


--
-- Name: bil_tenant_invoices_invoice_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_invoice_date_idx ON public.bil_tenant_invoices USING btree (invoice_date);


--
-- Name: bil_tenant_invoices_invoice_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_invoice_number_idx ON public.bil_tenant_invoices USING btree (invoice_number);


--
-- Name: bil_tenant_invoices_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_metadata_idx ON public.bil_tenant_invoices USING gin (metadata);


--
-- Name: bil_tenant_invoices_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_status_idx ON public.bil_tenant_invoices USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: bil_tenant_invoices_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_tenant_id_idx ON public.bil_tenant_invoices USING btree (tenant_id);


--
-- Name: bil_tenant_invoices_tenant_id_invoice_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bil_tenant_invoices_tenant_id_invoice_number_key ON public.bil_tenant_invoices USING btree (tenant_id, invoice_number) WHERE (deleted_at IS NULL);


--
-- Name: bil_tenant_invoices_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_invoices_updated_by_idx ON public.bil_tenant_invoices USING btree (updated_by);


--
-- Name: bil_tenant_subscriptions_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_created_by_idx ON public.bil_tenant_subscriptions USING btree (created_by);


--
-- Name: bil_tenant_subscriptions_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_deleted_at_idx ON public.bil_tenant_subscriptions USING btree (deleted_at);


--
-- Name: bil_tenant_subscriptions_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_metadata_idx ON public.bil_tenant_subscriptions USING gin (metadata);


--
-- Name: bil_tenant_subscriptions_plan_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_plan_id_idx ON public.bil_tenant_subscriptions USING btree (plan_id);


--
-- Name: bil_tenant_subscriptions_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_status_idx ON public.bil_tenant_subscriptions USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: bil_tenant_subscriptions_subscription_end_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_subscription_end_idx ON public.bil_tenant_subscriptions USING btree (subscription_end);


--
-- Name: bil_tenant_subscriptions_subscription_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_subscription_start_idx ON public.bil_tenant_subscriptions USING btree (subscription_start);


--
-- Name: bil_tenant_subscriptions_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_tenant_id_idx ON public.bil_tenant_subscriptions USING btree (tenant_id);


--
-- Name: bil_tenant_subscriptions_tenant_id_plan_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bil_tenant_subscriptions_tenant_id_plan_id_key ON public.bil_tenant_subscriptions USING btree (tenant_id, plan_id) WHERE (deleted_at IS NULL);


--
-- Name: bil_tenant_subscriptions_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_subscriptions_updated_by_idx ON public.bil_tenant_subscriptions USING btree (updated_by);


--
-- Name: bil_tenant_usage_metrics_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_created_by_idx ON public.bil_tenant_usage_metrics USING btree (created_by);


--
-- Name: bil_tenant_usage_metrics_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_deleted_at_idx ON public.bil_tenant_usage_metrics USING btree (deleted_at);


--
-- Name: bil_tenant_usage_metrics_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_metadata_idx ON public.bil_tenant_usage_metrics USING gin (metadata);


--
-- Name: bil_tenant_usage_metrics_metric_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_metric_name_idx ON public.bil_tenant_usage_metrics USING btree (metric_name);


--
-- Name: bil_tenant_usage_metrics_period_end_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_period_end_idx ON public.bil_tenant_usage_metrics USING btree (period_end);


--
-- Name: bil_tenant_usage_metrics_period_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_period_start_idx ON public.bil_tenant_usage_metrics USING btree (period_start);


--
-- Name: bil_tenant_usage_metrics_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_tenant_id_idx ON public.bil_tenant_usage_metrics USING btree (tenant_id);


--
-- Name: bil_tenant_usage_metrics_tenant_id_metric_name_period_start_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX bil_tenant_usage_metrics_tenant_id_metric_name_period_start_key ON public.bil_tenant_usage_metrics USING btree (tenant_id, metric_name, period_start) WHERE (deleted_at IS NULL);


--
-- Name: bil_tenant_usage_metrics_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bil_tenant_usage_metrics_updated_by_idx ON public.bil_tenant_usage_metrics USING btree (updated_by);


--
-- Name: crm_contracts_client_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_client_id_idx ON public.crm_contracts USING btree (lead_id);


--
-- Name: crm_contracts_contract_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_contract_date_idx ON public.crm_contracts USING btree (contract_date);


--
-- Name: crm_contracts_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_created_by_idx ON public.crm_contracts USING btree (created_by);


--
-- Name: crm_contracts_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_deleted_at_idx ON public.crm_contracts USING btree (deleted_at);


--
-- Name: crm_contracts_effective_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_effective_date_idx ON public.crm_contracts USING btree (effective_date);


--
-- Name: crm_contracts_expiry_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_expiry_date_idx ON public.crm_contracts USING btree (expiry_date);


--
-- Name: crm_contracts_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_metadata_idx ON public.crm_contracts USING gin (metadata);


--
-- Name: crm_contracts_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_status_active_idx ON public.crm_contracts USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: crm_contracts_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_contracts_updated_by_idx ON public.crm_contracts USING btree (updated_by);


--
-- Name: crm_leads_assigned_to_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_leads_assigned_to_idx ON public.crm_leads USING btree (assigned_to) WHERE (deleted_at IS NULL);


--
-- Name: crm_leads_country_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_leads_country_code_idx ON public.crm_leads USING btree (country_code) WHERE (deleted_at IS NULL);


--
-- Name: crm_leads_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_leads_created_at_idx ON public.crm_leads USING btree (created_at DESC);


--
-- Name: crm_leads_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_leads_deleted_at_idx ON public.crm_leads USING btree (deleted_at);


--
-- Name: crm_leads_email_unique_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX crm_leads_email_unique_active ON public.crm_leads USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: crm_leads_notes_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_leads_notes_gin ON public.crm_leads USING gin (to_tsvector('english'::regconfig, COALESCE(message, ''::text)));


--
-- Name: crm_leads_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_leads_status_idx ON public.crm_leads USING btree (status);


--
-- Name: crm_opportunities_assigned_to_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_assigned_to_idx ON public.crm_opportunities USING btree (assigned_to);


--
-- Name: crm_opportunities_close_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_close_date_idx ON public.crm_opportunities USING btree (close_date);


--
-- Name: crm_opportunities_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_created_by_idx ON public.crm_opportunities USING btree (created_by);


--
-- Name: crm_opportunities_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_deleted_at_idx ON public.crm_opportunities USING btree (deleted_at);


--
-- Name: crm_opportunities_lead_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_lead_id_idx ON public.crm_opportunities USING btree (lead_id);


--
-- Name: crm_opportunities_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_metadata_idx ON public.crm_opportunities USING gin (metadata);


--
-- Name: crm_opportunities_opportunity_stage_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_opportunity_stage_idx ON public.crm_opportunities USING btree (stage) WHERE (deleted_at IS NULL);


--
-- Name: crm_opportunities_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crm_opportunities_updated_by_idx ON public.crm_opportunities USING btree (updated_by);


--
-- Name: dir_car_makes_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_makes_created_at_idx ON public.dir_car_makes USING btree (created_at);


--
-- Name: dir_car_makes_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_makes_tenant_id_idx ON public.dir_car_makes USING btree (tenant_id);


--
-- Name: dir_car_makes_tenant_name_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dir_car_makes_tenant_name_uq ON public.dir_car_makes USING btree (tenant_id, name);


--
-- Name: dir_car_makes_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_makes_updated_at_idx ON public.dir_car_makes USING btree (updated_at);


--
-- Name: dir_car_models_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_models_created_at_idx ON public.dir_car_models USING btree (created_at);


--
-- Name: dir_car_models_make_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_models_make_id_idx ON public.dir_car_models USING btree (make_id);


--
-- Name: dir_car_models_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_models_tenant_id_idx ON public.dir_car_models USING btree (tenant_id);


--
-- Name: dir_car_models_tenant_make_name_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dir_car_models_tenant_make_name_uq ON public.dir_car_models USING btree (tenant_id, make_id, name);


--
-- Name: dir_car_models_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_models_updated_at_idx ON public.dir_car_models USING btree (updated_at);


--
-- Name: dir_car_models_vehicle_class_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_car_models_vehicle_class_id_idx ON public.dir_car_models USING btree (vehicle_class_id);


--
-- Name: dir_country_regulations_currency_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_country_regulations_currency_idx ON public.dir_country_regulations USING btree (currency);


--
-- Name: dir_country_regulations_timezone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_country_regulations_timezone_idx ON public.dir_country_regulations USING btree (timezone);


--
-- Name: dir_platforms_api_config_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_platforms_api_config_gin ON public.dir_platforms USING gin (api_config);


--
-- Name: dir_platforms_name_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dir_platforms_name_uq ON public.dir_platforms USING btree (name);


--
-- Name: dir_vehicle_classes_country_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_vehicle_classes_country_code_idx ON public.dir_vehicle_classes USING btree (country_code);


--
-- Name: dir_vehicle_classes_country_name_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX dir_vehicle_classes_country_name_uq ON public.dir_vehicle_classes USING btree (country_code, name);


--
-- Name: dir_vehicle_classes_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_vehicle_classes_created_at_idx ON public.dir_vehicle_classes USING btree (created_at);


--
-- Name: dir_vehicle_classes_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dir_vehicle_classes_updated_at_idx ON public.dir_vehicle_classes USING btree (updated_at);


--
-- Name: doc_documents_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_created_at_idx ON public.doc_documents USING btree (created_at);


--
-- Name: doc_documents_document_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_document_type_idx ON public.doc_documents USING btree (document_type);


--
-- Name: doc_documents_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_entity_id_idx ON public.doc_documents USING btree (entity_id);


--
-- Name: doc_documents_entity_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_entity_type_idx ON public.doc_documents USING btree (entity_type);


--
-- Name: doc_documents_expiry_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_expiry_date_idx ON public.doc_documents USING btree (expiry_date);


--
-- Name: doc_documents_tenant_document_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_tenant_document_type_idx ON public.doc_documents USING btree (tenant_id, document_type);


--
-- Name: doc_documents_tenant_entity_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_tenant_entity_idx ON public.doc_documents USING btree (tenant_id, entity_type, entity_id);


--
-- Name: doc_documents_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_tenant_id_idx ON public.doc_documents USING btree (tenant_id);


--
-- Name: doc_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX doc_documents_updated_at_idx ON public.doc_documents USING btree (updated_at);


--
-- Name: fin_driver_payment_batches_batch_reference_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_batch_reference_idx ON public.fin_driver_payment_batches USING btree (batch_reference);


--
-- Name: fin_driver_payment_batches_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_created_by_idx ON public.fin_driver_payment_batches USING btree (created_by);


--
-- Name: fin_driver_payment_batches_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_deleted_at_idx ON public.fin_driver_payment_batches USING btree (deleted_at);


--
-- Name: fin_driver_payment_batches_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_metadata_idx ON public.fin_driver_payment_batches USING gin (metadata);


--
-- Name: fin_driver_payment_batches_payment_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_payment_date_idx ON public.fin_driver_payment_batches USING btree (payment_date DESC);


--
-- Name: fin_driver_payment_batches_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_status_active_idx ON public.fin_driver_payment_batches USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: fin_driver_payment_batches_tenant_batch_ref_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fin_driver_payment_batches_tenant_batch_ref_unique ON public.fin_driver_payment_batches USING btree (tenant_id, batch_reference) WHERE (deleted_at IS NULL);


--
-- Name: fin_driver_payment_batches_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_tenant_id_idx ON public.fin_driver_payment_batches USING btree (tenant_id);


--
-- Name: fin_driver_payment_batches_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payment_batches_updated_by_idx ON public.fin_driver_payment_batches USING btree (updated_by);


--
-- Name: fin_driver_payments_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_created_by_idx ON public.fin_driver_payments USING btree (created_by);


--
-- Name: fin_driver_payments_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_deleted_at_idx ON public.fin_driver_payments USING btree (deleted_at);


--
-- Name: fin_driver_payments_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_driver_id_idx ON public.fin_driver_payments USING btree (driver_id);


--
-- Name: fin_driver_payments_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_metadata_idx ON public.fin_driver_payments USING gin (metadata);


--
-- Name: fin_driver_payments_payment_batch_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_payment_batch_id_idx ON public.fin_driver_payments USING btree (payment_batch_id);


--
-- Name: fin_driver_payments_payment_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_payment_date_idx ON public.fin_driver_payments USING btree (payment_date DESC);


--
-- Name: fin_driver_payments_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_status_active_idx ON public.fin_driver_payments USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: fin_driver_payments_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_tenant_id_idx ON public.fin_driver_payments USING btree (tenant_id);


--
-- Name: fin_driver_payments_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_driver_payments_updated_by_idx ON public.fin_driver_payments USING btree (updated_by);


--
-- Name: fin_toll_transactions_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_created_by_idx ON public.fin_toll_transactions USING btree (created_by);


--
-- Name: fin_toll_transactions_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_deleted_at_idx ON public.fin_toll_transactions USING btree (deleted_at);


--
-- Name: fin_toll_transactions_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_driver_id_idx ON public.fin_toll_transactions USING btree (driver_id);


--
-- Name: fin_toll_transactions_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_metadata_idx ON public.fin_toll_transactions USING gin (metadata);


--
-- Name: fin_toll_transactions_tenant_driver_vehicle_date_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fin_toll_transactions_tenant_driver_vehicle_date_unique ON public.fin_toll_transactions USING btree (tenant_id, driver_id, vehicle_id, toll_date) WHERE (deleted_at IS NULL);


--
-- Name: fin_toll_transactions_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_tenant_id_idx ON public.fin_toll_transactions USING btree (tenant_id);


--
-- Name: fin_toll_transactions_toll_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_toll_date_idx ON public.fin_toll_transactions USING btree (toll_date DESC);


--
-- Name: fin_toll_transactions_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_updated_by_idx ON public.fin_toll_transactions USING btree (updated_by);


--
-- Name: fin_toll_transactions_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_toll_transactions_vehicle_id_idx ON public.fin_toll_transactions USING btree (vehicle_id);


--
-- Name: fin_traffic_fines_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_created_by_idx ON public.fin_traffic_fines USING btree (created_by);


--
-- Name: fin_traffic_fines_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_deleted_at_idx ON public.fin_traffic_fines USING btree (deleted_at);


--
-- Name: fin_traffic_fines_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_driver_id_idx ON public.fin_traffic_fines USING btree (driver_id);


--
-- Name: fin_traffic_fines_fine_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_fine_date_idx ON public.fin_traffic_fines USING btree (fine_date DESC);


--
-- Name: fin_traffic_fines_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_metadata_idx ON public.fin_traffic_fines USING gin (metadata);


--
-- Name: fin_traffic_fines_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_status_active_idx ON public.fin_traffic_fines USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: fin_traffic_fines_tenant_id_fine_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX fin_traffic_fines_tenant_id_fine_reference_key ON public.fin_traffic_fines USING btree (tenant_id, fine_reference) WHERE (deleted_at IS NULL);


--
-- Name: fin_traffic_fines_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_tenant_id_idx ON public.fin_traffic_fines USING btree (tenant_id);


--
-- Name: fin_traffic_fines_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_updated_by_idx ON public.fin_traffic_fines USING btree (updated_by);


--
-- Name: fin_traffic_fines_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_traffic_fines_vehicle_id_idx ON public.fin_traffic_fines USING btree (vehicle_id);


--
-- Name: fin_transactions_account_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_account_id_idx ON public.fin_transactions USING btree (account_id);


--
-- Name: fin_transactions_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_created_by_idx ON public.fin_transactions USING btree (created_by);


--
-- Name: fin_transactions_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_deleted_at_idx ON public.fin_transactions USING btree (deleted_at);


--
-- Name: fin_transactions_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_metadata_idx ON public.fin_transactions USING gin (metadata);


--
-- Name: fin_transactions_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_status_active_idx ON public.fin_transactions USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: fin_transactions_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_tenant_id_idx ON public.fin_transactions USING btree (tenant_id);


--
-- Name: fin_transactions_transaction_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_transaction_date_idx ON public.fin_transactions USING btree (transaction_date DESC);


--
-- Name: fin_transactions_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fin_transactions_updated_by_idx ON public.fin_transactions USING btree (updated_by);


--
-- Name: flt_vehicle_assignments_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_created_by_idx ON public.flt_vehicle_assignments USING btree (created_by);


--
-- Name: flt_vehicle_assignments_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_deleted_at_idx ON public.flt_vehicle_assignments USING btree (deleted_at);


--
-- Name: flt_vehicle_assignments_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_driver_id_idx ON public.flt_vehicle_assignments USING btree (driver_id);


--
-- Name: flt_vehicle_assignments_end_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_end_date_idx ON public.flt_vehicle_assignments USING btree (end_date);


--
-- Name: flt_vehicle_assignments_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_metadata_idx ON public.flt_vehicle_assignments USING gin (metadata);


--
-- Name: flt_vehicle_assignments_start_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_start_date_idx ON public.flt_vehicle_assignments USING btree (start_date);


--
-- Name: flt_vehicle_assignments_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_status_active_idx ON public.flt_vehicle_assignments USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_assignments_tenant_driver_vehicle_start_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX flt_vehicle_assignments_tenant_driver_vehicle_start_uq ON public.flt_vehicle_assignments USING btree (tenant_id, driver_id, vehicle_id, start_date) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_assignments_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_tenant_id_idx ON public.flt_vehicle_assignments USING btree (tenant_id);


--
-- Name: flt_vehicle_assignments_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_updated_by_idx ON public.flt_vehicle_assignments USING btree (updated_by);


--
-- Name: flt_vehicle_assignments_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_assignments_vehicle_id_idx ON public.flt_vehicle_assignments USING btree (vehicle_id);


--
-- Name: flt_vehicle_events_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_created_at_idx ON public.flt_vehicle_events USING btree (created_at DESC);


--
-- Name: flt_vehicle_events_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_created_by_idx ON public.flt_vehicle_events USING btree (created_by);


--
-- Name: flt_vehicle_events_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_deleted_at_idx ON public.flt_vehicle_events USING btree (deleted_at);


--
-- Name: flt_vehicle_events_details_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_details_idx ON public.flt_vehicle_events USING gin (details);


--
-- Name: flt_vehicle_events_event_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_event_date_idx ON public.flt_vehicle_events USING btree (event_date);


--
-- Name: flt_vehicle_events_event_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_event_type_idx ON public.flt_vehicle_events USING btree (event_type);


--
-- Name: flt_vehicle_events_severity_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_severity_active_idx ON public.flt_vehicle_events USING btree (severity) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_tenant_id_idx ON public.flt_vehicle_events USING btree (tenant_id);


--
-- Name: flt_vehicle_events_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_updated_by_idx ON public.flt_vehicle_events USING btree (updated_by);


--
-- Name: flt_vehicle_events_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_events_vehicle_id_idx ON public.flt_vehicle_events USING btree (vehicle_id);


--
-- Name: flt_vehicle_expenses_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_created_at_idx ON public.flt_vehicle_expenses USING btree (created_at DESC);


--
-- Name: flt_vehicle_expenses_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_created_by_idx ON public.flt_vehicle_expenses USING btree (created_by);


--
-- Name: flt_vehicle_expenses_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_deleted_at_idx ON public.flt_vehicle_expenses USING btree (deleted_at);


--
-- Name: flt_vehicle_expenses_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_driver_id_idx ON public.flt_vehicle_expenses USING btree (driver_id);


--
-- Name: flt_vehicle_expenses_expense_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_expense_category_idx ON public.flt_vehicle_expenses USING btree (expense_category);


--
-- Name: flt_vehicle_expenses_expense_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_expense_date_idx ON public.flt_vehicle_expenses USING btree (expense_date);


--
-- Name: flt_vehicle_expenses_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_metadata_idx ON public.flt_vehicle_expenses USING gin (metadata);


--
-- Name: flt_vehicle_expenses_reimbursed_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_reimbursed_active_idx ON public.flt_vehicle_expenses USING btree (reimbursed) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_expenses_reimbursed_pending_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_reimbursed_pending_idx ON public.flt_vehicle_expenses USING btree (reimbursed) WHERE ((deleted_at IS NULL) AND (reimbursed = false));


--
-- Name: flt_vehicle_expenses_ride_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_ride_id_idx ON public.flt_vehicle_expenses USING btree (ride_id);


--
-- Name: flt_vehicle_expenses_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_tenant_id_idx ON public.flt_vehicle_expenses USING btree (tenant_id);


--
-- Name: flt_vehicle_expenses_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_updated_by_idx ON public.flt_vehicle_expenses USING btree (updated_by);


--
-- Name: flt_vehicle_expenses_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_expenses_vehicle_id_idx ON public.flt_vehicle_expenses USING btree (vehicle_id);


--
-- Name: flt_vehicle_insurances_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_created_at_idx ON public.flt_vehicle_insurances USING btree (created_at DESC);


--
-- Name: flt_vehicle_insurances_end_date_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_end_date_active_idx ON public.flt_vehicle_insurances USING btree (end_date) WHERE ((deleted_at IS NULL) AND (is_active = true));


--
-- Name: flt_vehicle_insurances_is_active_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_is_active_active_idx ON public.flt_vehicle_insurances USING btree (is_active) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_insurances_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_is_active_idx ON public.flt_vehicle_insurances USING btree (is_active) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_insurances_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_metadata_idx ON public.flt_vehicle_insurances USING gin (metadata);


--
-- Name: flt_vehicle_insurances_policy_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_policy_number_idx ON public.flt_vehicle_insurances USING btree (policy_number);


--
-- Name: flt_vehicle_insurances_policy_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_policy_type_idx ON public.flt_vehicle_insurances USING btree (policy_type);


--
-- Name: flt_vehicle_insurances_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_tenant_id_idx ON public.flt_vehicle_insurances USING btree (tenant_id);


--
-- Name: flt_vehicle_insurances_tenant_policy_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX flt_vehicle_insurances_tenant_policy_uq ON public.flt_vehicle_insurances USING btree (tenant_id, policy_number) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicle_insurances_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_insurances_vehicle_id_idx ON public.flt_vehicle_insurances USING btree (vehicle_id);


--
-- Name: flt_vehicle_maintenance_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_created_at_idx ON public.flt_vehicle_maintenance USING btree (created_at DESC);


--
-- Name: flt_vehicle_maintenance_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_created_by_idx ON public.flt_vehicle_maintenance USING btree (created_by);


--
-- Name: flt_vehicle_maintenance_maintenance_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_maintenance_type_idx ON public.flt_vehicle_maintenance USING btree (maintenance_type);


--
-- Name: flt_vehicle_maintenance_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_metadata_idx ON public.flt_vehicle_maintenance USING gin (metadata);


--
-- Name: flt_vehicle_maintenance_next_service_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_next_service_idx ON public.flt_vehicle_maintenance USING btree (next_service_date) WHERE (status = 'completed'::text);


--
-- Name: flt_vehicle_maintenance_scheduled_date_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_scheduled_date_active_idx ON public.flt_vehicle_maintenance USING btree (scheduled_date);


--
-- Name: flt_vehicle_maintenance_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_status_active_idx ON public.flt_vehicle_maintenance USING btree (status);


--
-- Name: flt_vehicle_maintenance_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_tenant_id_idx ON public.flt_vehicle_maintenance USING btree (tenant_id);


--
-- Name: flt_vehicle_maintenance_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_updated_by_idx ON public.flt_vehicle_maintenance USING btree (updated_by);


--
-- Name: flt_vehicle_maintenance_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicle_maintenance_vehicle_id_idx ON public.flt_vehicle_maintenance USING btree (vehicle_id);


--
-- Name: flt_vehicles_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_created_by_idx ON public.flt_vehicles USING btree (created_by);


--
-- Name: flt_vehicles_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_deleted_at_idx ON public.flt_vehicles USING btree (deleted_at);


--
-- Name: flt_vehicles_license_plate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_license_plate_idx ON public.flt_vehicles USING btree (license_plate);


--
-- Name: flt_vehicles_make_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_make_id_idx ON public.flt_vehicles USING btree (make_id);


--
-- Name: flt_vehicles_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_metadata_idx ON public.flt_vehicles USING gin (metadata);


--
-- Name: flt_vehicles_model_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_model_id_idx ON public.flt_vehicles USING btree (model_id);


--
-- Name: flt_vehicles_next_inspection_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_next_inspection_idx ON public.flt_vehicles USING btree (next_inspection);


--
-- Name: flt_vehicles_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_status_active_idx ON public.flt_vehicles USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicles_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_tenant_id_idx ON public.flt_vehicles USING btree (tenant_id);


--
-- Name: flt_vehicles_tenant_plate_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX flt_vehicles_tenant_plate_uq ON public.flt_vehicles USING btree (tenant_id, license_plate) WHERE (deleted_at IS NULL);


--
-- Name: flt_vehicles_tenant_vin_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX flt_vehicles_tenant_vin_uq ON public.flt_vehicles USING btree (tenant_id, vin) WHERE ((deleted_at IS NULL) AND (vin IS NOT NULL));


--
-- Name: flt_vehicles_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_updated_by_idx ON public.flt_vehicles USING btree (updated_by);


--
-- Name: flt_vehicles_vin_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flt_vehicles_vin_idx ON public.flt_vehicles USING btree (vin);


--
-- Name: idx_fin_accounts_account_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_account_name ON public.fin_accounts USING btree (account_name);


--
-- Name: idx_fin_accounts_account_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_account_type ON public.fin_accounts USING btree (account_type);


--
-- Name: idx_fin_accounts_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_created_by ON public.fin_accounts USING btree (created_by);


--
-- Name: idx_fin_accounts_currency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_currency ON public.fin_accounts USING btree (currency);


--
-- Name: idx_fin_accounts_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_deleted_at ON public.fin_accounts USING btree (deleted_at);


--
-- Name: idx_fin_accounts_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_metadata ON public.fin_accounts USING gin (metadata);


--
-- Name: idx_fin_accounts_tenant_account_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_fin_accounts_tenant_account_unique ON public.fin_accounts USING btree (tenant_id, account_name) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_accounts_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_tenant_id ON public.fin_accounts USING btree (tenant_id);


--
-- Name: idx_fin_accounts_updated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_accounts_updated_by ON public.fin_accounts USING btree (updated_by);


--
-- Name: idx_sch_tasks_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_created_by ON public.sch_tasks USING btree (created_by);


--
-- Name: idx_sch_tasks_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_deleted_at ON public.sch_tasks USING btree (deleted_at);


--
-- Name: idx_sch_tasks_due_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_due_at ON public.sch_tasks USING btree (due_at);


--
-- Name: idx_sch_tasks_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_metadata ON public.sch_tasks USING gin (metadata);


--
-- Name: idx_sch_tasks_status_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_status_active ON public.sch_tasks USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: idx_sch_tasks_target_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_target_id ON public.sch_tasks USING btree (target_id);


--
-- Name: idx_sch_tasks_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_tenant_id ON public.sch_tasks USING btree (tenant_id);


--
-- Name: idx_sch_tasks_updated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sch_tasks_updated_by ON public.sch_tasks USING btree (updated_by);


--
-- Name: idx_trp_client_invoices_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_client_id ON public.trp_client_invoices USING btree (client_id);


--
-- Name: idx_trp_client_invoices_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_created_by ON public.trp_client_invoices USING btree (created_by);


--
-- Name: idx_trp_client_invoices_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_deleted_at ON public.trp_client_invoices USING btree (deleted_at);


--
-- Name: idx_trp_client_invoices_due_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_due_date ON public.trp_client_invoices USING btree (due_date);


--
-- Name: idx_trp_client_invoices_invoice_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_invoice_date ON public.trp_client_invoices USING btree (invoice_date);


--
-- Name: idx_trp_client_invoices_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_metadata ON public.trp_client_invoices USING gin (metadata);


--
-- Name: idx_trp_client_invoices_status_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_status_active ON public.trp_client_invoices USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: idx_trp_client_invoices_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_tenant_id ON public.trp_client_invoices USING btree (tenant_id);


--
-- Name: idx_trp_client_invoices_tenant_invoice_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_trp_client_invoices_tenant_invoice_unique ON public.trp_client_invoices USING btree (tenant_id, invoice_number) WHERE (deleted_at IS NULL);


--
-- Name: idx_trp_client_invoices_updated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_client_invoices_updated_by ON public.trp_client_invoices USING btree (updated_by);


--
-- Name: idx_trp_platform_accounts_account_identifier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_account_identifier ON public.trp_platform_accounts USING btree (account_identifier);


--
-- Name: idx_trp_platform_accounts_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_created_by ON public.trp_platform_accounts USING btree (created_by);


--
-- Name: idx_trp_platform_accounts_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_deleted_at ON public.trp_platform_accounts USING btree (deleted_at);


--
-- Name: idx_trp_platform_accounts_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_metadata ON public.trp_platform_accounts USING gin (metadata);


--
-- Name: idx_trp_platform_accounts_platform_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_platform_id ON public.trp_platform_accounts USING btree (platform_id);


--
-- Name: idx_trp_platform_accounts_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_tenant_id ON public.trp_platform_accounts USING btree (tenant_id);


--
-- Name: idx_trp_platform_accounts_tenant_platform_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_trp_platform_accounts_tenant_platform_unique ON public.trp_platform_accounts USING btree (tenant_id, platform_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_trp_platform_accounts_updated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_platform_accounts_updated_by ON public.trp_platform_accounts USING btree (updated_by);


--
-- Name: idx_trp_settlements_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_created_by ON public.trp_settlements USING btree (created_by);


--
-- Name: idx_trp_settlements_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_deleted_at ON public.trp_settlements USING btree (deleted_at);


--
-- Name: idx_trp_settlements_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_metadata ON public.trp_settlements USING gin (metadata);


--
-- Name: idx_trp_settlements_settlement_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_settlement_date ON public.trp_settlements USING btree (settlement_date);


--
-- Name: idx_trp_settlements_status_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_status_active ON public.trp_settlements USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: idx_trp_settlements_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_tenant_id ON public.trp_settlements USING btree (tenant_id);


--
-- Name: idx_trp_settlements_tenant_trip_ref_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_trp_settlements_tenant_trip_ref_unique ON public.trp_settlements USING btree (tenant_id, trip_id, settlement_reference) WHERE (deleted_at IS NULL);


--
-- Name: idx_trp_settlements_trip_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_trip_id ON public.trp_settlements USING btree (trip_id);


--
-- Name: idx_trp_settlements_updated_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trp_settlements_updated_by ON public.trp_settlements USING btree (updated_by);


--
-- Name: rev_driver_revenues_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_created_by_idx ON public.rev_driver_revenues USING btree (created_by);


--
-- Name: rev_driver_revenues_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_deleted_at_idx ON public.rev_driver_revenues USING btree (deleted_at);


--
-- Name: rev_driver_revenues_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_driver_id_idx ON public.rev_driver_revenues USING btree (driver_id);


--
-- Name: rev_driver_revenues_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_metadata_idx ON public.rev_driver_revenues USING gin (metadata);


--
-- Name: rev_driver_revenues_period_end_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_period_end_idx ON public.rev_driver_revenues USING btree (period_end DESC);


--
-- Name: rev_driver_revenues_period_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_period_start_idx ON public.rev_driver_revenues USING btree (period_start DESC);


--
-- Name: rev_driver_revenues_tenant_id_driver_id_period_start_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rev_driver_revenues_tenant_id_driver_id_period_start_key ON public.rev_driver_revenues USING btree (tenant_id, driver_id, period_start) WHERE (deleted_at IS NULL);


--
-- Name: rev_driver_revenues_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_tenant_id_idx ON public.rev_driver_revenues USING btree (tenant_id);


--
-- Name: rev_driver_revenues_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_driver_revenues_updated_by_idx ON public.rev_driver_revenues USING btree (updated_by);


--
-- Name: rev_reconciliations_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_created_by_idx ON public.rev_reconciliations USING btree (created_by);


--
-- Name: rev_reconciliations_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_deleted_at_idx ON public.rev_reconciliations USING btree (deleted_at);


--
-- Name: rev_reconciliations_import_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_import_id_idx ON public.rev_reconciliations USING btree (import_id);


--
-- Name: rev_reconciliations_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_metadata_idx ON public.rev_reconciliations USING gin (metadata);


--
-- Name: rev_reconciliations_reconciliation_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_reconciliation_date_idx ON public.rev_reconciliations USING btree (reconciliation_date DESC);


--
-- Name: rev_reconciliations_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_status_active_idx ON public.rev_reconciliations USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: rev_reconciliations_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_tenant_id_idx ON public.rev_reconciliations USING btree (tenant_id);


--
-- Name: rev_reconciliations_tenant_id_import_id_reconciliation_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rev_reconciliations_tenant_id_import_id_reconciliation_date_key ON public.rev_reconciliations USING btree (tenant_id, import_id, reconciliation_date) WHERE (deleted_at IS NULL);


--
-- Name: rev_reconciliations_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_reconciliations_updated_by_idx ON public.rev_reconciliations USING btree (updated_by);


--
-- Name: rev_revenue_imports_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_created_by_idx ON public.rev_revenue_imports USING btree (created_by);


--
-- Name: rev_revenue_imports_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_deleted_at_idx ON public.rev_revenue_imports USING btree (deleted_at);


--
-- Name: rev_revenue_imports_import_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_import_date_idx ON public.rev_revenue_imports USING btree (import_date DESC);


--
-- Name: rev_revenue_imports_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_metadata_idx ON public.rev_revenue_imports USING gin (metadata);


--
-- Name: rev_revenue_imports_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_status_active_idx ON public.rev_revenue_imports USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: rev_revenue_imports_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_tenant_id_idx ON public.rev_revenue_imports USING btree (tenant_id);


--
-- Name: rev_revenue_imports_tenant_id_import_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rev_revenue_imports_tenant_id_import_reference_key ON public.rev_revenue_imports USING btree (tenant_id, import_reference) WHERE (deleted_at IS NULL);


--
-- Name: rev_revenue_imports_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rev_revenue_imports_updated_by_idx ON public.rev_revenue_imports USING btree (updated_by);


--
-- Name: rid_driver_blacklists_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_created_by_idx ON public.rid_driver_blacklists USING btree (created_by);


--
-- Name: rid_driver_blacklists_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_deleted_at_idx ON public.rid_driver_blacklists USING btree (deleted_at);


--
-- Name: rid_driver_blacklists_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_driver_id_idx ON public.rid_driver_blacklists USING btree (driver_id);


--
-- Name: rid_driver_blacklists_end_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_end_date_idx ON public.rid_driver_blacklists USING btree (end_date);


--
-- Name: rid_driver_blacklists_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_metadata_gin ON public.rid_driver_blacklists USING gin (metadata);


--
-- Name: rid_driver_blacklists_start_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_start_date_idx ON public.rid_driver_blacklists USING btree (start_date);


--
-- Name: rid_driver_blacklists_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_status_active_idx ON public.rid_driver_blacklists USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_blacklists_tenant_driver_active_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_blacklists_tenant_driver_active_key ON public.rid_driver_blacklists USING btree (tenant_id, driver_id) WHERE ((deleted_at IS NULL) AND (status = 'active'::text));


--
-- Name: rid_driver_blacklists_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_tenant_id_idx ON public.rid_driver_blacklists USING btree (tenant_id);


--
-- Name: rid_driver_blacklists_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_blacklists_updated_by_idx ON public.rid_driver_blacklists USING btree (updated_by);


--
-- Name: rid_driver_cooperation_terms_accepted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_accepted_at_idx ON public.rid_driver_cooperation_terms USING btree (accepted_at);


--
-- Name: rid_driver_cooperation_terms_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_created_by_idx ON public.rid_driver_cooperation_terms USING btree (created_by);


--
-- Name: rid_driver_cooperation_terms_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_deleted_at_idx ON public.rid_driver_cooperation_terms USING btree (deleted_at);


--
-- Name: rid_driver_cooperation_terms_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_driver_id_idx ON public.rid_driver_cooperation_terms USING btree (driver_id);


--
-- Name: rid_driver_cooperation_terms_effective_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_effective_date_idx ON public.rid_driver_cooperation_terms USING btree (effective_date);


--
-- Name: rid_driver_cooperation_terms_expiry_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_expiry_date_idx ON public.rid_driver_cooperation_terms USING btree (expiry_date);


--
-- Name: rid_driver_cooperation_terms_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_metadata_gin ON public.rid_driver_cooperation_terms USING gin (metadata);


--
-- Name: rid_driver_cooperation_terms_tenant_driver_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_cooperation_terms_tenant_driver_version_key ON public.rid_driver_cooperation_terms USING btree (tenant_id, driver_id, terms_version) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_cooperation_terms_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_tenant_id_idx ON public.rid_driver_cooperation_terms USING btree (tenant_id);


--
-- Name: rid_driver_cooperation_terms_terms_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_terms_version_idx ON public.rid_driver_cooperation_terms USING btree (terms_version);


--
-- Name: rid_driver_cooperation_terms_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_cooperation_terms_updated_by_idx ON public.rid_driver_cooperation_terms USING btree (updated_by);


--
-- Name: rid_driver_documents_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_created_by_idx ON public.rid_driver_documents USING btree (created_by);


--
-- Name: rid_driver_documents_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_deleted_at_idx ON public.rid_driver_documents USING btree (deleted_at);


--
-- Name: rid_driver_documents_document_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_document_id_idx ON public.rid_driver_documents USING btree (document_id);


--
-- Name: rid_driver_documents_document_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_document_type_idx ON public.rid_driver_documents USING btree (document_type);


--
-- Name: rid_driver_documents_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_driver_id_idx ON public.rid_driver_documents USING btree (driver_id);


--
-- Name: rid_driver_documents_driver_type_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_documents_driver_type_uq ON public.rid_driver_documents USING btree (driver_id, document_type) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_documents_expiry_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_expiry_date_idx ON public.rid_driver_documents USING btree (expiry_date);


--
-- Name: rid_driver_documents_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_tenant_id_idx ON public.rid_driver_documents USING btree (tenant_id);


--
-- Name: rid_driver_documents_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_documents_updated_by_idx ON public.rid_driver_documents USING btree (updated_by);


--
-- Name: rid_driver_languages_lang_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_languages_lang_idx ON public.rid_driver_languages USING btree (language_code) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_languages_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_languages_unique ON public.rid_driver_languages USING btree (tenant_id, driver_id, language_code) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_performances_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_created_by_idx ON public.rid_driver_performances USING btree (created_by);


--
-- Name: rid_driver_performances_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_deleted_at_idx ON public.rid_driver_performances USING btree (deleted_at);


--
-- Name: rid_driver_performances_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_driver_id_idx ON public.rid_driver_performances USING btree (driver_id);


--
-- Name: rid_driver_performances_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_metadata_gin ON public.rid_driver_performances USING gin (metadata);


--
-- Name: rid_driver_performances_period_end_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_period_end_idx ON public.rid_driver_performances USING btree (period_end);


--
-- Name: rid_driver_performances_period_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_period_start_idx ON public.rid_driver_performances USING btree (period_start);


--
-- Name: rid_driver_performances_tenant_driver_period_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_performances_tenant_driver_period_key ON public.rid_driver_performances USING btree (tenant_id, driver_id, period_start) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_performances_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_tenant_id_idx ON public.rid_driver_performances USING btree (tenant_id);


--
-- Name: rid_driver_performances_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_performances_updated_by_idx ON public.rid_driver_performances USING btree (updated_by);


--
-- Name: rid_driver_requests_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_created_by_idx ON public.rid_driver_requests USING btree (created_by);


--
-- Name: rid_driver_requests_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_deleted_at_idx ON public.rid_driver_requests USING btree (deleted_at);


--
-- Name: rid_driver_requests_details_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_details_gin ON public.rid_driver_requests USING gin (details);


--
-- Name: rid_driver_requests_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_driver_id_idx ON public.rid_driver_requests USING btree (driver_id);


--
-- Name: rid_driver_requests_request_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_request_date_idx ON public.rid_driver_requests USING btree (request_date);


--
-- Name: rid_driver_requests_request_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_request_type_idx ON public.rid_driver_requests USING btree (request_type);


--
-- Name: rid_driver_requests_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_status_active_idx ON public.rid_driver_requests USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_requests_tenant_driver_date_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_requests_tenant_driver_date_type_key ON public.rid_driver_requests USING btree (tenant_id, driver_id, request_date, request_type) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_requests_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_tenant_id_idx ON public.rid_driver_requests USING btree (tenant_id);


--
-- Name: rid_driver_requests_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_requests_updated_by_idx ON public.rid_driver_requests USING btree (updated_by);


--
-- Name: rid_driver_training_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_created_by_idx ON public.rid_driver_training USING btree (created_by);


--
-- Name: rid_driver_training_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_deleted_at_idx ON public.rid_driver_training USING btree (deleted_at);


--
-- Name: rid_driver_training_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_driver_id_idx ON public.rid_driver_training USING btree (driver_id);


--
-- Name: rid_driver_training_due_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_due_at_idx ON public.rid_driver_training USING btree (due_at);


--
-- Name: rid_driver_training_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_metadata_gin ON public.rid_driver_training USING gin (metadata);


--
-- Name: rid_driver_training_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_status_active_idx ON public.rid_driver_training USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_training_tenant_driver_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_driver_training_tenant_driver_name_key ON public.rid_driver_training USING btree (tenant_id, driver_id, training_name) WHERE (deleted_at IS NULL);


--
-- Name: rid_driver_training_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_tenant_id_idx ON public.rid_driver_training USING btree (tenant_id);


--
-- Name: rid_driver_training_training_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_training_name_idx ON public.rid_driver_training USING btree (training_name);


--
-- Name: rid_driver_training_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_driver_training_updated_by_idx ON public.rid_driver_training USING btree (updated_by);


--
-- Name: rid_drivers_cooperation_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_cooperation_type_idx ON public.rid_drivers USING btree (cooperation_type) WHERE (deleted_at IS NULL);


--
-- Name: rid_drivers_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_created_at_idx ON public.rid_drivers USING btree (created_at DESC);


--
-- Name: rid_drivers_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_deleted_at_idx ON public.rid_drivers USING btree (deleted_at);


--
-- Name: rid_drivers_dob_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_dob_idx ON public.rid_drivers USING btree (date_of_birth) WHERE (deleted_at IS NULL);


--
-- Name: rid_drivers_driver_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_driver_status_idx ON public.rid_drivers USING btree (driver_status);


--
-- Name: rid_drivers_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_email_idx ON public.rid_drivers USING btree (email);


--
-- Name: rid_drivers_employment_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_employment_status_idx ON public.rid_drivers USING btree (employment_status) WHERE (deleted_at IS NULL);


--
-- Name: rid_drivers_first_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_first_name_idx ON public.rid_drivers USING btree (first_name);


--
-- Name: rid_drivers_hire_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_hire_date_idx ON public.rid_drivers USING btree (hire_date) WHERE (deleted_at IS NULL);


--
-- Name: rid_drivers_last_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_last_name_idx ON public.rid_drivers USING btree (last_name);


--
-- Name: rid_drivers_license_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_license_number_idx ON public.rid_drivers USING btree (license_number);


--
-- Name: rid_drivers_nationality_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_nationality_idx ON public.rid_drivers USING btree (nationality) WHERE (deleted_at IS NULL);


--
-- Name: rid_drivers_notes_gin_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_notes_gin_idx ON public.rid_drivers USING gin (to_tsvector('english'::regconfig, COALESCE(notes, ''::text)));


--
-- Name: rid_drivers_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_phone_idx ON public.rid_drivers USING btree (phone);


--
-- Name: rid_drivers_tenant_email_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_drivers_tenant_email_uq ON public.rid_drivers USING btree (tenant_id, email) WHERE (deleted_at IS NULL);


--
-- Name: rid_drivers_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rid_drivers_tenant_id_idx ON public.rid_drivers USING btree (tenant_id);


--
-- Name: rid_drivers_tenant_license_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX rid_drivers_tenant_license_uq ON public.rid_drivers USING btree (tenant_id, license_number) WHERE (deleted_at IS NULL);


--
-- Name: sch_goals_assigned_to_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_assigned_to_idx ON public.sch_goals USING btree (assigned_to);


--
-- Name: sch_goals_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_created_by_idx ON public.sch_goals USING btree (created_by);


--
-- Name: sch_goals_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_deleted_at_idx ON public.sch_goals USING btree (deleted_at);


--
-- Name: sch_goals_goal_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_goal_type_idx ON public.sch_goals USING btree (goal_type);


--
-- Name: sch_goals_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_metadata_gin ON public.sch_goals USING gin (metadata);


--
-- Name: sch_goals_period_end_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_period_end_idx ON public.sch_goals USING btree (period_end);


--
-- Name: sch_goals_period_start_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_period_start_idx ON public.sch_goals USING btree (period_start);


--
-- Name: sch_goals_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_status_active_idx ON public.sch_goals USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: sch_goals_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_tenant_id_idx ON public.sch_goals USING btree (tenant_id);


--
-- Name: sch_goals_tenant_type_period_assigned_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sch_goals_tenant_type_period_assigned_unique ON public.sch_goals USING btree (tenant_id, goal_type, period_start, assigned_to) WHERE (deleted_at IS NULL);


--
-- Name: sch_goals_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_goals_updated_by_idx ON public.sch_goals USING btree (updated_by);


--
-- Name: sch_maintenance_schedules_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_created_by_idx ON public.sch_maintenance_schedules USING btree (created_by);


--
-- Name: sch_maintenance_schedules_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_deleted_at_idx ON public.sch_maintenance_schedules USING btree (deleted_at);


--
-- Name: sch_maintenance_schedules_maintenance_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_maintenance_type_idx ON public.sch_maintenance_schedules USING btree (maintenance_type);


--
-- Name: sch_maintenance_schedules_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_metadata_gin ON public.sch_maintenance_schedules USING gin (metadata);


--
-- Name: sch_maintenance_schedules_scheduled_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_scheduled_date_idx ON public.sch_maintenance_schedules USING btree (scheduled_date);


--
-- Name: sch_maintenance_schedules_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_status_active_idx ON public.sch_maintenance_schedules USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: sch_maintenance_schedules_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_tenant_id_idx ON public.sch_maintenance_schedules USING btree (tenant_id);


--
-- Name: sch_maintenance_schedules_tenant_vehicle_date_type_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sch_maintenance_schedules_tenant_vehicle_date_type_unique ON public.sch_maintenance_schedules USING btree (tenant_id, vehicle_id, scheduled_date, maintenance_type) WHERE (deleted_at IS NULL);


--
-- Name: sch_maintenance_schedules_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_updated_by_idx ON public.sch_maintenance_schedules USING btree (updated_by);


--
-- Name: sch_maintenance_schedules_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_maintenance_schedules_vehicle_id_idx ON public.sch_maintenance_schedules USING btree (vehicle_id);


--
-- Name: sch_shifts_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_created_by_idx ON public.sch_shifts USING btree (created_by);


--
-- Name: sch_shifts_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_deleted_at_idx ON public.sch_shifts USING btree (deleted_at);


--
-- Name: sch_shifts_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_driver_id_idx ON public.sch_shifts USING btree (driver_id);


--
-- Name: sch_shifts_end_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_end_time_idx ON public.sch_shifts USING btree (end_time);


--
-- Name: sch_shifts_metadata_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_metadata_gin ON public.sch_shifts USING gin (metadata);


--
-- Name: sch_shifts_start_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_start_time_idx ON public.sch_shifts USING btree (start_time);


--
-- Name: sch_shifts_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_status_active_idx ON public.sch_shifts USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: sch_shifts_tenant_driver_start_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sch_shifts_tenant_driver_start_unique ON public.sch_shifts USING btree (tenant_id, driver_id, start_time) WHERE (deleted_at IS NULL);


--
-- Name: sch_shifts_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_tenant_id_idx ON public.sch_shifts USING btree (tenant_id);


--
-- Name: sch_shifts_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sch_shifts_updated_by_idx ON public.sch_shifts USING btree (updated_by);


--
-- Name: sup_customer_feedback_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_customer_feedback_created_at_idx ON public.sup_customer_feedback USING btree (created_at DESC) WHERE (deleted_at IS NULL);


--
-- Name: sup_customer_feedback_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_customer_feedback_metadata_idx ON public.sup_customer_feedback USING gin (metadata);


--
-- Name: sup_customer_feedback_rating_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_customer_feedback_rating_idx ON public.sup_customer_feedback USING btree (rating) WHERE (deleted_at IS NULL);


--
-- Name: sup_customer_feedback_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_customer_feedback_tenant_id_idx ON public.sup_customer_feedback USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: sup_customer_feedback_tenant_id_submitted_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_customer_feedback_tenant_id_submitted_by_idx ON public.sup_customer_feedback USING btree (tenant_id, submitted_by) WHERE (deleted_at IS NULL);


--
-- Name: sup_ticket_messages_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_ticket_messages_created_by_idx ON public.sup_ticket_messages USING btree (created_by);


--
-- Name: sup_ticket_messages_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_ticket_messages_deleted_at_idx ON public.sup_ticket_messages USING btree (deleted_at);


--
-- Name: sup_ticket_messages_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_ticket_messages_metadata_idx ON public.sup_ticket_messages USING gin (metadata);


--
-- Name: sup_ticket_messages_sent_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_ticket_messages_sent_at_idx ON public.sup_ticket_messages USING btree (sent_at);


--
-- Name: sup_ticket_messages_ticket_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_ticket_messages_ticket_id_idx ON public.sup_ticket_messages USING btree (ticket_id);


--
-- Name: sup_ticket_messages_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_ticket_messages_updated_by_idx ON public.sup_ticket_messages USING btree (updated_by);


--
-- Name: sup_tickets_assigned_to_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_assigned_to_idx ON public.sup_tickets USING btree (assigned_to);


--
-- Name: sup_tickets_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_created_at_idx ON public.sup_tickets USING btree (created_at);


--
-- Name: sup_tickets_created_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_created_by_idx ON public.sup_tickets USING btree (created_by);


--
-- Name: sup_tickets_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_deleted_at_idx ON public.sup_tickets USING btree (deleted_at);


--
-- Name: sup_tickets_metadata_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_metadata_idx ON public.sup_tickets USING gin (metadata);


--
-- Name: sup_tickets_priority_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_priority_active_idx ON public.sup_tickets USING btree (priority) WHERE (deleted_at IS NULL);


--
-- Name: sup_tickets_raised_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_raised_by_idx ON public.sup_tickets USING btree (raised_by);


--
-- Name: sup_tickets_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_status_active_idx ON public.sup_tickets USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: sup_tickets_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_tenant_id_idx ON public.sup_tickets USING btree (tenant_id);


--
-- Name: sup_tickets_tenant_id_raised_by_created_at_deleted_at_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sup_tickets_tenant_id_raised_by_created_at_deleted_at_key ON public.sup_tickets USING btree (tenant_id, raised_by, created_at) WHERE (deleted_at IS NULL);


--
-- Name: sup_tickets_updated_by_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sup_tickets_updated_by_idx ON public.sup_tickets USING btree (updated_by);


--
-- Name: trp_trips_client_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_client_id_idx ON public.trp_trips USING btree (client_id);


--
-- Name: trp_trips_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_created_at_idx ON public.trp_trips USING btree (created_at DESC);


--
-- Name: trp_trips_deleted_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_deleted_at_idx ON public.trp_trips USING btree (deleted_at);


--
-- Name: trp_trips_driver_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_driver_id_idx ON public.trp_trips USING btree (driver_id);


--
-- Name: trp_trips_end_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_end_time_idx ON public.trp_trips USING btree (end_time);


--
-- Name: trp_trips_platform_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_platform_id_idx ON public.trp_trips USING btree (platform_id);


--
-- Name: trp_trips_start_time_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_start_time_idx ON public.trp_trips USING btree (start_time);


--
-- Name: trp_trips_status_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_status_active_idx ON public.trp_trips USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: trp_trips_tenant_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_tenant_id_idx ON public.trp_trips USING btree (tenant_id);


--
-- Name: trp_trips_trip_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_trip_date_idx ON public.trp_trips USING btree (trip_date);


--
-- Name: trp_trips_vehicle_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX trp_trips_vehicle_id_idx ON public.trp_trips USING btree (vehicle_id);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- Name: crm_contracts set_crm_contracts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_crm_contracts_updated_at BEFORE UPDATE ON public.crm_contracts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: crm_leads set_crm_leads_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_crm_leads_updated_at BEFORE UPDATE ON public.crm_leads FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: crm_opportunities set_crm_opportunities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_crm_opportunities_updated_at BEFORE UPDATE ON public.crm_opportunities FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: adm_member_roles set_updated_at_adm_member_roles; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_adm_member_roles BEFORE UPDATE ON public.adm_member_roles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: adm_members set_updated_at_adm_members; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_adm_members BEFORE UPDATE ON public.adm_members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: adm_provider_employees set_updated_at_adm_provider_employees; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_adm_provider_employees BEFORE UPDATE ON public.adm_provider_employees FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: adm_tenants set_updated_at_adm_tenants; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_adm_tenants BEFORE UPDATE ON public.adm_tenants FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: crm_leads set_updated_at_crm_leads; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_crm_leads BEFORE UPDATE ON public.crm_leads FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: dir_car_makes set_updated_at_dir_car_makes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_dir_car_makes BEFORE UPDATE ON public.dir_car_makes FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: dir_car_models set_updated_at_dir_car_models; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_dir_car_models BEFORE UPDATE ON public.dir_car_models FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: dir_country_regulations set_updated_at_dir_country_regulations; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_dir_country_regulations BEFORE UPDATE ON public.dir_country_regulations FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: dir_platforms set_updated_at_dir_platforms; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_dir_platforms BEFORE UPDATE ON public.dir_platforms FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: dir_vehicle_classes set_updated_at_dir_vehicle_classes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_dir_vehicle_classes BEFORE UPDATE ON public.dir_vehicle_classes FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: doc_documents set_updated_at_doc_documents; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_doc_documents BEFORE UPDATE ON public.doc_documents FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: flt_vehicle_assignments set_updated_at_flt_vehicle_assignments; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_flt_vehicle_assignments BEFORE UPDATE ON public.flt_vehicle_assignments FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: flt_vehicle_events set_updated_at_flt_vehicle_events; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_flt_vehicle_events BEFORE UPDATE ON public.flt_vehicle_events FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: flt_vehicle_expenses set_updated_at_flt_vehicle_expenses; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_flt_vehicle_expenses BEFORE UPDATE ON public.flt_vehicle_expenses FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: flt_vehicle_insurances set_updated_at_flt_vehicle_insurances; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_flt_vehicle_insurances BEFORE UPDATE ON public.flt_vehicle_insurances FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: flt_vehicle_maintenance set_updated_at_flt_vehicle_maintenance; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_flt_vehicle_maintenance BEFORE UPDATE ON public.flt_vehicle_maintenance FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: flt_vehicles set_updated_at_flt_vehicles; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_flt_vehicles BEFORE UPDATE ON public.flt_vehicles FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_languages set_updated_at_rid_driver_languages; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_rid_driver_languages BEFORE UPDATE ON public.rid_driver_languages FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sup_customer_feedback trg_sup_customer_feedback_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_sup_customer_feedback_updated_at BEFORE UPDATE ON public.sup_customer_feedback FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: rid_drivers trg_sync_driver_status; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_sync_driver_status BEFORE INSERT OR UPDATE OF employment_status ON public.rid_drivers FOR EACH ROW EXECUTE FUNCTION public.sync_driver_status_from_employment();


--
-- Name: adm_roles update_adm_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_adm_roles_updated_at BEFORE UPDATE ON public.adm_roles FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: bil_billing_plans update_bil_billing_plans_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bil_billing_plans_updated_at BEFORE UPDATE ON public.bil_billing_plans FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: bil_payment_methods update_bil_payment_methods_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bil_payment_methods_updated_at BEFORE UPDATE ON public.bil_payment_methods FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: bil_tenant_invoice_lines update_bil_tenant_invoice_lines_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bil_tenant_invoice_lines_updated_at BEFORE UPDATE ON public.bil_tenant_invoice_lines FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: bil_tenant_invoices update_bil_tenant_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bil_tenant_invoices_updated_at BEFORE UPDATE ON public.bil_tenant_invoices FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: bil_tenant_subscriptions update_bil_tenant_subscriptions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bil_tenant_subscriptions_updated_at BEFORE UPDATE ON public.bil_tenant_subscriptions FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: bil_tenant_usage_metrics update_bil_tenant_usage_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bil_tenant_usage_metrics_updated_at BEFORE UPDATE ON public.bil_tenant_usage_metrics FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: crm_contracts update_crm_contracts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_crm_contracts_updated_at BEFORE UPDATE ON public.crm_contracts FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: crm_opportunities update_crm_opportunities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_crm_opportunities_updated_at BEFORE UPDATE ON public.crm_opportunities FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: fin_accounts update_fin_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_fin_accounts_updated_at BEFORE UPDATE ON public.fin_accounts FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: fin_driver_payment_batches update_fin_driver_payment_batches_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_fin_driver_payment_batches_updated_at BEFORE UPDATE ON public.fin_driver_payment_batches FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: fin_driver_payments update_fin_driver_payments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_fin_driver_payments_updated_at BEFORE UPDATE ON public.fin_driver_payments FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: fin_toll_transactions update_fin_toll_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_fin_toll_transactions_updated_at BEFORE UPDATE ON public.fin_toll_transactions FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: fin_traffic_fines update_fin_traffic_fines_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_fin_traffic_fines_updated_at BEFORE UPDATE ON public.fin_traffic_fines FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: fin_transactions update_fin_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_fin_transactions_updated_at BEFORE UPDATE ON public.fin_transactions FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rev_driver_revenues update_rev_driver_revenues_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rev_driver_revenues_updated_at BEFORE UPDATE ON public.rev_driver_revenues FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rev_reconciliations update_rev_reconciliations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rev_reconciliations_updated_at BEFORE UPDATE ON public.rev_reconciliations FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rev_revenue_imports update_rev_revenue_imports_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rev_revenue_imports_updated_at BEFORE UPDATE ON public.rev_revenue_imports FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_blacklists update_rid_driver_blacklists_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rid_driver_blacklists_updated_at BEFORE UPDATE ON public.rid_driver_blacklists FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_cooperation_terms update_rid_driver_cooperation_terms_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rid_driver_cooperation_terms_updated_at BEFORE UPDATE ON public.rid_driver_cooperation_terms FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_documents update_rid_driver_documents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rid_driver_documents_updated_at BEFORE UPDATE ON public.rid_driver_documents FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_performances update_rid_driver_performances_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rid_driver_performances_updated_at BEFORE UPDATE ON public.rid_driver_performances FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_requests update_rid_driver_requests_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rid_driver_requests_updated_at BEFORE UPDATE ON public.rid_driver_requests FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: rid_driver_training update_rid_driver_training_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_rid_driver_training_updated_at BEFORE UPDATE ON public.rid_driver_training FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sch_goals update_sch_goals_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sch_goals_updated_at BEFORE UPDATE ON public.sch_goals FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sch_maintenance_schedules update_sch_maintenance_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sch_maintenance_schedules_updated_at BEFORE UPDATE ON public.sch_maintenance_schedules FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sch_shifts update_sch_shifts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sch_shifts_updated_at BEFORE UPDATE ON public.sch_shifts FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sch_tasks update_sch_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sch_tasks_updated_at BEFORE UPDATE ON public.sch_tasks FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sup_ticket_messages update_sup_ticket_messages_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sup_ticket_messages_updated_at BEFORE UPDATE ON public.sup_ticket_messages FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: sup_tickets update_sup_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_sup_tickets_updated_at BEFORE UPDATE ON public.sup_tickets FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: trp_client_invoices update_trp_client_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_trp_client_invoices_updated_at BEFORE UPDATE ON public.trp_client_invoices FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: trp_platform_accounts update_trp_platform_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_trp_platform_accounts_updated_at BEFORE UPDATE ON public.trp_platform_accounts FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: trp_settlements update_trp_settlements_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_trp_settlements_updated_at BEFORE UPDATE ON public.trp_settlements FOR EACH ROW EXECUTE FUNCTION public.trigger_set_updated_at();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: adm_audit_logs adm_audit_logs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_audit_logs
    ADD CONSTRAINT adm_audit_logs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_audit_logs adm_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_audit_logs
    ADD CONSTRAINT adm_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adm_member_roles adm_member_roles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_member_roles adm_member_roles_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_member_roles adm_member_roles_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adm_member_roles adm_member_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.adm_roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adm_member_roles adm_member_roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adm_member_roles adm_member_roles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_member_roles
    ADD CONSTRAINT adm_member_roles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_members adm_members_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_members
    ADD CONSTRAINT adm_members_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_members adm_members_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_members
    ADD CONSTRAINT adm_members_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_members adm_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_members
    ADD CONSTRAINT adm_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adm_members adm_members_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_members
    ADD CONSTRAINT adm_members_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_provider_employees adm_provider_employees_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_provider_employees
    ADD CONSTRAINT adm_provider_employees_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_provider_employees adm_provider_employees_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_provider_employees
    ADD CONSTRAINT adm_provider_employees_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_provider_employees adm_provider_employees_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_provider_employees
    ADD CONSTRAINT adm_provider_employees_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_roles adm_roles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_roles
    ADD CONSTRAINT adm_roles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_roles adm_roles_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_roles
    ADD CONSTRAINT adm_roles_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_roles adm_roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_roles
    ADD CONSTRAINT adm_roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adm_roles adm_roles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_roles
    ADD CONSTRAINT adm_roles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_tenant_lifecycle_events adm_tenant_lifecycle_events_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_tenant_lifecycle_events
    ADD CONSTRAINT adm_tenant_lifecycle_events_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: adm_tenant_lifecycle_events adm_tenant_lifecycle_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adm_tenant_lifecycle_events
    ADD CONSTRAINT adm_tenant_lifecycle_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_billing_plans bil_billing_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_billing_plans
    ADD CONSTRAINT bil_billing_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_billing_plans bil_billing_plans_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_billing_plans
    ADD CONSTRAINT bil_billing_plans_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_billing_plans bil_billing_plans_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_billing_plans
    ADD CONSTRAINT bil_billing_plans_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_payment_methods bil_payment_methods_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_payment_methods
    ADD CONSTRAINT bil_payment_methods_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_payment_methods bil_payment_methods_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_payment_methods
    ADD CONSTRAINT bil_payment_methods_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_payment_methods bil_payment_methods_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_payment_methods
    ADD CONSTRAINT bil_payment_methods_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_payment_methods bil_payment_methods_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_payment_methods
    ADD CONSTRAINT bil_payment_methods_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_invoice_lines bil_tenant_invoice_lines_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoice_lines
    ADD CONSTRAINT bil_tenant_invoice_lines_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_invoice_lines bil_tenant_invoice_lines_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoice_lines
    ADD CONSTRAINT bil_tenant_invoice_lines_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_invoice_lines bil_tenant_invoice_lines_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoice_lines
    ADD CONSTRAINT bil_tenant_invoice_lines_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.bil_tenant_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_tenant_invoice_lines bil_tenant_invoice_lines_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoice_lines
    ADD CONSTRAINT bil_tenant_invoice_lines_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_invoices bil_tenant_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoices
    ADD CONSTRAINT bil_tenant_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_invoices bil_tenant_invoices_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoices
    ADD CONSTRAINT bil_tenant_invoices_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_invoices bil_tenant_invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoices
    ADD CONSTRAINT bil_tenant_invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_tenant_invoices bil_tenant_invoices_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_invoices
    ADD CONSTRAINT bil_tenant_invoices_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_subscriptions bil_tenant_subscriptions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_subscriptions
    ADD CONSTRAINT bil_tenant_subscriptions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_subscriptions bil_tenant_subscriptions_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_subscriptions
    ADD CONSTRAINT bil_tenant_subscriptions_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_subscriptions bil_tenant_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_subscriptions
    ADD CONSTRAINT bil_tenant_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.bil_billing_plans(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_tenant_subscriptions bil_tenant_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_subscriptions
    ADD CONSTRAINT bil_tenant_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_tenant_subscriptions bil_tenant_subscriptions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_subscriptions
    ADD CONSTRAINT bil_tenant_subscriptions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_usage_metrics bil_tenant_usage_metrics_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_usage_metrics
    ADD CONSTRAINT bil_tenant_usage_metrics_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_usage_metrics bil_tenant_usage_metrics_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_usage_metrics
    ADD CONSTRAINT bil_tenant_usage_metrics_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bil_tenant_usage_metrics bil_tenant_usage_metrics_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_usage_metrics
    ADD CONSTRAINT bil_tenant_usage_metrics_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bil_tenant_usage_metrics bil_tenant_usage_metrics_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bil_tenant_usage_metrics
    ADD CONSTRAINT bil_tenant_usage_metrics_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_contracts crm_contracts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_contracts
    ADD CONSTRAINT crm_contracts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_contracts crm_contracts_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_contracts
    ADD CONSTRAINT crm_contracts_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_contracts crm_contracts_opportunity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_contracts
    ADD CONSTRAINT crm_contracts_opportunity_id_fkey FOREIGN KEY (opportunity_id) REFERENCES public.crm_opportunities(id) ON DELETE SET NULL;


--
-- Name: crm_contracts crm_contracts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_contracts
    ADD CONSTRAINT crm_contracts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_opportunities crm_opportunities_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_opportunities crm_opportunities_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_opportunities crm_opportunities_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_opportunities crm_opportunities_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.crm_leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: crm_opportunities crm_opportunities_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dir_car_makes dir_car_makes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_car_makes
    ADD CONSTRAINT dir_car_makes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dir_car_models dir_car_models_make_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_car_models
    ADD CONSTRAINT dir_car_models_make_id_fkey FOREIGN KEY (make_id) REFERENCES public.dir_car_makes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dir_car_models dir_car_models_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_car_models
    ADD CONSTRAINT dir_car_models_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dir_car_models dir_car_models_vehicle_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_car_models
    ADD CONSTRAINT dir_car_models_vehicle_class_id_fkey FOREIGN KEY (vehicle_class_id) REFERENCES public.dir_vehicle_classes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dir_vehicle_classes dir_vehicle_classes_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dir_vehicle_classes
    ADD CONSTRAINT dir_vehicle_classes_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.dir_country_regulations(country_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doc_documents doc_documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doc_documents
    ADD CONSTRAINT doc_documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_accounts fin_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_accounts fin_accounts_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_accounts fin_accounts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_accounts fin_accounts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_accounts
    ADD CONSTRAINT fin_accounts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_driver_payment_batches fin_driver_payment_batches_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payment_batches
    ADD CONSTRAINT fin_driver_payment_batches_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_driver_payment_batches fin_driver_payment_batches_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payment_batches
    ADD CONSTRAINT fin_driver_payment_batches_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_driver_payment_batches fin_driver_payment_batches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payment_batches
    ADD CONSTRAINT fin_driver_payment_batches_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_driver_payment_batches fin_driver_payment_batches_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payment_batches
    ADD CONSTRAINT fin_driver_payment_batches_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_driver_payments fin_driver_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_driver_payments fin_driver_payments_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_driver_payments fin_driver_payments_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_driver_payments fin_driver_payments_payment_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_payment_batch_id_fkey FOREIGN KEY (payment_batch_id) REFERENCES public.fin_driver_payment_batches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_driver_payments fin_driver_payments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_driver_payments fin_driver_payments_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_driver_payments
    ADD CONSTRAINT fin_driver_payments_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_toll_transactions fin_toll_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_toll_transactions fin_toll_transactions_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_toll_transactions fin_toll_transactions_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_toll_transactions fin_toll_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_toll_transactions fin_toll_transactions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_toll_transactions fin_toll_transactions_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_toll_transactions
    ADD CONSTRAINT fin_toll_transactions_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_traffic_fines fin_traffic_fines_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_traffic_fines fin_traffic_fines_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_traffic_fines fin_traffic_fines_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_traffic_fines fin_traffic_fines_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_traffic_fines fin_traffic_fines_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_traffic_fines fin_traffic_fines_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_traffic_fines
    ADD CONSTRAINT fin_traffic_fines_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_transactions fin_transactions_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.fin_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_transactions fin_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_transactions fin_transactions_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fin_transactions fin_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fin_transactions fin_transactions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fin_transactions
    ADD CONSTRAINT fin_transactions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_assignments flt_vehicle_assignments_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_assignments
    ADD CONSTRAINT flt_vehicle_assignments_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_events flt_vehicle_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_events
    ADD CONSTRAINT flt_vehicle_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_events flt_vehicle_events_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_events
    ADD CONSTRAINT flt_vehicle_events_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_events flt_vehicle_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_events
    ADD CONSTRAINT flt_vehicle_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_events flt_vehicle_events_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_events
    ADD CONSTRAINT flt_vehicle_events_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_events flt_vehicle_events_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_events
    ADD CONSTRAINT flt_vehicle_events_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON DELETE SET NULL;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_ride_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_ride_id_fkey FOREIGN KEY (ride_id) REFERENCES public.trp_trips(id) ON DELETE SET NULL;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_expenses flt_vehicle_expenses_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_expenses
    ADD CONSTRAINT flt_vehicle_expenses_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_insurances flt_vehicle_insurances_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_insurances
    ADD CONSTRAINT flt_vehicle_insurances_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_insurances flt_vehicle_insurances_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_insurances
    ADD CONSTRAINT flt_vehicle_insurances_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_insurances flt_vehicle_insurances_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_insurances
    ADD CONSTRAINT flt_vehicle_insurances_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_insurances flt_vehicle_insurances_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_insurances
    ADD CONSTRAINT flt_vehicle_insurances_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_insurances flt_vehicle_insurances_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_insurances
    ADD CONSTRAINT flt_vehicle_insurances_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_maintenance flt_vehicle_maintenance_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_maintenance
    ADD CONSTRAINT flt_vehicle_maintenance_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_maintenance flt_vehicle_maintenance_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_maintenance
    ADD CONSTRAINT flt_vehicle_maintenance_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicle_maintenance flt_vehicle_maintenance_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_maintenance
    ADD CONSTRAINT flt_vehicle_maintenance_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicle_maintenance flt_vehicle_maintenance_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicle_maintenance
    ADD CONSTRAINT flt_vehicle_maintenance_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicles flt_vehicles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicles flt_vehicles_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: flt_vehicles flt_vehicles_make_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_make_id_fkey FOREIGN KEY (make_id) REFERENCES public.dir_car_makes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: flt_vehicles flt_vehicles_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.dir_car_models(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: flt_vehicles flt_vehicles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flt_vehicles flt_vehicles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flt_vehicles
    ADD CONSTRAINT flt_vehicles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_driver_revenues rev_driver_revenues_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_driver_revenues
    ADD CONSTRAINT rev_driver_revenues_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_driver_revenues rev_driver_revenues_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_driver_revenues
    ADD CONSTRAINT rev_driver_revenues_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_driver_revenues rev_driver_revenues_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_driver_revenues
    ADD CONSTRAINT rev_driver_revenues_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rev_driver_revenues rev_driver_revenues_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_driver_revenues
    ADD CONSTRAINT rev_driver_revenues_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rev_driver_revenues rev_driver_revenues_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_driver_revenues
    ADD CONSTRAINT rev_driver_revenues_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_reconciliations rev_reconciliations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_reconciliations
    ADD CONSTRAINT rev_reconciliations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_reconciliations rev_reconciliations_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_reconciliations
    ADD CONSTRAINT rev_reconciliations_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_reconciliations rev_reconciliations_import_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_reconciliations
    ADD CONSTRAINT rev_reconciliations_import_id_fkey FOREIGN KEY (import_id) REFERENCES public.rev_revenue_imports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rev_reconciliations rev_reconciliations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_reconciliations
    ADD CONSTRAINT rev_reconciliations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rev_reconciliations rev_reconciliations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_reconciliations
    ADD CONSTRAINT rev_reconciliations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_revenue_imports rev_revenue_imports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_revenue_imports
    ADD CONSTRAINT rev_revenue_imports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_revenue_imports rev_revenue_imports_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_revenue_imports
    ADD CONSTRAINT rev_revenue_imports_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rev_revenue_imports rev_revenue_imports_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_revenue_imports
    ADD CONSTRAINT rev_revenue_imports_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rev_revenue_imports rev_revenue_imports_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rev_revenue_imports
    ADD CONSTRAINT rev_revenue_imports_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_blacklists rid_driver_blacklists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_blacklists
    ADD CONSTRAINT rid_driver_blacklists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_blacklists rid_driver_blacklists_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_blacklists
    ADD CONSTRAINT rid_driver_blacklists_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_blacklists rid_driver_blacklists_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_blacklists
    ADD CONSTRAINT rid_driver_blacklists_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_blacklists rid_driver_blacklists_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_blacklists
    ADD CONSTRAINT rid_driver_blacklists_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_blacklists rid_driver_blacklists_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_blacklists
    ADD CONSTRAINT rid_driver_blacklists_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_cooperation_terms rid_driver_cooperation_terms_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_cooperation_terms
    ADD CONSTRAINT rid_driver_cooperation_terms_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_cooperation_terms rid_driver_cooperation_terms_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_cooperation_terms
    ADD CONSTRAINT rid_driver_cooperation_terms_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_cooperation_terms rid_driver_cooperation_terms_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_cooperation_terms
    ADD CONSTRAINT rid_driver_cooperation_terms_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_cooperation_terms rid_driver_cooperation_terms_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_cooperation_terms
    ADD CONSTRAINT rid_driver_cooperation_terms_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_cooperation_terms rid_driver_cooperation_terms_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_cooperation_terms
    ADD CONSTRAINT rid_driver_cooperation_terms_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_documents rid_driver_documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_documents rid_driver_documents_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_documents rid_driver_documents_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.doc_documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_documents rid_driver_documents_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_documents rid_driver_documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_documents rid_driver_documents_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_documents rid_driver_documents_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_documents
    ADD CONSTRAINT rid_driver_documents_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_languages rid_driver_languages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_languages
    ADD CONSTRAINT rid_driver_languages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_languages rid_driver_languages_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_languages
    ADD CONSTRAINT rid_driver_languages_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_languages rid_driver_languages_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_languages
    ADD CONSTRAINT rid_driver_languages_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_languages rid_driver_languages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_languages
    ADD CONSTRAINT rid_driver_languages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_languages rid_driver_languages_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_languages
    ADD CONSTRAINT rid_driver_languages_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_performances rid_driver_performances_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_performances
    ADD CONSTRAINT rid_driver_performances_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_performances rid_driver_performances_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_performances
    ADD CONSTRAINT rid_driver_performances_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_performances rid_driver_performances_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_performances
    ADD CONSTRAINT rid_driver_performances_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_performances rid_driver_performances_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_performances
    ADD CONSTRAINT rid_driver_performances_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_performances rid_driver_performances_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_performances
    ADD CONSTRAINT rid_driver_performances_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_requests rid_driver_requests_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_requests
    ADD CONSTRAINT rid_driver_requests_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_requests rid_driver_requests_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_requests
    ADD CONSTRAINT rid_driver_requests_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_requests rid_driver_requests_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_requests
    ADD CONSTRAINT rid_driver_requests_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_requests rid_driver_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_requests
    ADD CONSTRAINT rid_driver_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_requests rid_driver_requests_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_requests
    ADD CONSTRAINT rid_driver_requests_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_training rid_driver_training_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_training
    ADD CONSTRAINT rid_driver_training_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_training rid_driver_training_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_training
    ADD CONSTRAINT rid_driver_training_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_driver_training rid_driver_training_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_training
    ADD CONSTRAINT rid_driver_training_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_training rid_driver_training_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_training
    ADD CONSTRAINT rid_driver_training_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rid_driver_training rid_driver_training_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_driver_training
    ADD CONSTRAINT rid_driver_training_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rid_drivers rid_drivers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rid_drivers
    ADD CONSTRAINT rid_drivers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_goals sch_goals_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_goals
    ADD CONSTRAINT sch_goals_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_goals sch_goals_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_goals
    ADD CONSTRAINT sch_goals_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_goals sch_goals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_goals
    ADD CONSTRAINT sch_goals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_goals sch_goals_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_goals
    ADD CONSTRAINT sch_goals_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_maintenance_schedules sch_maintenance_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_maintenance_schedules
    ADD CONSTRAINT sch_maintenance_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_maintenance_schedules sch_maintenance_schedules_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_maintenance_schedules
    ADD CONSTRAINT sch_maintenance_schedules_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_maintenance_schedules sch_maintenance_schedules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_maintenance_schedules
    ADD CONSTRAINT sch_maintenance_schedules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_maintenance_schedules sch_maintenance_schedules_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_maintenance_schedules
    ADD CONSTRAINT sch_maintenance_schedules_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_maintenance_schedules sch_maintenance_schedules_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_maintenance_schedules
    ADD CONSTRAINT sch_maintenance_schedules_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_shifts sch_shifts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_shifts
    ADD CONSTRAINT sch_shifts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_shifts sch_shifts_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_shifts
    ADD CONSTRAINT sch_shifts_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_shifts sch_shifts_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_shifts
    ADD CONSTRAINT sch_shifts_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_shifts sch_shifts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_shifts
    ADD CONSTRAINT sch_shifts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_shifts sch_shifts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_shifts
    ADD CONSTRAINT sch_shifts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_tasks sch_tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_tasks
    ADD CONSTRAINT sch_tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_tasks sch_tasks_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_tasks
    ADD CONSTRAINT sch_tasks_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sch_tasks sch_tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_tasks
    ADD CONSTRAINT sch_tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sch_tasks sch_tasks_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sch_tasks
    ADD CONSTRAINT sch_tasks_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_customer_feedback sup_customer_feedback_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_customer_feedback
    ADD CONSTRAINT sup_customer_feedback_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON DELETE CASCADE;


--
-- Name: sup_ticket_messages sup_ticket_messages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_ticket_messages
    ADD CONSTRAINT sup_ticket_messages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_ticket_messages sup_ticket_messages_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_ticket_messages
    ADD CONSTRAINT sup_ticket_messages_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_ticket_messages sup_ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_ticket_messages
    ADD CONSTRAINT sup_ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.sup_tickets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sup_ticket_messages sup_ticket_messages_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_ticket_messages
    ADD CONSTRAINT sup_ticket_messages_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_tickets sup_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_tickets
    ADD CONSTRAINT sup_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.adm_provider_employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_tickets sup_tickets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_tickets
    ADD CONSTRAINT sup_tickets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_tickets sup_tickets_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_tickets
    ADD CONSTRAINT sup_tickets_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sup_tickets sup_tickets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_tickets
    ADD CONSTRAINT sup_tickets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sup_tickets sup_tickets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sup_tickets
    ADD CONSTRAINT sup_tickets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_client_invoices trp_client_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_client_invoices
    ADD CONSTRAINT trp_client_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_client_invoices trp_client_invoices_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_client_invoices
    ADD CONSTRAINT trp_client_invoices_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_client_invoices trp_client_invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_client_invoices
    ADD CONSTRAINT trp_client_invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_client_invoices trp_client_invoices_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_client_invoices
    ADD CONSTRAINT trp_client_invoices_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_platform_accounts trp_platform_accounts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_platform_accounts
    ADD CONSTRAINT trp_platform_accounts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_platform_accounts trp_platform_accounts_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_platform_accounts
    ADD CONSTRAINT trp_platform_accounts_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_platform_accounts trp_platform_accounts_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_platform_accounts
    ADD CONSTRAINT trp_platform_accounts_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES public.dir_platforms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_platform_accounts trp_platform_accounts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_platform_accounts
    ADD CONSTRAINT trp_platform_accounts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_platform_accounts trp_platform_accounts_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_platform_accounts
    ADD CONSTRAINT trp_platform_accounts_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_settlements trp_settlements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_settlements
    ADD CONSTRAINT trp_settlements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_settlements trp_settlements_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_settlements
    ADD CONSTRAINT trp_settlements_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_settlements trp_settlements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_settlements
    ADD CONSTRAINT trp_settlements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_settlements trp_settlements_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_settlements
    ADD CONSTRAINT trp_settlements_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trp_trips(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_settlements trp_settlements_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_settlements
    ADD CONSTRAINT trp_settlements_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.adm_members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trp_trips trp_trips_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_trips
    ADD CONSTRAINT trp_trips_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.rid_drivers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_trips trp_trips_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_trips
    ADD CONSTRAINT trp_trips_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES public.dir_platforms(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: trp_trips trp_trips_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_trips
    ADD CONSTRAINT trp_trips_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.adm_tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: trp_trips trp_trips_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trp_trips
    ADD CONSTRAINT trp_trips_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.flt_vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_member_roles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.adm_member_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_members; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.adm_members ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_provider_employees; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.adm_provider_employees ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_roles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.adm_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_tenant_lifecycle_events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.adm_tenant_lifecycle_events ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_tenants; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.adm_tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: bil_billing_plans; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bil_billing_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: bil_payment_methods; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bil_payment_methods ENABLE ROW LEVEL SECURITY;

--
-- Name: bil_tenant_invoice_lines; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bil_tenant_invoice_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: bil_tenant_invoices; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bil_tenant_invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: bil_tenant_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bil_tenant_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: bil_tenant_usage_metrics; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bil_tenant_usage_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_contracts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.crm_contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_leads; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.crm_leads ENABLE ROW LEVEL SECURITY;

--
-- Name: crm_opportunities; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.crm_opportunities ENABLE ROW LEVEL SECURITY;

--
-- Name: dir_car_makes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dir_car_makes ENABLE ROW LEVEL SECURITY;

--
-- Name: dir_car_models; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dir_car_models ENABLE ROW LEVEL SECURITY;

--
-- Name: dir_country_regulations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dir_country_regulations ENABLE ROW LEVEL SECURITY;

--
-- Name: dir_platforms; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dir_platforms ENABLE ROW LEVEL SECURITY;

--
-- Name: dir_vehicle_classes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dir_vehicle_classes ENABLE ROW LEVEL SECURITY;

--
-- Name: doc_documents; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.doc_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: fin_accounts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.fin_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: fin_driver_payment_batches; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.fin_driver_payment_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: fin_driver_payments; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.fin_driver_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: fin_toll_transactions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.fin_toll_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: fin_traffic_fines; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.fin_traffic_fines ENABLE ROW LEVEL SECURITY;

--
-- Name: fin_transactions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.fin_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: flt_vehicle_assignments; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.flt_vehicle_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: flt_vehicle_events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.flt_vehicle_events ENABLE ROW LEVEL SECURITY;

--
-- Name: flt_vehicle_expenses; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.flt_vehicle_expenses ENABLE ROW LEVEL SECURITY;

--
-- Name: flt_vehicle_insurances; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.flt_vehicle_insurances ENABLE ROW LEVEL SECURITY;

--
-- Name: flt_vehicle_maintenance; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.flt_vehicle_maintenance ENABLE ROW LEVEL SECURITY;

--
-- Name: flt_vehicles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.flt_vehicles ENABLE ROW LEVEL SECURITY;

--
-- Name: rev_driver_revenues; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rev_driver_revenues ENABLE ROW LEVEL SECURITY;

--
-- Name: rev_reconciliations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rev_reconciliations ENABLE ROW LEVEL SECURITY;

--
-- Name: rev_revenue_imports; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rev_revenue_imports ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_blacklists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_blacklists ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_cooperation_terms; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_cooperation_terms ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_documents; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_languages; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_languages ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_performances; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_performances ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_requests; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_driver_training; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_driver_training ENABLE ROW LEVEL SECURITY;

--
-- Name: rid_drivers; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rid_drivers ENABLE ROW LEVEL SECURITY;

--
-- Name: sch_goals; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sch_goals ENABLE ROW LEVEL SECURITY;

--
-- Name: sch_maintenance_schedules; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sch_maintenance_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: sch_shifts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sch_shifts ENABLE ROW LEVEL SECURITY;

--
-- Name: sch_tasks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sch_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: sup_customer_feedback; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sup_customer_feedback ENABLE ROW LEVEL SECURITY;

--
-- Name: sup_ticket_messages; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sup_ticket_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: sup_tickets; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.sup_tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: adm_member_roles temp_allow_all_adm_member_roles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_adm_member_roles ON public.adm_member_roles TO authenticated USING (true);


--
-- Name: adm_members temp_allow_all_adm_members; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_adm_members ON public.adm_members TO authenticated USING (true);


--
-- Name: adm_provider_employees temp_allow_all_adm_provider_employees; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_adm_provider_employees ON public.adm_provider_employees TO authenticated USING (true);


--
-- Name: adm_roles temp_allow_all_adm_roles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_adm_roles ON public.adm_roles TO authenticated USING (true);


--
-- Name: adm_tenant_lifecycle_events temp_allow_all_adm_tenant_lifecycle_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_adm_tenant_lifecycle_events ON public.adm_tenant_lifecycle_events TO authenticated USING (true);


--
-- Name: adm_tenants temp_allow_all_adm_tenants; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_adm_tenants ON public.adm_tenants TO authenticated USING (true);


--
-- Name: bil_billing_plans temp_allow_all_bil_billing_plans; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_bil_billing_plans ON public.bil_billing_plans TO authenticated USING (true);


--
-- Name: bil_payment_methods temp_allow_all_bil_payment_methods; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_bil_payment_methods ON public.bil_payment_methods TO authenticated USING (true);


--
-- Name: bil_tenant_invoice_lines temp_allow_all_bil_tenant_invoice_lines; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_bil_tenant_invoice_lines ON public.bil_tenant_invoice_lines TO authenticated USING (true);


--
-- Name: bil_tenant_invoices temp_allow_all_bil_tenant_invoices; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_bil_tenant_invoices ON public.bil_tenant_invoices TO authenticated USING (true);


--
-- Name: bil_tenant_subscriptions temp_allow_all_bil_tenant_subscriptions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_bil_tenant_subscriptions ON public.bil_tenant_subscriptions TO authenticated USING (true);


--
-- Name: bil_tenant_usage_metrics temp_allow_all_bil_tenant_usage_metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_bil_tenant_usage_metrics ON public.bil_tenant_usage_metrics TO authenticated USING (true);


--
-- Name: crm_contracts temp_allow_all_crm_contracts_dev; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_crm_contracts_dev ON public.crm_contracts USING (true) WITH CHECK (true);


--
-- Name: crm_leads temp_allow_all_crm_leads_dev; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_crm_leads_dev ON public.crm_leads USING (true) WITH CHECK (true);


--
-- Name: crm_opportunities temp_allow_all_crm_opportunities_dev; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_crm_opportunities_dev ON public.crm_opportunities USING (true) WITH CHECK (true);


--
-- Name: dir_car_makes temp_allow_all_dir_car_makes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_dir_car_makes ON public.dir_car_makes TO authenticated USING (true);


--
-- Name: dir_car_models temp_allow_all_dir_car_models; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_dir_car_models ON public.dir_car_models TO authenticated USING (true);


--
-- Name: dir_country_regulations temp_allow_all_dir_country_regulations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_dir_country_regulations ON public.dir_country_regulations TO authenticated USING (true);


--
-- Name: dir_platforms temp_allow_all_dir_platforms; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_dir_platforms ON public.dir_platforms TO authenticated USING (true);


--
-- Name: dir_vehicle_classes temp_allow_all_dir_vehicle_classes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_dir_vehicle_classes ON public.dir_vehicle_classes TO authenticated USING (true);


--
-- Name: doc_documents temp_allow_all_doc_documents; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_doc_documents ON public.doc_documents TO authenticated USING (true);


--
-- Name: fin_accounts temp_allow_all_fin_accounts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_fin_accounts ON public.fin_accounts TO authenticated USING (true);


--
-- Name: fin_driver_payment_batches temp_allow_all_fin_driver_payment_batches; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_fin_driver_payment_batches ON public.fin_driver_payment_batches TO authenticated USING (true);


--
-- Name: fin_driver_payments temp_allow_all_fin_driver_payments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_fin_driver_payments ON public.fin_driver_payments TO authenticated USING (true);


--
-- Name: fin_toll_transactions temp_allow_all_fin_toll_transactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_fin_toll_transactions ON public.fin_toll_transactions TO authenticated USING (true);


--
-- Name: fin_traffic_fines temp_allow_all_fin_traffic_fines; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_fin_traffic_fines ON public.fin_traffic_fines TO authenticated USING (true);


--
-- Name: fin_transactions temp_allow_all_fin_transactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_fin_transactions ON public.fin_transactions TO authenticated USING (true);


--
-- Name: flt_vehicle_assignments temp_allow_all_flt_vehicle_assignments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_flt_vehicle_assignments ON public.flt_vehicle_assignments TO authenticated USING (true);


--
-- Name: flt_vehicle_events temp_allow_all_flt_vehicle_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_flt_vehicle_events ON public.flt_vehicle_events TO authenticated USING (true);


--
-- Name: flt_vehicle_expenses temp_allow_all_flt_vehicle_expenses; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_flt_vehicle_expenses ON public.flt_vehicle_expenses TO authenticated USING (true);


--
-- Name: flt_vehicle_insurances temp_allow_all_flt_vehicle_insurances; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_flt_vehicle_insurances ON public.flt_vehicle_insurances TO authenticated USING (true);


--
-- Name: flt_vehicle_maintenance temp_allow_all_flt_vehicle_maintenance; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_flt_vehicle_maintenance ON public.flt_vehicle_maintenance TO authenticated USING (true);


--
-- Name: flt_vehicles temp_allow_all_flt_vehicles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_flt_vehicles ON public.flt_vehicles TO authenticated USING (true);


--
-- Name: rev_driver_revenues temp_allow_all_rev_driver_revenues; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rev_driver_revenues ON public.rev_driver_revenues TO authenticated USING (true);


--
-- Name: rev_reconciliations temp_allow_all_rev_reconciliations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rev_reconciliations ON public.rev_reconciliations TO authenticated USING (true);


--
-- Name: rev_revenue_imports temp_allow_all_rev_revenue_imports; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rev_revenue_imports ON public.rev_revenue_imports TO authenticated USING (true);


--
-- Name: rid_driver_blacklists temp_allow_all_rid_driver_blacklists; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_driver_blacklists ON public.rid_driver_blacklists TO authenticated USING (true);


--
-- Name: rid_driver_cooperation_terms temp_allow_all_rid_driver_cooperation_terms; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_driver_cooperation_terms ON public.rid_driver_cooperation_terms TO authenticated USING (true);


--
-- Name: rid_driver_documents temp_allow_all_rid_driver_documents; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_driver_documents ON public.rid_driver_documents TO authenticated USING (true);


--
-- Name: rid_driver_performances temp_allow_all_rid_driver_performances; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_driver_performances ON public.rid_driver_performances TO authenticated USING (true);


--
-- Name: rid_driver_requests temp_allow_all_rid_driver_requests; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_driver_requests ON public.rid_driver_requests TO authenticated USING (true);


--
-- Name: rid_driver_training temp_allow_all_rid_driver_training; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_driver_training ON public.rid_driver_training TO authenticated USING (true);


--
-- Name: rid_drivers temp_allow_all_rid_drivers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_rid_drivers ON public.rid_drivers TO authenticated USING (true);


--
-- Name: sch_goals temp_allow_all_sch_goals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sch_goals ON public.sch_goals TO authenticated USING (true);


--
-- Name: sch_maintenance_schedules temp_allow_all_sch_maintenance_schedules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sch_maintenance_schedules ON public.sch_maintenance_schedules TO authenticated USING (true);


--
-- Name: sch_shifts temp_allow_all_sch_shifts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sch_shifts ON public.sch_shifts TO authenticated USING (true);


--
-- Name: sch_tasks temp_allow_all_sch_tasks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sch_tasks ON public.sch_tasks TO authenticated USING (true);


--
-- Name: sup_customer_feedback temp_allow_all_sup_customer_feedback; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sup_customer_feedback ON public.sup_customer_feedback USING (true) WITH CHECK (true);


--
-- Name: sup_ticket_messages temp_allow_all_sup_ticket_messages; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sup_ticket_messages ON public.sup_ticket_messages TO authenticated USING (true);


--
-- Name: sup_tickets temp_allow_all_sup_tickets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_sup_tickets ON public.sup_tickets TO authenticated USING (true);


--
-- Name: trp_client_invoices temp_allow_all_trp_client_invoices; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_trp_client_invoices ON public.trp_client_invoices TO authenticated USING (true);


--
-- Name: trp_platform_accounts temp_allow_all_trp_platform_accounts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_trp_platform_accounts ON public.trp_platform_accounts TO authenticated USING (true);


--
-- Name: trp_settlements temp_allow_all_trp_settlements; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_trp_settlements ON public.trp_settlements TO authenticated USING (true);


--
-- Name: trp_trips temp_allow_all_trp_trips; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY temp_allow_all_trp_trips ON public.trp_trips TO authenticated USING (true);


--
-- Name: adm_member_roles tenant_isolation_adm_member_roles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_adm_member_roles ON public.adm_member_roles TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: adm_members tenant_isolation_adm_members; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_adm_members ON public.adm_members TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: adm_roles tenant_isolation_adm_roles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_adm_roles ON public.adm_roles TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: adm_tenant_lifecycle_events tenant_isolation_adm_tenant_lifecycle_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_adm_tenant_lifecycle_events ON public.adm_tenant_lifecycle_events TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: bil_payment_methods tenant_isolation_bil_payment_methods; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_bil_payment_methods ON public.bil_payment_methods TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: bil_tenant_invoices tenant_isolation_bil_tenant_invoices; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_bil_tenant_invoices ON public.bil_tenant_invoices TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: bil_tenant_subscriptions tenant_isolation_bil_tenant_subscriptions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_bil_tenant_subscriptions ON public.bil_tenant_subscriptions TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: bil_tenant_usage_metrics tenant_isolation_bil_tenant_usage_metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_bil_tenant_usage_metrics ON public.bil_tenant_usage_metrics TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: dir_car_makes tenant_isolation_dir_car_makes; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_dir_car_makes ON public.dir_car_makes TO authenticated USING (((tenant_id IS NULL) OR (tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid))) WITH CHECK (((tenant_id IS NULL) OR (tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)));


--
-- Name: dir_car_models tenant_isolation_dir_car_models; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_dir_car_models ON public.dir_car_models TO authenticated USING (((tenant_id IS NULL) OR (tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid))) WITH CHECK (((tenant_id IS NULL) OR (tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)));


--
-- Name: doc_documents tenant_isolation_doc_documents; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_doc_documents ON public.doc_documents TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: fin_accounts tenant_isolation_fin_accounts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_fin_accounts ON public.fin_accounts TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: fin_driver_payment_batches tenant_isolation_fin_driver_payment_batches; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_fin_driver_payment_batches ON public.fin_driver_payment_batches TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: fin_driver_payments tenant_isolation_fin_driver_payments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_fin_driver_payments ON public.fin_driver_payments TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: fin_toll_transactions tenant_isolation_fin_toll_transactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_fin_toll_transactions ON public.fin_toll_transactions TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: fin_traffic_fines tenant_isolation_fin_traffic_fines; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_fin_traffic_fines ON public.fin_traffic_fines TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: fin_transactions tenant_isolation_fin_transactions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_fin_transactions ON public.fin_transactions TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: flt_vehicle_assignments tenant_isolation_flt_vehicle_assignments; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_flt_vehicle_assignments ON public.flt_vehicle_assignments TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: flt_vehicle_events tenant_isolation_flt_vehicle_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_flt_vehicle_events ON public.flt_vehicle_events TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: flt_vehicle_expenses tenant_isolation_flt_vehicle_expenses; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_flt_vehicle_expenses ON public.flt_vehicle_expenses TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: flt_vehicle_insurances tenant_isolation_flt_vehicle_insurances; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_flt_vehicle_insurances ON public.flt_vehicle_insurances TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: flt_vehicle_maintenance tenant_isolation_flt_vehicle_maintenance; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_flt_vehicle_maintenance ON public.flt_vehicle_maintenance TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: flt_vehicles tenant_isolation_flt_vehicles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_flt_vehicles ON public.flt_vehicles TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rev_driver_revenues tenant_isolation_rev_driver_revenues; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rev_driver_revenues ON public.rev_driver_revenues TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rev_reconciliations tenant_isolation_rev_reconciliations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rev_reconciliations ON public.rev_reconciliations TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rev_revenue_imports tenant_isolation_rev_revenue_imports; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rev_revenue_imports ON public.rev_revenue_imports TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_driver_blacklists tenant_isolation_rid_driver_blacklists; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_blacklists ON public.rid_driver_blacklists TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_driver_cooperation_terms tenant_isolation_rid_driver_cooperation_terms; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_cooperation_terms ON public.rid_driver_cooperation_terms TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_driver_documents tenant_isolation_rid_driver_documents; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_documents ON public.rid_driver_documents TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_driver_languages tenant_isolation_rid_driver_languages_delete; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_languages_delete ON public.rid_driver_languages FOR UPDATE USING ((((tenant_id)::text = COALESCE(current_setting('app.current_tenant_id'::text, true), ''::text)) AND (deleted_at IS NULL)));


--
-- Name: rid_driver_languages tenant_isolation_rid_driver_languages_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_languages_insert ON public.rid_driver_languages FOR INSERT WITH CHECK (((tenant_id)::text = COALESCE(current_setting('app.current_tenant_id'::text, true), ''::text)));


--
-- Name: rid_driver_languages tenant_isolation_rid_driver_languages_select; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_languages_select ON public.rid_driver_languages FOR SELECT USING ((((tenant_id)::text = COALESCE(current_setting('app.current_tenant_id'::text, true), ''::text)) AND (deleted_at IS NULL)));


--
-- Name: rid_driver_languages tenant_isolation_rid_driver_languages_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_languages_update ON public.rid_driver_languages FOR UPDATE USING ((((tenant_id)::text = COALESCE(current_setting('app.current_tenant_id'::text, true), ''::text)) AND (deleted_at IS NULL))) WITH CHECK (((tenant_id)::text = COALESCE(current_setting('app.current_tenant_id'::text, true), ''::text)));


--
-- Name: rid_driver_performances tenant_isolation_rid_driver_performances; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_performances ON public.rid_driver_performances TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_driver_requests tenant_isolation_rid_driver_requests; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_requests ON public.rid_driver_requests TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_driver_training tenant_isolation_rid_driver_training; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_driver_training ON public.rid_driver_training TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: rid_drivers tenant_isolation_rid_drivers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_rid_drivers ON public.rid_drivers TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: sch_goals tenant_isolation_sch_goals; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sch_goals ON public.sch_goals TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: sch_maintenance_schedules tenant_isolation_sch_maintenance_schedules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sch_maintenance_schedules ON public.sch_maintenance_schedules TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: sch_shifts tenant_isolation_sch_shifts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sch_shifts ON public.sch_shifts TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: sch_tasks tenant_isolation_sch_tasks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sch_tasks ON public.sch_tasks TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: sup_customer_feedback tenant_isolation_sup_customer_feedback; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sup_customer_feedback ON public.sup_customer_feedback USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: sup_ticket_messages tenant_isolation_sup_ticket_messages; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sup_ticket_messages ON public.sup_ticket_messages TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.sup_tickets t
  WHERE ((t.id = sup_ticket_messages.ticket_id) AND (t.tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.sup_tickets t
  WHERE ((t.id = sup_ticket_messages.ticket_id) AND (t.tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)))));


--
-- Name: sup_tickets tenant_isolation_sup_tickets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_sup_tickets ON public.sup_tickets TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: trp_client_invoices tenant_isolation_trp_client_invoices; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_trp_client_invoices ON public.trp_client_invoices TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: trp_platform_accounts tenant_isolation_trp_platform_accounts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_trp_platform_accounts ON public.trp_platform_accounts TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: trp_settlements tenant_isolation_trp_settlements; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_trp_settlements ON public.trp_settlements TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: trp_trips tenant_isolation_trp_trips; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation_trp_trips ON public.trp_trips TO authenticated USING ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid)) WITH CHECK ((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid));


--
-- Name: trp_client_invoices; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.trp_client_invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: trp_platform_accounts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.trp_platform_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: trp_settlements; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.trp_settlements ENABLE ROW LEVEL SECURITY;

--
-- Name: trp_trips; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.trp_trips ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO prisma;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA shadow; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA shadow TO prisma;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION citextin(cstring); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citextin(cstring) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citextout(extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citextout(extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citextrecv(internal); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citextrecv(internal) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citextsend(extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citextsend(extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext(boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext(boolean) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext(character); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext(character) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext(inet); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext(inet) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION citext_cmp(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_cmp(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_eq(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_eq(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_ge(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_ge(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_gt(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_gt(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_hash(extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_hash(extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_hash_extended(extensions.citext, bigint); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_hash_extended(extensions.citext, bigint) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_larger(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_larger(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_le(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_le(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_lt(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_lt(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_ne(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_ne(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_pattern_cmp(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_pattern_cmp(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_pattern_ge(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_pattern_ge(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_pattern_gt(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_pattern_gt(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_pattern_le(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_pattern_le(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_pattern_lt(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_pattern_lt(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION citext_smaller(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.citext_smaller(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_match(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_match(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_match(extensions.citext, extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_match(extensions.citext, extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_matches(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_matches(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_matches(extensions.citext, extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_matches(extensions.citext, extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_replace(extensions.citext, extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_replace(extensions.citext, extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_replace(extensions.citext, extensions.citext, text, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_replace(extensions.citext, extensions.citext, text, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_split_to_array(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_split_to_array(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_split_to_array(extensions.citext, extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_split_to_array(extensions.citext, extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_split_to_table(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_split_to_table(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION regexp_split_to_table(extensions.citext, extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.regexp_split_to_table(extensions.citext, extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION replace(extensions.citext, extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.replace(extensions.citext, extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION split_part(extensions.citext, extensions.citext, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.split_part(extensions.citext, extensions.citext, integer) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION strpos(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.strpos(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticlike(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticlike(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticlike(extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticlike(extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticnlike(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticnlike(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticnlike(extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticnlike(extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticregexeq(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticregexeq(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticregexeq(extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticregexeq(extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticregexne(extensions.citext, extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticregexne(extensions.citext, extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION texticregexne(extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.texticregexne(extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION translate(extensions.citext, extensions.citext, text); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.translate(extensions.citext, extensions.citext, text) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO postgres;


--
-- Name: FUNCTION rid_driver_language_add(p_tenant_id uuid, p_driver_id uuid, p_language_code character, p_proficiency text, p_created_by uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.rid_driver_language_add(p_tenant_id uuid, p_driver_id uuid, p_language_code character, p_proficiency text, p_created_by uuid) TO prisma;


--
-- Name: FUNCTION rid_driver_profile_get(p_driver_id uuid, p_tenant_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.rid_driver_profile_get(p_driver_id uuid, p_tenant_id uuid) TO prisma;


--
-- Name: FUNCTION set_tenant(p_tenant_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_tenant(p_tenant_id uuid) TO prisma;


--
-- Name: FUNCTION set_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_updated_at() TO prisma;


--
-- Name: FUNCTION sync_driver_status_from_employment(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.sync_driver_status_from_employment() TO prisma;


--
-- Name: FUNCTION trigger_set_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.trigger_set_updated_at() TO prisma;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION max(extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.max(extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION min(extensions.citext); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.min(extensions.citext) TO postgres WITH GRANT OPTION;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE _prisma_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public._prisma_migrations TO prisma;


--
-- Name: TABLE adm_audit_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_audit_logs TO prisma;


--
-- Name: TABLE adm_member_roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_member_roles TO prisma;


--
-- Name: TABLE adm_members; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_members TO prisma;


--
-- Name: TABLE adm_provider_employees; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_provider_employees TO prisma;


--
-- Name: TABLE adm_roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_roles TO prisma;


--
-- Name: TABLE adm_tenant_lifecycle_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_tenant_lifecycle_events TO prisma;


--
-- Name: TABLE adm_tenants; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.adm_tenants TO prisma;


--
-- Name: TABLE bil_billing_plans; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bil_billing_plans TO prisma;


--
-- Name: TABLE bil_payment_methods; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bil_payment_methods TO prisma;


--
-- Name: TABLE bil_tenant_invoice_lines; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bil_tenant_invoice_lines TO prisma;


--
-- Name: TABLE bil_tenant_invoices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bil_tenant_invoices TO prisma;


--
-- Name: TABLE bil_tenant_subscriptions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bil_tenant_subscriptions TO prisma;


--
-- Name: TABLE bil_tenant_usage_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bil_tenant_usage_metrics TO prisma;


--
-- Name: TABLE crm_contracts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.crm_contracts TO prisma;


--
-- Name: TABLE crm_leads; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.crm_leads TO prisma;


--
-- Name: TABLE crm_opportunities; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.crm_opportunities TO prisma;


--
-- Name: TABLE dir_car_makes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.dir_car_makes TO prisma;


--
-- Name: TABLE dir_car_models; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.dir_car_models TO prisma;


--
-- Name: TABLE dir_country_regulations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.dir_country_regulations TO prisma;


--
-- Name: TABLE dir_platforms; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.dir_platforms TO prisma;


--
-- Name: TABLE dir_vehicle_classes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.dir_vehicle_classes TO prisma;


--
-- Name: TABLE doc_documents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.doc_documents TO prisma;


--
-- Name: TABLE fin_accounts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fin_accounts TO prisma;


--
-- Name: TABLE fin_driver_payment_batches; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fin_driver_payment_batches TO prisma;


--
-- Name: TABLE fin_driver_payments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fin_driver_payments TO prisma;


--
-- Name: TABLE fin_toll_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fin_toll_transactions TO prisma;


--
-- Name: TABLE fin_traffic_fines; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fin_traffic_fines TO prisma;


--
-- Name: TABLE fin_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fin_transactions TO prisma;


--
-- Name: TABLE flt_vehicle_assignments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flt_vehicle_assignments TO prisma;


--
-- Name: TABLE flt_vehicle_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flt_vehicle_events TO prisma;


--
-- Name: TABLE flt_vehicle_expenses; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flt_vehicle_expenses TO prisma;


--
-- Name: TABLE flt_vehicle_insurances; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flt_vehicle_insurances TO prisma;


--
-- Name: TABLE flt_vehicle_maintenance; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flt_vehicle_maintenance TO prisma;


--
-- Name: TABLE flt_vehicles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.flt_vehicles TO prisma;


--
-- Name: TABLE rev_driver_revenues; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rev_driver_revenues TO prisma;


--
-- Name: TABLE rev_reconciliations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rev_reconciliations TO prisma;


--
-- Name: TABLE rev_revenue_imports; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rev_revenue_imports TO prisma;


--
-- Name: TABLE rid_driver_blacklists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_blacklists TO prisma;


--
-- Name: TABLE rid_driver_cooperation_terms; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_cooperation_terms TO prisma;


--
-- Name: TABLE rid_driver_documents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_documents TO prisma;


--
-- Name: TABLE rid_driver_languages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_languages TO prisma;


--
-- Name: TABLE rid_driver_performances; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_performances TO prisma;


--
-- Name: TABLE rid_driver_requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_requests TO prisma;


--
-- Name: TABLE rid_driver_training; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_driver_training TO prisma;


--
-- Name: TABLE rid_drivers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.rid_drivers TO prisma;


--
-- Name: TABLE sch_goals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sch_goals TO prisma;


--
-- Name: TABLE sch_maintenance_schedules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sch_maintenance_schedules TO prisma;


--
-- Name: TABLE sch_shifts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sch_shifts TO prisma;


--
-- Name: TABLE sch_tasks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sch_tasks TO prisma;


--
-- Name: TABLE sup_customer_feedback; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sup_customer_feedback TO prisma;


--
-- Name: TABLE sup_ticket_messages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sup_ticket_messages TO prisma;


--
-- Name: TABLE sup_tickets; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sup_tickets TO prisma;


--
-- Name: TABLE trp_client_invoices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.trp_client_invoices TO prisma;


--
-- Name: TABLE trp_platform_accounts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.trp_platform_accounts TO prisma;


--
-- Name: TABLE trp_settlements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.trp_settlements TO prisma;


--
-- Name: TABLE trp_trips; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.trp_trips TO prisma;


--
-- Name: TABLE v_driver_profile; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_driver_profile TO prisma;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE prefixes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.prefixes TO service_role;
GRANT ALL ON TABLE storage.prefixes TO authenticated;
GRANT ALL ON TABLE storage.prefixes TO anon;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO prisma;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO prisma;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO prisma;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: shadow; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA shadow GRANT ALL ON TABLES TO postgres;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict vWvUyac9BWqJJViPhRrdQSvjA01yypE9jYTPOy7ajNGWfUmx1TxmN7i5ATggUQ1

